# Part 1 论文代码归档

整理日期：2026-11-10。仅归档代码与必要静态配置，不含模拟输出、状态轨迹、结果数组、统计结果、成图、论文文件、字体、编译产物、虚拟环境或登录凭据。

本包对应当前Part 1（9.0稿）的模式与6张图。01_current_model 是当前参数命名的自由积分入口。参考阈值 c29=1、c28=0.5，c27=0.01*0.009（与历史原表达式的浮点求值顺序保持一致），E0=0.8、A0=0.0018。

运行顺序：Linux下先运行 `bash build.sh`，只编译，不积分。然后在两个不同的新结果目录中分别运行 build/model7 和 build/model10。原驱动起转10000 TU，最长积分2000000 TU；不会因为归档而缩短，运行前请确认计算资源。Fig. 1使用biased_twin.f90；Fig. 2使用plot_model_psd_original_method.py；Fig. 3/4使用emission/plot_freeze.py的V2/V3段；Fig. 5/6使用当前参数图重绘脚本及相应历史生成器。详情见FIGURE_CODE_MAP.csv。

排放、敏感性、响应时间及额外诊断的原始生成程序位于02_original_generators和04_additional_analysis，其中保留旧参数名及原目录关系；其旧c28=1对应当前c29=1。不要把历史模块覆盖到01_current_model，也不要对当前名再次应用旧名映射。当前自由模式与本次从超算下载的free_model_new源码经A1→c29名称替换后逐行一致。


## 目录与复现边界

- 01_current_model：当前主用源码与静态配置。
- 02_original_generators：支撑既有实验/分析的原始生成与处理代码，保留历史相对路径和旧参数名。
- 03_current_figure_code：最终参数名的绘图入口、符号映射和绘图源模块。此目录脚本需要实验生成的graph_inputs数组；数据没有打包。
- 04_additional_analysis（若有）：模式反馈、频谱、收支等补充诊断源代码。
- 05_display_provenance：最终标签与字体处理的追溯脚本，其中部分具有修改Word功能；无需运行它们来编译模式。
- FIGURE_CODE_MAP.csv：图号、代码入口和预期输入文件对照。
- SOURCE_MANIFEST.json、MANIFEST.sha256、verify_archive.py：来源、校验和与本地完整性检查。

先用 `python verify_archive.py` 检查文件完整性。正式数值计算及分析应使用原超算yuki环境或经验证的等效环境。requirements.txt仅列依赖名称，不声称重建了历史软件版本。原始脚本可能含绝对数据路径，迁移后需按自身目录调整路径常量；不要因此修改方程、参数、时间步、种子或频谱设置。图内Times New Roman字体由运行者自行安装，本包不附带字体文件。

历史脚本中的批处理账号/远程路径仅供追溯；若在Levante重新提交，须使用ab0246，并按当前平台检查脚本。此包没有自动上传、提交、停止或更改任何超算作业。本次只做下载、来源比对、静态语法和归档校验，没有重新进行科学计算或重绘。

本地ZIP本身没有公开仓库链接或DOI。正式投稿时，需将选定的代码版本归档到可公开访问且提供永久标识符的仓库，再在Availability Statement中填写真实地址；不能将本地路径表述为公开数据仓库。

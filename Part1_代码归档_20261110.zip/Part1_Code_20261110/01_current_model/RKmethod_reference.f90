module RKmethod
    implicit none
    integer, parameter :: dp = selected_real_kind(15, 307)
    
    ! --- 基础物理参数：以 Yang (2024) Table 1 为准 (已修正 ss = 1.0) ---
    real(kind=dp), parameter :: sigma=9.95_dp, kappa=28.0_dp, b=8.0/3.0_dp
    real(kind=dp), parameter :: om=10.0_dp, od=1.0_dp, sm=10.0_dp
    real(kind=dp), parameter :: ss=1.0_dp, spd=10.0_dp  
    real(kind=dp), parameter :: gamma_deep=100.0_dp
    real(kind=dp), parameter :: c1=0.1_dp, c2=1.0_dp, c3=0.01_dp, c4=0.01_dp, c5=1.0_dp
    real(kind=dp), parameter :: c6=0.001_dp, c7=0.1_dp, c8=0.1_dp, c9=0.1_dp, c10=10.0_dp
    real(kind=dp), parameter :: c11=0.01_dp, c12=0.5_dp, c13=0.01_dp, c14=0.1_dp, c15=0.05_dp
    real(kind=dp), parameter :: lambda=0.3_dp, old=0.4_dp, olm=2.0_dp, slm=5.0_dp, sls=1.0_dp

    ! --- 碳循环与自设参数：以 dX1-改.docx 为准 ---
    real(kind=dp), parameter :: c16=0.1_dp, c18=0.001_dp, c19=0.1_dp, c20=0.01_dp
    real(kind=dp), parameter :: c21=0.01_dp, c22=0.001_dp, c23=0.01_dp, c24=0.01_dp
    real(kind=dp), parameter :: c17=0.005_dp, E0=0.8_dp, A0=0.0018_dp
    ! c27 is the effective carbonate-removal coefficient used in the manuscript.
    real(kind=dp), parameter :: rrain=0.009_dp, c27=0.01_dp*rrain, c28=0.5_dp
    real(kind=dp), parameter :: c29=1.0_dp, c25=1.0_dp, c26=1.2_dp

contains
    subroutine adv_true_state(x, it, n_var)
        integer(kind=8), intent(in) :: it
        integer, intent(in) :: n_var
        real(kind=dp), intent(inout) :: x(18)
        real(kind=dp) :: dt=0.01_dp, k1(10), k2(10), k3(10), k4(10), tmp(18), h_val
        
        k1 = derivs(x, it, n_var)
        tmp = x; tmp(1:10) = x(1:10)+0.5*dt*k1
        k2 = derivs(tmp, it, n_var)
        tmp = x; tmp(1:10) = x(1:10)+0.5*dt*k2
        k3 = derivs(tmp, it, n_var)
        tmp = x; tmp(1:10) = x(1:10)+dt*k3
        k4 = derivs(tmp, it, n_var)
        
        x(1:n_var) = x(1:n_var) + (dt/6.0_dp)*(k1(1:n_var)+2.0_dp*k2(1:n_var)+2.0_dp*k3(1:n_var)+k4(1:n_var))
        
        h_val = c8*x(2)**2 + c9*x(4)**2 + c10*x(15)**2 
        if(h_val > 50.0_dp) then; x(6) = 0.0_dp; elseif(h_val < 10.0_dp) then; x(6) = 1.0_dp
        else; x(6) = 0.5_dp*(exp(-(h_val-10.0_dp)/80.0_dp) + exp(-1.0_dp/max(50.0_dp-h_val, 1.0e-10_dp))); endif 
        x(15) = x(6)
    end subroutine

    function derivs(s, it, n) result(ds)
        real(kind=dp), intent(in) :: s(18); integer(kind=8), intent(in) :: it
        integer, intent(in) :: n; real(kind=dp) :: ds(10), pCO2_oc, Bcal, pi
        pi = 3.141592653589793_dp
        ds = 0.0_dp
        if (n >= 9) then
            pCO2_oc = max(c25*s(9) - c26*s(10), 0.0_dp)
            Bcal = c27 * s(9) * max(s(10) - c28*s(9) + c29, 0.0_dp)
        else
            pCO2_oc = 0.0_dp; Bcal = 0.0_dp
        end if
        ds(1)=sigma*(s(2)-s(1))-(lambda+c11*s(7))+c14*(s(7)-s(4))
        ds(2)=-s(1)*s(3)+(1.0+c1*s(4))*kappa*s(1)-s(2)+c13*kappa*s(7)*s(1)
        if(n>=9) ds(2)=ds(2)+c16*s(8)
        ds(3)=s(1)*s(2)-b*s(3)
        ds(4)=(c2*s(2)+c3*s(5)+c4*s(4)*s(5)-od*s(4)-c7*s(15)+c15*s(1)*(s(7)-s(4)))
        if(n<9) then; ds(4)=(ds(4)+sm+ss*cos(2.0*pi*it*0.01/spd))/om
        else; ds(4)=(ds(4)+sm*(1.0+c18*s(8))+ss*cos(2.0*pi*it*0.01/spd))/om; endif
        ds(5)=(c5*s(4)+c6*s(4)*s(5)-od*s(5))/gamma_deep
        ds(7)=(c12*s(2)-old*s(7)-c15*s(1)*(s(7)-s(4)))
        if(n<9) then; ds(7)=(ds(7)+slm+sls*cos(2.0*pi*it*0.01/spd))/olm
        else; ds(7)=(ds(7)+slm*(1.0+c17*s(8))+sls*cos(2.0*pi*it*0.01/spd))/olm; endif
        if(n>=9) then
            ds(8)=E0-c19*(1.0-c20*s(4))*(s(8)-pCO2_oc)-c21*s(8)*s(7)-c22*s(1)*(s(7)-s(4))
            ds(9)=c19*(1.0-c20*s(4))*(s(8)-pCO2_oc)-c23*(1.0-c24*s(4))*s(5)-Bcal
            if(n==10) ds(10)=A0-2.0_dp*Bcal
        endif
    end function
end module

program RK4main
    use RKmethod
    implicit none
    integer(kind=8) :: i, step_total, spin_up
    real(kind=dp) :: x(18) = 0.0_dp, time
    step_total = 200000000_8 ; spin_up = 1000000_8
    x(2) = 1.0_dp; x(10) = 0.0_dp
    open(11, file="x2_10var.txt"); open(12, file="wTL_10var.txt")
    open(13, file="etaCatm_10var.txt"); open(14, file="Cocean_10var.txt"); open(15, file="alk_10var.txt")
    do i = 1, spin_up; call adv_true_state(x, i, 10); end do
    do i = 1, step_total
        call adv_true_state(x, i, 10); time = dble(i)*0.01_dp
        if (time <= 4000.0_dp .and. mod(i, 10_8)==0) write(11,'(F12.2,F19.14)') time, x(2)
        if (time <= 20000.0_dp .and. mod(i, 100_8)==0) write(12,'(F12.2,2F19.14)') time, x(4), x(7)
        if (time <= 200000.0_dp .and. mod(i, 100_8)==0) write(13,'(F12.2,2F19.14)') time, x(5), x(8)
        if (time <= 2000000.0_dp .and. mod(i, 1000_8)==0) write(14,'(F12.2,F19.14)') time, x(9)
        if (time <= 2000000.0_dp .and. mod(i, 1000_8)==0) write(15,'(F12.2,F19.14)') time, x(10)
        if (mod(i, 4000000_8)==0) then
            write(*,'(A,I2,A,F5.1,A)',advance='no') char(13), 10, &
                "-var progress: ", (dble(i)/step_total)*100.0_dp, "%"
        end if
    end do
    close(11); close(12); close(13); close(14); close(15)
    print*, ""
end program

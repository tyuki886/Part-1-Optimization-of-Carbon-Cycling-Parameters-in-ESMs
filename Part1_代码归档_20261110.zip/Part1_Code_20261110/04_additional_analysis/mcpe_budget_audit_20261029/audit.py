from pathlib import Path
import json,hashlib
import numpy as np
B=Path(__file__).resolve().parent
P=B.parent/'tl_route_sediment_20261029'
# Audit only saved 1-TU samples. This is NOT a native-step integrated closure test.
def read(p):return np.memmap(p,dtype='<f8',mode='r',shape=(200001,9))[1:]
def stat(x):return {'mean':float(np.mean(x)),'rms':float(np.sqrt(np.mean(x*x))),'max_abs':float(np.max(abs(x)))}
rows=[]
for seed in range(10):
 ref=read(P/'data'/f'mode1_seed{seed}'/'reference.bin')
 for category,masks,dirname,prefix in [
  ('macro',range(8),P/'data'/f'mode1_seed{seed}','R'),
  ('finer',[1,2,5,6,9,10,13,14],P/'extra/data'/f'seed{seed}','T')]:
  for mask in masks:
   p=dirname/f'{prefix}{mask}.bin';a=read(p);delta=ref[:,4]-a[:,4]
   A1=bool(mask&1);A2=bool(mask&1) if category=='macro' else bool(mask&2)
   O=bool(mask&2) if category=='macro' else bool(mask&4)
   C=bool(mask&4) if category=='macro' else bool(mask&8)
   qheat=np.zeros(len(a)) if O else .05*a[:,0]*delta
   qcarbon=np.zeros(len(a)) if C else -(.01*a[:,5]+.001*a[:,0])*delta
   qa1=np.zeros(len(a)) if A1 else (.1-.01)*delta
   qa2=np.zeros(len(a)) if A2 else .01*28*a[:,0]*delta
   # Independent reconstruction of recipient pair fluxes.
   left=.05*a[:,0]*((a[:,4] if O else ref[:,4])-a[:,2])
   right=-.05*a[:,0]*(a[:,4]-a[:,2])
   assert np.allclose(left+right,qheat,rtol=1e-10,atol=1e-12)
   row={'experiment':category,'mask':mask,'seed':seed,'ocean_land_pair_retained':O,
    'heat_pair_extra':stat(qheat),'carbon_original_flux_law_extra':stat(qcarbon),
    'x1_external_replay':stat(qa1),'x2_external_replay':stat(qa2)}
   rows.append(row)
 for mask in range(4):
  a=read(P/'data'/f'mode2_seed{seed}'/f'S{mask}.bin')
  bn=a[:,8] if mask&1 else np.full(len(a),.0009)
  bk=a[:,8] if mask&2 else np.full(len(a),.0009)
  extra=2*(bn-bk)
  expected=np.zeros(len(a)) if mask in (0,3) else (2 if mask==1 else -2)*(a[:,8]-.0009)
  assert np.array_equal(extra,expected)
  rows.append({'experiment':'sediment','mask':mask,'seed':seed,'stoichiometry_retained':mask in (0,3),
   'ALK_minus_2Cocn_extra':stat(extra)})

summary={}
for group in ['macro','finer','sediment']:
 rr=[r for r in rows if r['experiment']==group]
 summary[group]={}
 for mask in sorted(set(r['mask'] for r in rr)):
  z=[r for r in rr if r['mask']==mask]
  fields=['ALK_minus_2Cocn_extra'] if group=='sediment' else ['heat_pair_extra','carbon_original_flux_law_extra','x1_external_replay','x2_external_replay']
  summary[group][str(mask)]={k:{'mean_of_IC_means':float(np.mean([r[k]['mean'] for r in z])),
   'mean_of_IC_rms':float(np.mean([r[k]['rms'] for r in z])),
   'maximum_sampled_absolute':float(max(r[k]['max_abs'] for r in z))} for k in fields}
result={'scope':'Algebraic paired-flux and stoichiometry audit on saved 1-TU samples over 200000 TU; not an integrated native-step mass/heat closure claim',
 'identities':{
  'weighted_heat_pair_extra':'qH = c15*x1*(TL_ref-TL) when only ocean-side TL is replayed; weighted heat-like sum is om*w+olm*TL, not a complete ESM energy invariant.',
  'carbon_original_flux_law_extra':'qC=(c20*Catm+c21*x1)*(TL-TL_ref) when TL is replayed only in Catm loss terms. The actual modified exports can still close an open-system accounting.',
  'sediment_stoichiometry_extra':'d(ALK-2*Cocn)/dt -(c25-2*Fas+2*Fexp) = 2*(B_N-B_K); zero only if both recipient equations receive the same Bcal.'},
 'conclusions':[
  'Part of the edge-intervention experiment does not preserve the original paired exchange or 1:2 carbon-alkalinity removal law.',
  'Numerical identity and factorial additivity tests from the previous experiment did not establish physical budget closure.',
  'Full c24 on versus off compares unchanged paired-exchange equations, so the aggregate spectral contrast remains a valid conditional model sensitivity.',
  'Full sediment feedback versus balanced-constant feedback in BOTH equations preserves reaction stoichiometry, but separate recipient allocations use mixed unpaired branches.',
  'Fine pathway allocations must be labeled artificial edge-intervention spectral decompositions, not budget-preserving physical contribution estimates.'
 ],'summary':summary,'sampled_results':rows}
(B/'budget_audit_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'macro_R0':summary['macro']['0'],'sediment':summary['sediment'],'conclusions':result['conclusions']},indent=2),flush=True)

from pathlib import Path
from datetime import datetime
import json,hashlib,shutil
B=Path(__file__).resolve().parent
OLD=Path(r'D:\ClaudeFiles\mcpe_route_isolation_20261029')
D=Path(r'D:\科研王！\MCPE\1.0\part12\Part1补充模式诊断_20261028\路径隔离实验_20261029')
r=json.loads((B/'budget_audit_results.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
header='''> **2026-10-29 收支审查更新：下文路径细分为人工边干预下的谱差分摊，部分干预不保持原来的陆海交换配对与沉积碳—碱度 1:2 关系。细分百分比不能作为收支保持下的物理贡献写入论文机理结论。完整 c24 开/关的总体敏感性对照、沉积两端同时动态/恒定的总体对照需与这些单边干预分开解释。数值重复性与分摊加和不等于物理收支闭合。详见同目录《收支审查说明.md》。**

'''
reports=[]
for p in [OLD/'贡献分解结果.md',D/'贡献分解结果.md']:
 text=p.read_text(encoding='utf-8')
 if not (B/'贡献分解结果_审查前.md').exists():shutil.copy2(p,B/'贡献分解结果_审查前.md')
 if not text.startswith('> **2026-10-29 收支审查更新'):
  p.write_text(header+text,encoding='utf-8')
 reports.append({'path':str(p),'sha256':sha(p)})
q=r['summary']['macro']['0'];s=r['summary']['sediment']
note=f'''# 路径隔离实验的收支审查说明

## 审查结论

刚才的隔离实验没有全部保持原有物理收支配对。先前检验的是方程实现一致、完整组复现、全出口隔离后的参考状态一致、分摊加和与置换计算一致；这些都不能替代物理预算检验。细分通路的谱差分摊仍是有效的指定人工干预结果，但不能解读为保持原收支关系时的物理过程份额。

## 陆海交换的配对

原模式同一个 F15=c15*x1*(TL−w) 在上层海洋方程中为 +F15，在陆地方程中为 −F15，因此在模型加权温度量 om*w+olm*TL 的倾向中严格相消。这个量只是模型内的加权温度量，不是全系统物理能量不变量。

之前的 O 路径关闭组只把海洋端换成 c15*x1*(TL_ref−w)，陆地端仍为 −c15*x1*(TL−w)。配对和变成额外项 qH=c15*x1*(TL_ref−TL)，一般不为零。因此这些分支改变了原来的交换配对。

## 碳与碱度

原模式是有外部排放和未显式建库的碳汇的开放系统，其原方程满足：

    d(Catm+Cocn)/dt = E−F_land−F_convection−F_export−Bcal
    dALK/dt = c25−2 Bcal

海气交换 Fas 在 Catm 与 Cocn 方程间相消。这不是声称两个显式碳库的总碳恒定；预算闭合要求状态变化等于累计净源汇。

在 C 路径关闭组，若仍按本分支实际 TL 计算原 F_land、F_convection，会多出 qC=(c20*Catm+c21*x1)*(TL−TL_ref)。可以用改写后的外部碳汇或显式控制项做完整记账，但那是人工控制系统的预算，不是原碳汇定律保持不变。

沉积两端必须共享同一 Bcal 才保持每移除一份碳对应移除两份碱度。单边干预时，Cocn 收到 B_N，而 ALK 收到 2 B_K，则

    d(ALK−2 Cocn)/dt = c25−2 Fas+2 F_export+2(B_N−B_K)

最后一项一般非零。S0（两端均恒定）与 S3（两端均动态）保留该配对；S1、S2（只替换一端）不保留。因此不能把 S1/S2 支持的分摊叫作碳—碱度反应配对保持下的过程贡献。

## 已保存样本中的核查量级

以下为 200000 TU 记录、每 1 TU 保存样本上的代数额外项统计；不是原生 0.01 TU 的积分预算残差，也不以样本梯形积分冒充原生 RK4 通量累计闭合。

- 宏观全部 TL 出口隔离组 R0：qH 的10组初态 RMS 平均为 {q['heat_pair_extra']['mean_of_IC_rms']:.6g}，样本绝对最大值 {q['heat_pair_extra']['maximum_sampled_absolute']:.6g}；不是舍入误差。
- 同一组 qC 的10组 RMS 平均为 {q['carbon_original_flux_law_extra']['mean_of_IC_rms']:.6g}。
- 沉积 S1、S2 的 2(B_N−B_K) RMS 平均分别为 {s['1']['ALK_minus_2Cocn_extra']['mean_of_IC_rms']:.6g}、{s['2']['ALK_minus_2Cocn_extra']['mean_of_IC_rms']:.6g}，保存样本绝对最大值均为 0.0018。
- 完整 R7 的这些人工额外项为零；S0、S3 的沉积计量差额为零。

## 哪些结论可保留

- 完整 c24 开启与关闭使用同样配对的交换式，其总体谱差可作为条件模型敏感性保留。原 R0 的海洋谱又与 c24 关闭参考严格相同，因此 +4.71% 的 η 频带总体比较有未改配对参考支撑。
- 沉积在两方程中同时动态、同时恒定的总体比较保留原 1:2 关系；它检验的是动态沉积反馈相对平衡恒定移除的差别。
- x1、x2、直接海洋、碳返回的细分百分比只保留为人工边干预分解，不用作“已查清物理贡献”的证据。沉积 Cocn/ALK 单边分摊也一样。
- 若进一步做收支一致的物理归因，内部交换必须在两端同步替换同一通量，沉积两端必须使用同一 Bcal；对原模型不存在成对守恒定义的大气代理变量耦合，应明确其控制项及原方程层面的含义，不能凭补记账就宣称全系统物理能量守恒。

## 与旧预算图的区别

2026-10-28 原始自由模式的独立碳/碱度核查曾按原生 RK4 四阶段累计通量，25 条20000 TU分支的累计预算残差最大约 6.57e-12、5.52e-11。那是原模式对应分支的源汇数值闭合，不是本次所有路径隔离分支的守恒证明，也不是完整地球系统所有碳库和物理能量的守恒证明。

本次审查在 Levante yuki、ab0246 下运行，作业 28542722。原始审查结果为 D:\\ClaudeFiles\\mcpe_budget_audit_20261029\\budget_audit_results.json。未改论文、原始曲线、图件或旧计算结果；在当前贡献说明顶部增加了收支限制提示。
'''
(B/'收支审查说明.md').write_text(note,encoding='utf-8')
shutil.copy2(B/'收支审查说明.md',D/'收支审查说明.md')
shutil.copy2(B/'budget_audit_results.json',D/'budget_audit_results.json')
log=Path(r'D:\ClaudeFiles\运行记录\2026-10-29-MCPE路径隔离收支审查.md')
log.write_text(note,encoding='utf-8')
manifest=json.loads((OLD/'figure_manifest.json').read_text())
for z in manifest['files']:assert sha(D/z['name'])==z['sha256']
extra=json.loads((OLD/'extra_figure_manifest.json').read_text());assert sha(D/extra['filename'])==extra['sha256']
receipt={'reviewed_at':datetime.now().astimezone().isoformat(),'report':str(D/'收支审查说明.md'),
 'updated_reports':reports,'figures_preserved':True,'manuscripts_modified':False,'scope':'Saved-sample algebraic paired-flux audit; no new integrated native-step budget claim'}
(B/'review_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False,indent=2))

from pathlib import Path
import json,hashlib
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent;P=B.parent/'w_feedback_20261029'
cfg=json.loads((B/'configuration.json').read_text())
assert json.loads((P/'completion.json').read_text())['count']==80
assert float(np.loadtxt(P/'identity/identity.txt'))==0
welch=cfg['welch'];bands={'low':(.5,.75),'wider':(.5,.8),'display':(.5,1.5)}
rng=np.random.default_rng(20261029);boot=rng.integers(0,10,size=(19999,10))
def stats(v):
 v=np.asarray(v,float);assert v.shape==(10,)
 return {'mean':float(v.mean()),'ci95':np.percentile(v[boot].mean(1),[2.5,97.5]).tolist(),
 'positive_initial_conditions':int((v>0).sum()),'negative_initial_conditions':int((v<0).sum()),'by_initial_condition':v.tolist()}
def bins(f,lo,hi):return (f>=lo-1e-10)&(f<=hi+1e-10)
def metric(a):
 a=np.asarray(a,float)
 f,p=signal.welch(a,**welch);df=f[1]-f[0];fd=f*100;pd=p/100
 out={'variance':float(np.var(a)),'welch_total':float(np.sum(p)*df)}
 peakmask=bins(fd,.5,1.5);idx=np.flatnonzero(peakmask);kp=idx[np.argmax(p[idx])]
 out.update({'peak_frequency':float(fd[kp]),'peak_power':float(pd[kp]),
 'peak_at_search_boundary':bool(kp in [idx[0],idx[-1]]),
 'peak_is_local_in_full_spectrum':bool(kp>0 and kp<len(p)-1 and p[kp]>p[kp-1] and p[kp]>p[kp+1]),
 'global_max_frequency':float(fd[np.argmax(p)])})
 # Independent exact check of the one-sided Welch power normalization.
 segments=np.lib.stride_tricks.sliding_window_view(a,2500)[::1250]
 win=signal.get_window('hann',2500)
 actual=np.mean(np.sum((segments-segments.mean(1)[:,None])**2*win**2,axis=1)/np.sum(win**2))
 assert np.isclose(out['welch_total'],actual,rtol=1e-11,atol=1e-12)
 fp,pp=signal.periodogram(a,fs=1,window='boxcar',detrend='constant',scaling='density')
 dpf=fp[1]-fp[0];totalp=float(pp.sum()*dpf)
 assert np.isclose(totalp,out['variance'],rtol=1e-11,atol=1e-12)
 out['periodogram_total']=totalp
 for key,(lo,hi) in bands.items():
  pb=float(p[bins(fd,lo,hi)].sum()*df)
  out[key+'_power']=pb;out[key+'_fraction']=pb/out['welch_total']
  pbp=float(pp[bins(fp*100,lo,hi)].sum()*dpf)
  out['periodogram_'+key+'_power']=pbp;out['periodogram_'+key+'_fraction']=pbp/totalp
 return out,{'frequency':fd.tolist(),'psd':pd.tolist()}
legacy={}
for label,n in [('seven',7),('full',10)]:
 a=np.loadtxt(B/f'eta{n}.txt');assert len(a)==10001 and np.all(np.diff(a[:,0])==1)
 mm,ss=metric(a[:,1]);legacy[label]={'metrics':mm,'spectrum':ss}
legacy['relative_changes']={k:100*(legacy['full']['metrics'][k]/legacy['seven']['metrics'][k]-1) for k in ['variance','low_power','low_fraction','display_power','display_fraction']}
legacy['peak_shift']=legacy['full']['metrics']['peak_frequency']-legacy['seven']['metrics']['peak_frequency']
data={};curves={};sources=[]
for label,tag in [('seven','M0'),('full','M7'),('c24_off','M3'),('mean','mean'),('anomaly','anomaly')]:
 data[label]=[];psds=[]
 for seed in range(10):
  d=P/'data'/f'{tag}_seed{seed}';p=d/'states.bin';assert p.stat().st_size==200001*7*8
  receipt=json.loads((d/'receipt.json').read_text())
  assert receipt['c28']==1
  h=hashlib.sha256(p.read_bytes()).hexdigest();assert h==receipt['states_sha256']
  sources.append({'label':label,'seed':seed,'data':str(p),'sha256':h,'c28':receipt['c28']})
  a=np.memmap(p,dtype='<f8',mode='r',shape=(200001,7));rows=[];sp=[]
  for j in range(20):
   mm,ss=metric(a[j*10000+1:(j+1)*10000+1,3]);rows.append(mm);sp.append(ss['psd'])
  avg={k:float(np.mean([z[k] for z in rows])) for k in rows[0]}
  # Aggregate shares from the same aggregate spectrum, not an average of ratios.
  for key in bands:
   avg[key+'_fraction']=avg[key+'_power']/avg['welch_total']
   avg['periodogram_'+key+'_fraction']=avg['periodogram_'+key+'_power']/avg['periodogram_total']
  data[label].append({'windows':rows,'aggregate':avg})
  psds.append(np.mean(sp,axis=0))
 curves[label]={'frequency':ss['frequency'],'mean_psd':np.mean(psds,axis=0).tolist(),
  'mean_normalized_psd':np.mean([p/data[label][i]['aggregate']['welch_total'] for i,p in enumerate(psds)],axis=0).tolist(),
  'seed_psds':[p.tolist() for p in psds]}

def compare(left,right,window_slice=None):
 def agg(label,s):
  if window_slice is None:return data[label][s]['aggregate']
  rows=data[label][s]['windows'][window_slice]
  a={k:float(np.mean([z[k] for z in rows])) for k in rows[0]}
  for key in bands:
   a[key+'_fraction']=a[key+'_power']/a['welch_total']
   a['periodogram_'+key+'_fraction']=a['periodogram_'+key+'_power']/a['periodogram_total']
  return a
 out={}
 for key in ['variance','welch_total']+[k+s for k in bands for s in ['_power','_fraction']]+['periodogram_'+k+s for k in bands for s in ['_power','_fraction']]:
  out[key]=stats([100*(agg(left,s)[key]/agg(right,s)[key]-1) for s in range(10)])
 shifts=[agg(left,s)['peak_frequency']-agg(right,s)['peak_frequency'] for s in range(10)]
 out['mean_peak_shift']=stats(shifts)
 ci=out['mean_peak_shift']['ci95'];out['mean_peak_shift_CI_within_one_bin']=bool(ci[0]>-.04 and ci[1]<.04)
 pairs=[(data[left][s]['windows'][j],data[right][s]['windows'][j]) for s in range(10) for j in range(20)]
 delta=np.array([a['peak_frequency']-b['peak_frequency'] for a,b in pairs])
 out['paired_window_peak_shift']={'same_bin_count':int((abs(delta)<1e-8).sum()),
  'within_one_bin_count':int((abs(delta)<=.04000001).sum()),'count':200,'mean':float(delta.mean()),
  'shifts':delta.tolist(),'warning':'Window counts descriptive; uncertainty resamples initial-condition units only.'}
 out['paired_window_low_power_higher_count']=sum(a['low_power']>b['low_power'] for a,b in pairs)
 out['paired_window_low_fraction_higher_count']=sum(a['low_fraction']>b['low_fraction'] for a,b in pairs)
 out['paired_window_variance_higher_count']=sum(a['variance']>b['variance'] for a,b in pairs)
 for label in [left,right]:
  out[label+'_boundary_peak_count']=sum(data[label][s]['windows'][j]['peak_at_search_boundary'] for s in range(10) for j in range(20))
  out[label+'_local_peak_count']=sum(data[label][s]['windows'][j]['peak_is_local_in_full_spectrum'] for s in range(10) for j in range(20))
 return out
comparison=compare('full','seven')
feedback={label:compare(label,'c24_off') for label in ['full','mean','anomaly']}
halves={'early':compare('full','seven',slice(0,10)),'late':compare('full','seven',slice(10,20))}
means={label:{k:float(np.mean([z['aggregate'][k] for z in rows])) for k in rows[0]['aggregate']} for label,rows in data.items()}
summary={'configuration':cfg,'legacy_window':{'seven':legacy['seven']['metrics'],'full':legacy['full']['metrics'],
 'relative_changes':legacy['relative_changes'],'peak_shift':legacy['peak_shift']},'comparison':comparison,'feedback':feedback,
 'early_late':halves,'absolute_aggregates':means,'native_budget':json.loads((B/'native_budget_results.json').read_text())}
result={'summary':summary,'data':data,'curves':curves,'legacy':legacy,'sources':sources}
(B/'eta_test_results.json').write_text(json.dumps(result,indent=2))
(B/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'comparison':{k:comparison[k] for k in ['low_power','low_fraction','variance','mean_peak_shift']},
 'feedback_low_power':{k:v['low_power'] for k,v in feedback.items()},'legacy':summary['legacy_window']},indent=2),flush=True)

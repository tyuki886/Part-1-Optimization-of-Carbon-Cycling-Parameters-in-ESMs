program native_budget_check
 use RKmethod
 implicit none
 integer(kind=8)::i
 integer::seed,kind,u,j
 real(dp)::x(18),begin(4),actual(4),totals(4),correction(4),increment(4),mx(4),ref,stage_error
 real(dp)::tmp(18),k1(10),k2(10),k3(10),k4(10),f1(4),f2(4),f3(4),f4(4),z(4),next(4),row
 character(len=80)::arg
 call get_command_argument(1,arg);read(arg,*)seed
 call get_command_argument(2,arg);read(arg,*)kind
 call get_command_argument(3,arg);read(arg,*)ref
 x=0.0_dp;x(2)=1.0_dp+.001_dp*seed
 do i=1,1000000_8
  call adv_true_state(x,i,10)
 enddo
 begin=[x(8),x(9),x(10),om*x(4)+olm*x(7)]
 totals=0.0_dp;correction=0.0_dp;mx=0.0_dp;stage_error=0.0_dp
 open(newunit=u,file='eta_check.bin',access='stream',form='unformatted',status='new')
 write(u)x(5)
 do i=1,2000000_8
  k1=derivs(x,i,10);f1=flux(x,i);call compare(k1,f1)
  tmp=x;tmp(1:10)=x(1:10)+.5*.01_dp*k1;k2=derivs(tmp,i,10);f2=flux(tmp,i);call compare(k2,f2)
  tmp=x;tmp(1:10)=x(1:10)+.5*.01_dp*k2;k3=derivs(tmp,i,10);f3=flux(tmp,i);call compare(k3,f3)
  tmp=x;tmp(1:10)=x(1:10)+.01_dp*k3;k4=derivs(tmp,i,10);f4=flux(tmp,i);call compare(k4,f4)
  increment=(.01_dp/6.0_dp)*(f1+2.0_dp*f2+2.0_dp*f3+f4)
  z=increment-correction;next=totals+z;correction=(next-totals)-z;totals=next
  call adv_true_state(x,i,10)
  actual=[x(8),x(9),x(10),om*x(4)+olm*x(7)]-begin
  mx=max(mx,abs(actual-totals))
  if(mod(i,100_8)==0)write(u)x(5)
 enddo
 close(u)
 open(newunit=u,file='budget.txt',status='new')
 write(u,*)mx
 write(u,*)stage_error
 write(u,*)actual
 write(u,*)totals
 close(u)
contains
 function flux(s,it) result(f)
  real(dp),intent(in)::s(18)
  integer(kind=8),intent(in)::it
  real(dp)::f(4),fas,fl,fc,fe,bc,pco,smadd,sladd,pi
  pi=3.141592653589793_dp
  pco=max(c29*s(9)-c30*s(10),0.0_dp)
  fas=c18*(1.0-c19*s(4))*(s(8)-pco)
  fl=c20*s(8)*s(7);fc=c21*s(1)*(s(7)-s(4));fe=c22*(1.0-c23*s(4))*s(5)
  bc=c26*rrain*s(9)*max(s(10)-c27*s(9)+c28,0.0_dp)
  smadd=sm*(1.0+c17*s(8));sladd=slm*(1.0+c24*s(8))
  if(kind==0)smadd=sm
  if(kind==0.or.kind==3)sladd=slm
  if(kind==11)sladd=slm*(1.0+c24*ref)
  if(kind==12)sladd=slm*(1.0+c24*(s(8)-ref))
  f(1)=E_rate-fas-fl-fc;f(2)=fas-fe-bc;f(3)=c25-2.0_dp*bc
  f(4)=c2*s(2)+c3*s(5)+c4*s(4)*s(5)-od*s(4)-c7*s(15)+smadd+ss*cos(2.0*pi*it*.01/spd) &
   +c12*s(2)-old*s(7)+sladd+sls*cos(2.0*pi*it*.01/spd)
 end function
 subroutine compare(k,f)
  real(dp),intent(in)::k(10),f(4)
  stage_error=max(stage_error,maxval(abs([k(8),k(9),k(10),om*k(4)+olm*k(7)]-f)))
 end subroutine
end program

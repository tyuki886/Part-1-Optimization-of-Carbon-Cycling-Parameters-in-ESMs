from pathlib import Path
import subprocess,concurrent.futures,json,hashlib,time
import numpy as np
B=Path(__file__).resolve().parent
OLD=B.parent/'w_feedback_20261029'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(B/'budget_builds').mkdir();(B/'budget_checks').mkdir()
cases=[];builds={}
for seed in range(10):
 for label,kind in [('seven',0),('full',7),('c24_off',3),('mean',11),('anomaly',12)]:
  if label in ['mean','anomaly']:
   source=OLD/'data'/f'{label}_seed{seed}'/'RKmethod.f90'
   receipt=json.loads((source.parent/'receipt.json').read_text());ref=receipt['fixed_reference_Catm']
   assert sha(source)==receipt['source_sha256']
  else:source=OLD/'builds'/f'M{kind}'/'RKmethod.f90';ref=0.
  s=source.read_text();assert 'c28=1.0_dp' in s
  # All paired internal exchange and sediment terms must remain untouched.
  assert s.count('c15*s(1)*(s(7)-s(4))')==2
  assert 'ds(9)=c18*(1.0-c19*s(4))*(s(8)-pCO2_oc)-c22*(1.0-c23*s(4))*s(5)-Bcal' in s
  assert 'ds(10)=c25-2.0_dp*Bcal' in s
  key=sha(source)
  if key not in builds:
   d=B/'budget_builds'/key[:12];d.mkdir();(d/'RKmethod.f90').write_text(s)
   subprocess.run(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90',str(B/'budget.f90'),'-o','budget_check'],cwd=d,check=True)
   builds[key]=d/'budget_check'
  cases.append((label,kind,seed,ref,source,builds[key]))
def run(case):
 label,kind,seed,ref,source,binary=case
 d=B/'budget_checks'/f'{label}_{seed}';d.mkdir()
 with (d/'run.log').open('w') as log:subprocess.run([str(binary),str(seed),str(kind),format(ref,'.17g')],cwd=d,check=True,stdout=log,stderr=subprocess.STDOUT)
 lines=(d/'budget.txt').read_text().splitlines();mx=[float(v) for v in lines[0].split()];stage=float(lines[1])
 assert max(mx)<1e-8 and stage<1e-10,(label,seed,mx,stage)
 p=OLD/'data'/(f'M{kind}_seed{seed}' if kind in [0,3,7] else f'{label}_seed{seed}')/'states.bin'
 old=np.memmap(p,dtype='<f8',mode='r',shape=(200001,7))
 check=np.fromfile(d/'eta_check.bin',dtype='<f8');assert check.shape==(20001,)
 difference=float(np.max(abs(check-old[:20001,3])));assert difference==0,(label,seed,difference)
 row={'label':label,'seed':seed,'source_sha256':sha(source),'max_native_cumulative_residual_Catm_Cocn_ALK_weighted_temperature':mx,
  'independent_flux_rhs_max_abs':stage,'eta_matches_production_max_abs':difference,'window_TU':[0,20000]}
 (d/'receipt.json').write_text(json.dumps(row,indent=2));return row
t=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,cases))
out={'checks':rows,'count':50,'max_residual_by_budget':np.max([r['max_native_cumulative_residual_Catm_Cocn_ALK_weighted_temperature'] for r in rows],axis=0).tolist(),
 'max_independent_flux_rhs_difference':max(r['independent_flux_rhs_max_abs'] for r in rows),
 'all_eta_trajectories_reproduce_production':True,'exchange_and_sediment_pairing_preserved':True,
 'scope':'Native RK4 source/flux integration over first 20000 postspinup TU; not an integrated audit of the full 200000 TU production record or a complete ESM energy-conservation proof.',
 'seconds':time.time()-t}
(B/'native_budget_results.json').write_text(json.dumps(out,indent=2));print('NATIVE_BUDGET_PASS',out['max_residual_by_budget'],flush=True)

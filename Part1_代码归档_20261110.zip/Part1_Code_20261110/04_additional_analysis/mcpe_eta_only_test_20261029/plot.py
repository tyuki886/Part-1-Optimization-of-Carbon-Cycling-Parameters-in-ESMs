from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
B=Path(__file__).resolve().parent
r=json.loads((B/'eta_test_results.json').read_text());s=r['summary']
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9.5,
 'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
 'axes.linewidth':.75,'path.simplify':False})
blue='#24578D';red='#C6324B';gray='#777777';gold='#B77A22'
manifest={'font':'Times New Roman; STIX math','dpi':600,'variable':'eta only','figures':[],
 'source':'eta_test_results.json','uncertainty':'Pointwise 95% paired initial-condition bootstrap, 19999 resamples, ten units each averaging twenty consecutive windows',
 'power_band_decade_inverse':[.5,.75],
 'baseline_warning':'Archive panel is descriptive; long-record controls use the current all-feedback-off seven-variable-equivalent baseline.',
 'normalization':'Normalized curves use each initial condition complete one-sided Welch spectral power from 0 to 50 decade^-1, before averaging conditions. Displayed curves cover 0.5–1.5 only.',
 'native_budget':'All source families keep paired exchange and shared Bcal; fifty source/initial-condition short audits use native RK4 flux integration over 20000 TU. This is not a complete ESM energy-invariant claim.',
 'manuscripts_modified':False}
def save(fig,name,description):
 for suffix,dpi in [('',600),('_preview',160)]:fig.savefig(B/(name+suffix+'.png'),dpi=dpi,bbox_inches='tight',pad_inches=.07)
 manifest['figures'].append({'file':name+'.png','sha256':hashlib.sha256((B/(name+'.png')).read_bytes()).hexdigest(),'description':description})
 plt.close(fig)
def spectral_axes(ax):
 ax.set_xlim(.5,1.5);ax.set_ylim(bottom=0);ax.grid(color='#eeeeee',lw=.55);ax.set_axisbelow(True)
 ax.axvspan(.5,.75,color=gold,alpha=.09,lw=0)
 ax.set_xlabel('Frequency (Decade$^{-1}$)')
def intervals(ax,x,rows,c,marker,label,filled=True):
 v=np.array([z['mean'] for z in rows]);ci=np.array([z['ci95'] for z in rows])
 ax.errorbar(x,v,yerr=[v-ci[:,0],ci[:,1]-v],fmt=marker,c=c,mfc=c if filled else 'white',
  ms=4,capsize=3,lw=.9,label=label,zorder=4)

fig,axs=plt.subplots(2,2,figsize=(8.8,6.5));axs=axs.ravel()
for label,c,ls,desc in [('seven',blue,'--','Seven-variable'),('full',red,'-','10VCC')]:
 sp=r['legacy'][label]['spectrum'];f=np.array(sp['frequency']);p=np.array(sp['psd']);keep=(f>=.5)&(f<=1.5)
 axs[0].plot(f[keep],p[keep],c=c,ls=ls,lw=1.15,label=desc)
 kp=r['legacy'][label]['metrics']['peak_frequency'];pv=r['legacy'][label]['metrics']['peak_power']
 axs[0].plot(kp,pv,'o',c=c,ms=3)
axs[0].axvline(.56,c='#999999',ls=':',lw=.8)
axs[0].text(.575,axs[0].get_ylim()[1]*.9,'0.56 decade$^{-1}$',fontsize=8)
axs[0].set_title('(a) Archived comparison window',pad=6);axs[0].set_ylabel('PSD');spectral_axes(axs[0])
axs[0].legend(frameon=False,loc='upper right')
for label,c,ls in [('seven',blue,'--'),('full',red,'-')]:
 sp=r['curves'][label];f=np.array(sp['frequency']);keep=(f>=.5)&(f<=1.5)
 axs[1].plot(f[keep],np.array(sp['mean_psd'])[keep],c=c,ls=ls,lw=1.15)
 axs[2].plot(f[keep],np.array(sp['mean_normalized_psd'])[keep],c=c,ls=ls,lw=1.15)
axs[1].set_title('(b) Consistent-baseline long-record mean',pad=6);axs[1].set_ylabel('PSD');spectral_axes(axs[1])
axs[2].set_title('(c) Normalized long-record spectrum',pad=6);axs[2].set_ylabel('PSD / complete spectral power');spectral_axes(axs[2])
x=np.array([0,1])
intervals(axs[3],x-.10,[s['comparison'][k] for k in ['low_power','low_fraction']],'#222222','o','Welch')
intervals(axs[3],x+.10,[s['comparison'][k] for k in ['periodogram_low_power','periodogram_low_fraction']],gray,'D','Full-record periodogram',False)
intervals(axs[3],np.array([2]),[s['comparison']['variance']],gold,'*','Direct variance')
axs[3].set_xticks([0,1,2],['Low-band\npower','Low-band\nfraction','Total\nvariance'])
axs[3].set_ylabel('Relative change from seven-variable (%)');axs[3].axhline(0,c='#333333',lw=.75)
axs[3].grid(axis='y',color='#eeeeee',lw=.55);axs[3].set_axisbelow(True)
axs[3].set_title('(d) Paired long-record changes',pad=6);axs[3].legend(frameon=False,fontsize=7,loc='upper right')
lo,hi=axs[3].get_ylim();axs[3].set_ylim(lo-(hi-lo)*.05,hi+(hi-lo)*.35)
fig.suptitle(r'$\eta$: spectral peak position and low-frequency power',fontsize=12.5,y=.98)
fig.subplots_adjust(left=.10,right=.985,bottom=.09,top=.88,hspace=.45,wspace=.35)
save(fig,'Eta_spectral_test',{
 'a':'Archived 10000–20000 TU eta-only record; matching displayed-band maxima at 0.56 decade^-1. Shading: exploratory low band 0.5–0.75 decade^-1.',
 'b':'Current-baseline mean of spectra, first over twenty 10000-TU windows within each initial condition, then over ten initial conditions. Curves are not spectra of an averaged time series.',
 'c':'Mean of complete-power-normalized current-baseline spectra. Normalization uses all frequencies, not only the displayed range.',
 'd':'Paired relative changes in low-band absolute power, its complete-spectrum fraction, and direct total variance. Both Welch and full-record periodogram are shown; a fraction change is a relative percent change, not percentage points.'})

fig,axs=plt.subplots(1,2,figsize=(8.8,3.8))
delta=s['comparison']['mean_peak_shift'];v=np.array(delta['by_initial_condition'])
axs[0].axhline(0,c='#333333',lw=.75)
axs[0].axhline(.04,c=gray,ls='--',lw=.9,label='One frequency bin')
axs[0].axhline(-.04,c=gray,ls='--',lw=.9)
axs[0].plot(np.arange(10),v,'o',c='#222222',ms=4,label='Initial-condition mean shift')
axs[0].axhspan(delta['ci95'][0],delta['ci95'][1],color=red,alpha=.12,lw=0,label='95% interval of mean shift')
axs[0].axhline(delta['mean'],c=red,lw=1)
axs[0].set_xticks(np.arange(10));axs[0].set_xlim(-.6,9.6)
axs[0].set_xlabel('Initial condition');axs[0].set_ylabel('Mean peak-frequency shift (Decade$^{-1}$)')
axs[0].set_title('(a) Displayed-band peak position',pad=6)
axs[0].legend(frameon=False,fontsize=7,loc='upper left');axs[0].set_ylim(-.05,.075)
axs[0].grid(axis='y',color='#eeeeee',lw=.55);axs[0].set_axisbelow(True)
x=np.arange(3)
intervals(axs[1],x-.1,[s['feedback'][k]['low_power'] for k in ['full','mean','anomaly']],'#222222','o','Welch')
intervals(axs[1],x+.1,[s['feedback'][k]['periodogram_low_power'] for k in ['full','mean','anomaly']],gray,'D','Full-record periodogram',False)
axs[1].set_xticks(x,['Full','Fixed reference\nmean','Reference\nanomaly'])
axs[1].set_ylabel(r'Low-band power change from no $c_{24}$ (%)')
axs[1].set_title(r'(b) Complete $c_{24}$ forcing controls',pad=6)
axs[1].axhline(0,c='#333333',lw=.75);axs[1].grid(axis='y',color='#eeeeee',lw=.55);axs[1].set_axisbelow(True)
axs[1].legend(frameon=False,fontsize=7,loc='upper right')
lo,hi=axs[1].get_ylim();axs[1].set_ylim(lo-(hi-lo)*.05,hi+(hi-lo)*.25)
fig.suptitle(r'$\eta$: frequency stability and complete-feedback tests',fontsize=12.5,y=.98)
fig.subplots_adjust(left=.10,right=.985,bottom=.17,top=.79,wspace=.36)
save(fig,'Eta_feedback_test',{
 'a':'Each black point averages twenty displayed-band maximum-frequency shifts for one initial condition. The red band is the paired initial-condition bootstrap interval for the mean shift. Dashed bounds are the 0.04 decade^-1 Welch bin width; this is not a red-noise significance test.',
 'b':'Eta low-band power under full c24, fixed reference-mean c24 input, or fixed-reference anomaly c24 input, relative to c24 off with other feedbacks dynamic. Internal exchange and sediment pairs are unmodified. Mean and anomaly interventions are not additive.'})
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
print('ETA_FIGURES_COMPLETE',flush=True)

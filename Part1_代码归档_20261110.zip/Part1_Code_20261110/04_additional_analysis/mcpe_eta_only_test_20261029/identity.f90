program identity_check
 use RKmethod, only: dp,adv_original=>adv_true_state
 use Off_reference, only: adv_off=>adv_true_state
 implicit none
 real(dp)::x(18),y(18),maxdiff
 integer(kind=8)::i
 x=0._dp;y=0._dp;x(2)=1._dp;y(2)=1._dp;maxdiff=0._dp
 do i=1,3000000_8
   call adv_original(x,i,7)
   call adv_off(y,i,10)
   maxdiff=max(maxdiff,maxval(abs(x(1:7)-y(1:7))),abs(x(15)-y(15)))
 enddo
 if(maxdiff/=0._dp)error stop 'feedback-off water-state mismatch'
 open(11,file='identity.txt',status='new');write(11,*)maxdiff;close(11)
 print *,'IDENTITY_MAX',maxdiff
end program

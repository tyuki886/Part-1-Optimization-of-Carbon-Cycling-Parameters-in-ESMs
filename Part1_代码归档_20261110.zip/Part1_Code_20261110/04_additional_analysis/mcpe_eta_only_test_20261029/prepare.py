from pathlib import Path
import json,shutil,hashlib
B=Path(__file__).resolve().parent
P=Path(r'D:\ClaudeFiles\mcpe_w_feedback_20261029')
sources=[]
for n in ['times.ttf','eta7.txt','eta10.txt','identity.f90','RKmethod_reference.f90','same_source_driver_audit.json']:
 shutil.copy2(P/n,B/n);sources.append({'source':str(P/n),'copy':n,'sha256':hashlib.sha256((B/n).read_bytes()).hexdigest()})
cfg={'variable':'eta only','c28':1,'new_integrations':'No new production integrations; reuse full, all-feedback-off, c24-off, fixed mean, fixed-reference anomaly controls. Native budget verification is a separate shortened audit.',
 'primary_band_decade_inverse':[.5,.75],'band_selection':'Exploratory band selected from user-provided figure before examining this test output',
 'sensitivity_bands_decade_inverse':[[.5,.8],[.5,1.5]],'peak_search_band_decade_inverse':[.5,1.5],
 'frequency_conversion':'f_decade_inverse = 100 * f_TU_inverse; density_decade = density_TU / 100',
 'sampling_TU':1,'postspinup_TU':200000,'windows':20,'window_length_TU':10000,'initial_conditions':10,
 'welch':{'fs':1,'window':'hann','nperseg':2500,'noverlap':1250,'detrend':'constant','scaling':'density'},
 'power_definition':'Sum PSD bins selected by their centre frequency, times the native frequency increment. Complete estimated spectral power sums all one-sided bins up to Nyquist; normalized spectral bins sum to one under the same rule.',
 'normalization_warning':'Total Welch power is a tapered segment-demeaned estimate; direct full-window population variance is reported separately and not assumed numerically identical.',
 'periodogram_check':'Mean-removed full-record boxcar periodogram; verify Parseval against direct full-window variance and repeat band statistics',
 'uncertainty':'Exploratory pointwise paired bootstrap, 19999 resamples of ten initial-condition units, each first averaging twenty windows; no independent-window bootstrap',
 'peak_warning':'Displayed-band spectral maximum, not a red-noise significance test or a uniquely identified intrinsic oscillation. Assess boundary maxima explicitly.',
 'peak_resolution_decade_inverse':.04,'equivalence_margin':'One native Welch frequency bin (.04 decade^-1), evaluated for mean displayed-band peak shift, not proof of exact equality',
 'archive_warning':'Old seven-variable archive is not pointwise reproduced on current build. Archive panel is descriptive only; causal and long-record comparisons use current all-feedback-off baseline verified equivalent to seven-variable equations.',
 'controls':{'seven':'M0: carbon feedbacks off, current-platform verified seven-variable water core','full':'M7: full 10VCC','c24_off':'M3: c16/c17 active, c24 off','mean':'Replace only carbon input inside c24 with same-seed fixed reference mean','anomaly':'Replace only carbon input inside c24 with departure from same-seed fixed reference mean'},
 'native_budget_audit':{'spinup_TU':10000,'postspinup_TU':20000,'step_TU':.01,'states':'Catm,Cocn,ALK, and model weighted land-ocean temperature, not a complete ESM energy invariant','method':'Independent flux formulas at all four RK4 stages; compensated accumulation; original source advancer drives actual states'},
 'manuscripts_modified':False}
(B/'configuration.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
(B/'source_manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
print('η专用检验配置已固定。')

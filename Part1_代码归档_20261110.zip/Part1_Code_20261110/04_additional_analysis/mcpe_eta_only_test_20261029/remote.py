from pathlib import Path
import sys,shlex,json,re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_only_test_20261029'
c=hpc.connect()
try:
 mode=sys.argv[1]
 if mode=='submit':
  with c.open_sftp() as s:
   try:s.stat(R);raise RuntimeError('η独立检验目录已存在')
   except FileNotFoundError:s.mkdir(R)
   for name in ['native_audit.py','analyze.py','budget.f90','configuration.json','source_manifest.json','times.ttf','eta7.txt','eta10.txt']:
    s.put(str(B/name),R+'/'+name)
  wrap='export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python native_audit.py && /home/b/b382207/conda/envs/yuki/bin/python analyze.py'
  cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=4 --mem=8G --time=00:20:00 --job-name=eta_only_test --output=test-%j.log --wrap='+shlex.quote(wrap)
  rc,out,err=hpc.run(c,cmd)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
 elif mode=='status':
  job=json.loads((B/'submission.json').read_text())['job']
  rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -8 '+shlex.quote(R+'/test-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/summary.json')+' && echo TEST_COMPLETE')
  print(out)
 elif mode=='fetch':
  with c.open_sftp() as s:
   for name in ['summary.json','eta_test_results.json','native_budget_results.json']:s.get(R+'/'+name,str(B/name))
  print('η检验结果已下载。')
 elif mode=='plot':
  with c.open_sftp() as s:s.put(str(B/'plot.py'),R+'/plot.py')
  wrap='/home/b/b382207/conda/envs/yuki/bin/python plot.py'
  cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=4G --time=00:05:00 --job-name=eta_only_plot --output=plot-%j.log --wrap='+shlex.quote(wrap)
  rc,out,err=hpc.run(c,cmd)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'plot_submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
 elif mode=='plot-status':
  job=json.loads((B/'plot_submission.json').read_text())['job']
  rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -5 '+shlex.quote(R+'/plot-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/figure_manifest.json')+' && echo PLOT_COMPLETE')
  print(out)
 elif mode=='fetch-plot':
  with c.open_sftp() as s:
   for name in ['Eta_spectral_test.png','Eta_spectral_test_preview.png','Eta_feedback_test.png','Eta_feedback_test_preview.png','figure_manifest.json']:s.get(R+'/'+name,str(B/name))
  print('η图件已下载。')
finally:c.close()

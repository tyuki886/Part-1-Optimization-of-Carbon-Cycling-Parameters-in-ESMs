from pathlib import Path
import hashlib,json,shutil
B=Path(__file__).resolve().parent
S=Path(r'D:\ClaudeFiles\项目2-Levante超算\MCPE26.0_C81\paper_revision_20260915\c28_corrected_comparison')
manifest=[]
for model in [7,10]:
    for kind,name in [('w',f'wTL_{model}var.txt'),('eta','eta_7var.txt' if model==7 else 'etaCatm_10var.txt')]:
        src=S/f'run{model}'/name
        dest=B/f'{kind}{model}.txt'
        lines=[]
        with src.open() as f:
            for line in f:
                t=float(line.split()[0])
                if 10000<=t<=20000:lines.append(line)
        assert len(lines)==10001
        dest.write_text(''.join(lines))
        manifest.append({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'window_file':dest.name,'window_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'record_TU':[10000,20000],'samples':len(lines)})
shutil.copy2(Path(r'D:\ClaudeFiles\mcpe_font_unify_20261028\times.ttf'),B/'times.ttf')
(B/'source_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Four original-window extracts and font prepared.')

from pathlib import Path
import json,hashlib
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
B=Path(__file__).resolve().parent
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'axes.linewidth':.75,'path.simplify':False})
cfg=dict(fs=1.,window='hann',nperseg=2500,noverlap=1250,detrend='constant',scaling='spectrum')
records={};curves={}
for model in [7,10]:
    aw=np.loadtxt(B/f'w{model}.txt');ae=np.loadtxt(B/f'eta{model}.txt')
    assert np.array_equal(aw[:,0],ae[:,0]);assert np.all(np.diff(aw[:,0])==1)
    w=aw[:,1];eta=ae[:,1]
    f,pw=signal.welch(w-w.mean(),**cfg);_,pe=signal.welch(eta-eta.mean(),**cfg)
    _,cross=signal.csd(w-w.mean(),eta-eta.mean(),**cfg)
    co=np.abs(cross)**2/(pw*pe)
    band=(f*100>=.5)&(f*100<=1.5);indices=np.flatnonzero(band);k=indices[np.argmax(pe[band])]
    gain=abs(cross[k]/pw[k])**2
    a=1+.001*eta.mean();lam=1-.001*w.mean();theory_gain=a*a/(lam*lam+(2*np.pi*f[k]*100)**2)
    df=f[1]-f[0]
    records[str(model)]={'peak_frequency_decade_inverse':float(f[k]*100),'period_years':float(.1/f[k]),'eta_peak_power':float(pe[k]),'w_power_at_eta_peak':float(pw[k]),'coherence_at_eta_peak':float(co[k]),'empirical_gain_squared_at_eta_peak':float(gain),'linearized_gain_squared_at_eta_peak':float(theory_gain),'linearized_driver_coefficient':float(a),'linearized_restoring_coefficient':float(lam),'mean_w':float(w.mean()),'mean_eta':float(eta.mean()),'eta_variance':float(eta.var()),'eta_band_variance_estimate':float(pe[band].sum()/1.5),'window_TU':[10000,20000]}
    curves[model]=(f*100,pw,pe,co)
assert records['7']['peak_frequency_decade_inverse']==records['10']['peak_frequency_decade_inverse']
keys=['eta_peak_power','w_power_at_eta_peak','empirical_gain_squared_at_eta_peak','linearized_gain_squared_at_eta_peak','eta_variance','eta_band_variance_estimate']
ratios={k:records['10'][k]/records['7'][k] for k in keys}
archive=json.loads((B/'archive_peaks.json').read_text())['variables']['eta']['models']
for model in ['7','10']:
    assert np.isclose(records[model]['eta_peak_power'],archive[model]['peak_power'],rtol=1e-12)
    assert np.isclose(records[model]['peak_frequency_decade_inverse'],archive[model]['peak_frequency'],rtol=1e-12)
fig,axs=plt.subplots(1,3,figsize=(9.5,3.0))
colors={7:'#24578D',10:'#C6324B'}
for model in [7,10]:
    fx,pw,pe,co=curves[model];label='Seven-variable' if model==7 else '10VCC';style='--' if model==7 else '-'
    axs[0].plot(fx,pe,color=colors[model],ls=style,lw=1,label=label)
    axs[1].plot(fx,pw,color=colors[model],ls=style,lw=1,label=label)
for i,name in enumerate([r'(a) Deep-ocean $\eta$',r'(b) Surface-ocean $w$']):
    ax=axs[i];ax.set_title(name,pad=5);ax.set_xlim(.5,1.5);ax.set_xlabel(r'Frequency (Decade$^{-1}$)');ax.set_ylabel('Spectral power');ax.grid(alpha=.18,ls=':');ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,2));ax.axvline(.56,color='#555555',ls=':',lw=.7)
    band_max=[]
    for model in [7,10]:
        fx,pw,pe,co=curves[model];mask=(fx>=.5)&(fx<=1.5)
        band_max.append(np.max((pe if i==0 else pw)[mask]))
    ax.set_ylim(0,max(band_max)*1.12)
labels=[r'$\eta$ power',r'$w$ power',r'$|H_{\eta w}|^2$']
values=[ratios['eta_peak_power'],ratios['w_power_at_eta_peak'],ratios['empirical_gain_squared_at_eta_peak']]
axs[2].bar(np.arange(3),values,color=['#C6324B','#24578D','#707070'],width=.6)
axs[2].axhline(1,color='#333333',ls='--',lw=.8);axs[2].set_xticks(np.arange(3),labels);axs[2].set_ylabel('10VCC / seven-variable');axs[2].set_title(r'(c) Comparison at 0.56 decade$^{-1}$',pad=5);axs[2].set_ylim(0,max(values)*1.18)
for i,v in enumerate(values):axs[2].text(i,v+.03,f'{v:.3f}',ha='center',fontsize=8)
handles,legend_labels=axs[0].get_legend_handles_labels();fig.legend(handles,legend_labels,loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,.94))
fig.suptitle(r'$\eta$ spectral peak and same-frequency surface-ocean variability',fontsize=12.5,y=1.02)
fig.subplots_adjust(left=.07,right=.99,bottom=.20,top=.72,wspace=.43)
fig.savefig(B/'Eta_peak_driver_check.png',dpi=600,bbox_inches='tight',pad_inches=.06)
fig.savefig(B/'Eta_peak_driver_check_preview.png',dpi=160,bbox_inches='tight',pad_inches=.06)
out={'definition':{'record_TU':[10000,20000],'c28':1,'display_band_decade_inverse':[.5,1.5],'estimator':cfg,'grain':'one archived realization, model-only free integrations','gain_definition':'abs(CSD(w,eta)/PSD(w))^2; empirical association, not an intervention transfer function','band_variance_estimate':'sum of Hann spectrum ordinates / 1.5; estimator-derived, distinct from full-record temporal variance','limitations':['This diagnoses the displayed realization only.','Previous 20-window checks concerned 0--0.2 decade^-1 and cannot establish reproducibility in 0.5--1.5 decade^-1.','No individual carbon-feedback pathway is identified by coherence alone.']},'models':records,'ratios_10_over_7':ratios,'archive_peak_reproduced':True,'sources':json.loads((B/'source_manifest.json').read_text())}
(B/'eta_peak_results.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'models':records,'ratios':ratios},indent=2))

from pathlib import Path
import json,hashlib
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
B=Path(__file__).resolve().parent
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'axes.linewidth':.75,'path.simplify':False})
cfg=dict(fs=1.,window='hann',nperseg=2500,noverlap=1250,detrend='constant',scaling='spectrum')
previous=json.loads((B/'eta_peak_results.json').read_text())
archive=json.loads((B/'archive_peaks.json').read_text())
for row in json.loads((B/'source_manifest.json').read_text()):
    assert hashlib.sha256((B/row['window_file']).read_bytes()).hexdigest()==row['window_sha256']
curves={};checks={}
for model in [7,10]:
    aw=np.loadtxt(B/f'w{model}.txt');ae=np.loadtxt(B/f'eta{model}.txt')
    assert np.array_equal(aw[:,0],ae[:,0]);assert np.all(np.diff(aw[:,0])==1.)
    w=aw[:,1];eta=ae[:,1]
    f,pw=signal.welch(w-w.mean(),**cfg);_,pe=signal.welch(eta-eta.mean(),**cfg)
    year=f*10;decade=f*100
    annual=(year>=.5)&(year<=1.5);ak=np.flatnonzero(annual)[np.argmax(pw[annual])]
    eta_band=(decade>=.5)&(decade<=1.5);ek=np.flatnonzero(eta_band)[np.argmax(pe[eta_band])]
    assert np.isclose(year[ak],1.,atol=1e-14)
    assert np.isclose(pw[ak]*.1,archive['variables']['w']['models'][str(model)]['peak_power'],rtol=1e-12)
    assert np.isclose(pe[ek],previous['models'][str(model)]['eta_peak_power'],rtol=1e-12)
    assert np.isclose(pw[ek],previous['models'][str(model)]['w_power_at_eta_peak'],rtol=1e-12)
    curves[model]=(year,decade,pw,pe)
    checks[str(model)]={'w_annual_peak_frequency_year_inverse':float(year[ak]),'w_annual_period_years':float(1/year[ak]),'w_annual_raw_spectrum_power':float(pw[ak]),'w_annual_archived_normalization_power':float(pw[ak]*.1),'eta_peak_frequency_decade_inverse':float(decade[ek]),'same_physical_w_frequency_year_inverse':float(year[ek]),'same_physical_period_years':float(1/year[ek])}
fig,axs=plt.subplots(2,2,figsize=(8.2,5.6));axs=axs.ravel()
colors={7:'#24578D',10:'#C6324B'}
for model in [7,10]:
    year,decade,pw,pe=curves[model];label='Seven-variable' if model==7 else '10VCC';ls='--' if model==7 else '-'
    axs[0].plot(decade,pe,c=colors[model],ls=ls,lw=1,label=label)
    axs[1].plot(year,pw,c=colors[model],ls=ls,lw=1)
    axs[2].plot(year,pw,c=colors[model],ls=ls,lw=1)
panels=[(r'(a) $\eta$: decadal-frequency band',.5,1.5,'Decade',3,1,.56),
        (r'(b) $w$: annual-frequency band',.5,1.5,'Year',2,0,1.),
        (r'(c) $w$: low-frequency detail',.05,.15,'Year',2,0,.056)]
for i,(title,lo,hi,unit,pi,fi,mark) in enumerate(panels):
    ax=axs[i];ax.set_title(title,pad=5);ax.set_xlim(lo,hi)
    ax.set_xlabel('Frequency ('+unit+r'$^{-1}$)');ax.set_ylabel('Spectral power');ax.grid(alpha=.18,ls=':')
    maxima=[]
    for model in [7,10]:
        z=curves[model];mask=(z[fi]>=lo)&(z[fi]<=hi);maxima.append(float(z[pi][mask].max()))
    ax.set_ylim(0,max(maxima)*1.22);ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,2));ax.axvline(mark,c='#555555',ls=':',lw=.8)
    ax.text(.12 if i!=1 else .62,.93,'17.86 years' if i!=1 else '1 year',transform=ax.transAxes,ha='left',va='top',fontsize=8)
axs[1].set_xticks([.5,.75,1.,1.25,1.5]);axs[2].set_xticks([.05,.075,.10,.125,.15])
ratios=previous['ratios_10_over_7'];values=[ratios['eta_peak_power'],ratios['w_power_at_eta_peak'],ratios['empirical_gain_squared_at_eta_peak']]
axs[3].bar(range(3),values,color=['#C6324B','#24578D','#707070'],width=.6)
axs[3].axhline(1,c='#333333',ls='--',lw=.8)
axs[3].set_xticks(range(3),[r'$\eta$ power',r'$w$ power',r'$|H_{\eta w}|^2$'])
axs[3].set_ylim(0,max(values)*1.2);axs[3].set_ylabel('10VCC / seven-variable')
axs[3].set_title('(d) Ratios at the 17.86-year frequency',pad=5)
for i,v in enumerate(values):axs[3].text(i,v+.04,f'{v:.3f}',ha='center',fontsize=8)
handles,labels=axs[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,.94))
fig.suptitle(r'Annual $w$ peak and decadal $w$–$\eta$ variability',fontsize=12.5,y=.99)
fig.subplots_adjust(left=.09,right=.985,bottom=.09,top=.82,hspace=.55,wspace=.30)
name='Eta_w_annual_and_low_frequency_20261029'
fig.savefig(B/(name+'.png'),dpi=600,bbox_inches='tight',pad_inches=.06)
fig.savefig(B/(name+'_preview.png'),dpi=160,bbox_inches='tight',pad_inches=.06)
out={'record_TU':[10000,20000],'c28':1,'sampling_TU':1,'estimator':cfg,'checks':checks,'previous_eta_and_w_low_frequency_results_reproduced':True,'previous_annual_w_peaks_reproduced':True,'normalization':'All new panels use raw Welch spectrum power. Archived model-only w panel multiplied raw spectrum by 0.1; peak locations and ratios are unchanged.','unit_relation':'0.56 decade^-1 = 0.056 year^-1 = 17.857142857 years; annual frequency is 1 year^-1 = 10 decade^-1.','scope':'Annual peak is the maximum within the original displayed annual band 0.5--1.5 year^-1, not a claim about the global spectrum maximum.','ratios_10_over_7_at_17_86_years':ratios,'figure_sha256':hashlib.sha256((B/(name+'.png')).read_bytes()).hexdigest()}
(B/(name+'.json')).write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))

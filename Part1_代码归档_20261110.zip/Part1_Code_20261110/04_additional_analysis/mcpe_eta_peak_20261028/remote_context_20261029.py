from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_peak_20261028'
name='Eta_w_annual_and_low_frequency_20261029'
c=hpc.connect()
try:
    mode=sys.argv[1]
    if mode=='submit':
        with c.open_sftp() as s:s.put(str(B/'plot_context_20261029.py'),R+'/plot_context_20261029.py')
        command='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=2G --time=00:05:00 --job-name=eta_w_context --output=context-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python plot_context_20261029.py')
        rc,out,err=hpc.run(c,command)
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'context_submission_20261029.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
    elif mode=='status':
        job=json.loads((B/'context_submission_20261029.json').read_text())['job']
        rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -7 '+shlex.quote(R+'/context-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/'+name+'.json')+' && echo CONTEXT_DONE')
        print(out);print(err.strip())
    elif mode=='fetch':
        with c.open_sftp() as s:
            for ext in ['.png','_preview.png','.json']:s.get(R+'/'+name+ext,str(B/(name+ext)))
        print('DOWNLOADED')
finally:c.close()

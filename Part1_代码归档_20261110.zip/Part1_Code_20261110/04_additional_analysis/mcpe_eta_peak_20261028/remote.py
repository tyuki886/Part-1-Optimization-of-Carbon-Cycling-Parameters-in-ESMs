from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_peak_20261028'
c=hpc.connect()
try:
    mode=sys.argv[1]
    if mode=='submit':
        with c.open_sftp() as s:
            try:s.stat(R);raise RuntimeError('Independent directory exists')
            except FileNotFoundError:s.mkdir(R)
            for n in ['w7.txt','w10.txt','eta7.txt','eta10.txt','times.ttf','analyze.py','source_manifest.json','archive_peaks.json']:s.put(str(B/n),R+'/'+n)
        command='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=2G --time=00:05:00 --job-name=eta_peak_check --output=analysis-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python analyze.py')
        rc,out,err=hpc.run(c,command)
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
    elif mode=='replot':
        with c.open_sftp() as s:s.put(str(B/'analyze.py'),R+'/analyze.py')
        command='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=2G --time=00:05:00 --job-name=eta_peak_plot --output=analysis-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python analyze.py')
        rc,out,err=hpc.run(c,command)
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
    elif mode=='status':
        job=json.loads((B/'submission.json').read_text())['job']
        rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -8 '+shlex.quote(R+'/analysis-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/eta_peak_results.json')+' && echo DONE')
        print(out);print(err.strip())
    elif mode=='fetch':
        with c.open_sftp() as s:
            for n in ['eta_peak_results.json','Eta_peak_driver_check.png','Eta_peak_driver_check_preview.png']:s.get(R+'/'+n,str(B/n))
        print('DOWNLOADED')
finally:c.close()

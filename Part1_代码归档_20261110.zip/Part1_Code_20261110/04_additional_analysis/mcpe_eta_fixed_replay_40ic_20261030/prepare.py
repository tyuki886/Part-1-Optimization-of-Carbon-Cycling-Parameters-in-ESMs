from pathlib import Path
import json,shutil,hashlib
B=Path(__file__).resolve().parent
O=B.parent/'mcpe_eta_fixed_replay_20261030'
for name in ['RKmethod_reference.f90','times.ttf','plot.py']:
    shutil.copy2(O/name,B/name)
remote=(O/'remote.py').read_text(encoding='utf-8')
assert remote.count("/eta_fixed_replay_20261030'")==1
(B/'remote.py').write_text(remote.replace("/eta_fixed_replay_20261030'","/eta_fixed_replay_40ic_20261030'"),encoding='utf-8')
f=(O/'replay.f90').read_text(encoding='utf-8')
old=""" open(newunit=uo,file=trim(oldpath),access='stream',form='unformatted',status='old')
 read(uo)oldrow
 row=stored_row(ref,0.0_dp)
 old_error=maxval(abs(oldrow(1:6)-row(1:6)))
 old_error=max(old_error,abs(oldrow(7)-ref(1)*(ref(7)-ref(4))))"""
assert f.count(old)==1
new=""" old_error=0.0_dp
 if(trim(oldpath)/='-')then
  open(newunit=uo,file=trim(oldpath),access='stream',form='unformatted',status='old')
  read(uo)oldrow
  row=stored_row(ref,0.0_dp)
  old_error=maxval(abs(oldrow(1:6)-row(1:6)))
  old_error=max(old_error,abs(oldrow(7)-ref(1)*(ref(7)-ref(4))))
 endif"""
f=f.replace(old,new).replace('if(mod(i,100_8)==0.and.i<=20000000_8)then',
    "if(trim(oldpath)/='-'.and.mod(i,100_8)==0.and.i<=20000000_8)then")
assert f.count(' close(uo)')==1
f=f.replace(' close(uo)'," if(trim(oldpath)/='-')close(uo)")
(B/'replay.f90').write_text(f,encoding='utf-8')
a=(O/'analyze.py').read_text(encoding='utf-8')
a=a.replace("B=Path(__file__).resolve().parent", "B=Path(__file__).resolve().parent\nORIGINAL=B.parent/'eta_fixed_replay_20261030'\nN=40")
a=a.replace("completion['count']==10", "completion['count']==40")
a=a.replace('rng.integers(0,10,(19999,10))','rng.integers(0,N,(19999,N))')
a=a.replace('x.shape[0]==10','x.shape[0]==N').replace('range(10)','range(N)')
a=a.replace("d=B/'data'/f'seed{seed}'", "d=(ORIGINAL if seed<10 else B)/'data'/f'seed{seed}'")
a=a.replace("all_references_reproduce_existing_M7=all(z['audit']['reference_vs_existing_M7_max_abs']==0 for z in completion['runs']),", "all_available_archives_reproduced=all(z['audit']['reference_vs_existing_M7_max_abs']==0 for z in completion['runs'] if z['seed']<10),\n    existing_M7_archive_comparisons=10,")
a=a.replace('all ten IC','all forty IC')
target="(B/'factorial_results.json').write_text(json.dumps(out,indent=2))"
assert a.count(target)==1
a=a.replace(target,"out['mean_minus_fluctuation_low_percent']=stats(np.asarray(summary['low']['mean']['by_initial_condition'])-np.asarray(summary['low']['fluctuation']['by_initial_condition']))\n"+target)
(B/'analyze.py').write_text(a,encoding='utf-8')
cfg=json.loads((O/'configuration.json').read_text())
cfg['initial_conditions']=40
cfg['budget']=cfg['budget'].replace('ten IC','forty IC')
cfg['initialization']='Original x2=1+0.001*seed, seeds 0..39; all other initial states zero. Same full-model spinup and shared 18-entry branch checkpoint.'
cfg['extension']='Fixed extension from preliminary ten to forty IC because preliminary intervals were too broad for component attribution. All 40 IC and all four cases retained; no further sample-size extension selected from result signs.'
cfg['bootstrap']='19999 paired resamples of forty IC, after twenty-window averaging within each IC; seed 20261030; exploratory 95% intervals.'
(B/'configuration.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
manifest={n:hashlib.sha256((B/n).read_bytes()).hexdigest() for n in ['RKmethod_reference.f90','replay.f90','analyze.py','configuration.json','times.ttf']}
manifest['original_10_IC_remote']='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_fixed_replay_20261030'
(B/'source_manifest.json').write_text(json.dumps(manifest,indent=2))
print('40组初态扩展包已准备，仅新增30组；原10组保留复用。')

from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,r'D:\ClaudeFiles\项目2-Levante超算')
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_fixed_replay_40ic_20261030'
c=hpc.connect()
try:
    mode=sys.argv[1]
    if mode=='submit':
        with c.open_sftp() as s:
            try:s.stat(R);raise RuntimeError('独立实验目录已存在')
            except FileNotFoundError:s.mkdir(R)
            for name in ['replay.f90','RKmethod_reference.f90','run.py','analyze.py','configuration.json','source_manifest.json','times.ttf']:
                s.put(str(B/name),R+'/'+name)
        wrap='export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python run.py'
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=4 --mem=4G --time=00:20:00 --job-name=eta_fixed_replay --output=replay-%j.log --wrap='+shlex.quote(wrap)
        rc,out,err=hpc.run(c,cmd)
        if rc:raise RuntimeError(err)
        j=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'submission.json').write_text(json.dumps(dict(job=j,remote=R,account='ab0246')));print(out)
    elif mode in ['status','plot-status']:
        marker='submission.json' if mode=='status' else 'plot_submission.json';prefix='replay' if mode=='status' else 'plot'
        j=json.loads((B/marker).read_text())['job']
        rc,out,err=hpc.run(c,'sacct -n -j '+j+' --format=JobID,State,ExitCode,Elapsed; grep -E "PASS|DONE|COMPLETE|Error|Error stop|Traceback|STOP" '+shlex.quote(R+'/'+prefix+'-'+j+'.log')+' | tail -6')
        print(out)
    elif mode=='fetch':
        with c.open_sftp() as s:
            for name in ['completion.json','preflight.json','summary.json','factorial_results.json']:
                s.get(R+'/'+name,str(B/name))
        print('固定信号四组实验结果已下载')
    elif mode=='log':
        j=json.loads((B/'submission.json').read_text())['job']
        with c.open_sftp() as s:
            s.get(R+'/replay-'+j+'.log',str(B/'remote_run.log'))
            try:s.get(R+'/preflight/run.log',str(B/'preflight_run.log'))
            except FileNotFoundError:pass
        print((B/'remote_run.log').read_text(errors='replace')[-4500:])
        if (B/'preflight_run.log').exists():print((B/'preflight_run.log').read_text(errors='replace')[-2200:])
    elif mode=='plot':
        with c.open_sftp() as s:s.put(str(B/'plot.py'),R+'/plot.py')
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=4G --time=00:05:00 --job-name=eta_factor_plot --output=plot-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python plot.py')
        rc,out,err=hpc.run(c,cmd)
        if rc:raise RuntimeError(err)
        j=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'plot_submission.json').write_text(json.dumps(dict(job=j,remote=R,account='ab0246')));print(out)
    elif mode=='fetch-plot':
        with c.open_sftp() as s:
            for name in ['Eta_fixed_signal_factor_separation.png','Eta_fixed_signal_factor_separation_preview.png','figure_manifest.json']:
                s.get(R+'/'+name,str(B/name))
        print('因子分离成图已下载')
finally:c.close()

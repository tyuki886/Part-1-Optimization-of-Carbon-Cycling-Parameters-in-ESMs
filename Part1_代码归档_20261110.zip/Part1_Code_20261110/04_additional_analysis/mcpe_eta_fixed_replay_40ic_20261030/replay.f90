program eta_fixed_signal_factorial
 use RKmethod
 use, intrinsic :: ieee_arithmetic
 implicit none
 integer(kind=8),parameter::nspin=1000000_8,nburn=1000000_8,neval=20000000_8
 integer(kind=8)::i
 integer::seed,j,u(4),uo,ur
 real(dp)::ref(18),checkpoint(18),x(18,4),stage(4),mu,smu,cmu,inc,z,nxt
 real(dp)::budget_begin(5,4),totals(5,4),comp(5,4),mx(5,4),increments(5,4),rhs_error(4)
 real(dp)::ivec(5),zz(5),nn(5),actual(5),oldrow(7),row(9),old_error,replay_error
 real(dp)::qsum(4),qcomp(4),qinc(4),qmean(4),qmx,sum_error,phase_force_error
 character(len=1024)::arg,oldpath
 character(len=32)::names(4)
 call get_command_argument(1,arg);read(arg,*)seed
 call get_command_argument(2,oldpath)
 names=[character(len=32)::'off.bin','mean.bin','fluctuation.bin','full.bin']
 ref=0.0_dp;ref(2)=1.0_dp+.001_dp*seed
 do i=1,nspin
  call adv_true_state(ref,i,10)
 enddo
 checkpoint=ref
 old_error=0.0_dp
 if(trim(oldpath)/='-')then
  open(newunit=uo,file=trim(oldpath),access='stream',form='unformatted',status='old')
  read(uo)oldrow
  row=stored_row(ref,0.0_dp)
  old_error=maxval(abs(oldrow(1:6)-row(1:6)))
  old_error=max(old_error,abs(oldrow(7)-ref(1)*(ref(7)-ref(4))))
 endif
 smu=0.0_dp;cmu=0.0_dp
 do i=1,nburn+neval
  if(i>nburn)then
   call reference_stages(ref,i,stage)
   inc=(stage(1)+2.0_dp*stage(2)+2.0_dp*stage(3)+stage(4))/6.0_dp
   z=inc-cmu;nxt=smu+z;cmu=(nxt-smu)-z;smu=nxt
  endif
  call adv_true_state(ref,i,10)
  if(trim(oldpath)/='-'.and.mod(i,100_8)==0.and.i<=20000000_8)then
   read(uo)oldrow
   row=stored_row(ref,0.0_dp)
   old_error=max(old_error,maxval(abs(oldrow(1:6)-row(1:6))))
   old_error=max(old_error,abs(oldrow(7)-ref(1)*(ref(7)-ref(4))))
  endif
 enddo
 if(trim(oldpath)/='-')close(uo)
 mu=smu/real(neval,dp)
 if(old_error>1.0e-12_dp)error stop 'reference does not reproduce existing M7'
 ref=checkpoint
 do j=1,4
  x(:,j)=checkpoint
  open(newunit=u(j),file=trim(names(j)),access='stream',form='unformatted',status='new')
 enddo
 totals=0.0_dp;comp=0.0_dp;mx=0.0_dp;rhs_error=0.0_dp;replay_error=0.0_dp
 qsum=0.0_dp;qcomp=0.0_dp;sum_error=0.0_dp;phase_force_error=0.0_dp
 do i=1,nburn+neval
  call reference_stages(ref,i,stage)
  if(i==nburn+1)then
   do j=1,4
    budget_begin(:,j)=budget_values(x(:,j))
   enddo
  endif
  do j=1,4
   call forced_step(x(:,j),i,stage,mu,j,increments(:,j),rhs_error(j),i>nburn)
  enddo
  call adv_true_state(ref,i,10)
  replay_error=max(replay_error,maxval(abs(x(:,4)-ref)))
  if(replay_error>1.0e-12_dp)error stop 'full replay is not exact'
  if(i>=nburn)then
   if(i>nburn)then
    do j=1,4
     zz=increments(:,j)-comp(:,j);nn=totals(:,j)+zz
     comp(:,j)=(nn-totals(:,j))-zz;totals(:,j)=nn
     actual=budget_values(x(:,j))-budget_begin(:,j)
     mx(:,j)=max(mx(:,j),abs(actual-totals(:,j)))
     qinc(j)=.01_dp*(extra_force(stage(1),mu,j)+2.0_dp*extra_force(stage(2),mu,j) &
       +2.0_dp*extra_force(stage(3),mu,j)+extra_force(stage(4),mu,j))/6.0_dp
     z=qinc(j)-qcomp(j);nxt=qsum(j)+z;qcomp(j)=(nxt-qsum(j))-z;qsum(j)=nxt
    enddo
    sum_error=max(sum_error,abs(qinc(4)-qinc(2)-qinc(3)))
   endif
   if(mod(i-nburn,100_8)==0)then
    do j=1,4
     row=stored_row(x(:,j),extra_force(ref(8),mu,j))
     if(.not.all(ieee_is_finite(row)))error stop 'nonfinite trajectory'
     write(u(j))row
    enddo
   endif
  endif
 enddo
 do j=1,4
  close(u(j))
 enddo
 qmean=qsum/(real(neval,dp)*.01_dp)
 if(abs(qmean(3))>1.0e-10_dp)error stop 'fluctuation forcing not zero mean'
 if(maxval(mx)>1.0e-7_dp.or.maxval(rhs_error)>1.0e-10_dp)error stop 'budget audit failed'
 open(newunit=ur,file='audit.txt',status='new')
 write(ur,*)mu,old_error,replay_error
 do j=1,4
  write(ur,*)mx(:,j),rhs_error(j),qmean(j)
 enddo
 write(ur,*)sum_error
 close(ur)
 print *,'SEED_DONE',seed,'REFERENCE_MEAN',mu,'REPLAY_ERROR',replay_error
contains
 subroutine reference_stages(s,it,cref)
  real(dp),intent(in)::s(18)
  integer(kind=8),intent(in)::it
  real(dp),intent(out)::cref(4)
  real(dp)::a(10),b(10),c(10),tmp(18)
  cref(1)=s(8);a=derivs(s,it,10)
  tmp=s;tmp(1:10)=s(1:10)+.5*.01_dp*a;cref(2)=tmp(8);b=derivs(tmp,it,10)
  tmp=s;tmp(1:10)=s(1:10)+.5*.01_dp*b;cref(3)=tmp(8);c=derivs(tmp,it,10)
  tmp=s;tmp(1:10)=s(1:10)+.01_dp*c;cref(4)=tmp(8)
 end subroutine
 function extra_force(cref,meanref,kind)result(q)
  real(dp),intent(in)::cref,meanref
  integer,intent(in)::kind
  real(dp)::q
  select case(kind)
  case(1);q=0.0_dp
  case(2);q=slm*c24*meanref
  case(3);q=slm*c24*(cref-meanref)
  case(4);q=slm*c24*cref
  end select
 end function
 function land_source(cref,meanref,kind)result(q)
  real(dp),intent(in)::cref,meanref
  integer,intent(in)::kind
  real(dp)::q
  ! Retain original arithmetic for the full case so exact trajectory replay
  ! is a test of the stage-level forcing, not just a PSD-level agreement.
  select case(kind)
  case(1);q=slm
  case(2);q=slm*(1.0+c24*meanref)
  case(3);q=slm*(1.0+c24*(cref-meanref))
  case(4);q=slm*(1.0+c24*cref)
  end select
 end function
 function forced_rhs(s,it,cref,meanref,kind)result(ds)
  real(dp),intent(in)::s(18),cref,meanref
  integer(kind=8),intent(in)::it
  integer,intent(in)::kind
  real(dp)::ds(10),pi
  pi=3.141592653589793_dp
  ds=derivs(s,it,10)
  ds(7)=(c12*s(2)-old*s(7)-c15*s(1)*(s(7)-s(4)))
  ds(7)=(ds(7)+land_source(cref,meanref,kind)+sls*cos(2.0*pi*it*0.01/spd))/olm
 end function
 function independent_flux(s,it,cref,meanref,kind)result(f)
  real(dp),intent(in)::s(18),cref,meanref
  integer(kind=8),intent(in)::it
  integer,intent(in)::kind
  real(dp)::f(5),fas,fl,fc,fe,bc,pco,pi
  pi=3.141592653589793_dp
  pco=max(c29*s(9)-c30*s(10),0.0_dp)
  fas=c18*(1.0-c19*s(4))*(s(8)-pco)
  fl=c20*s(8)*s(7);fc=c21*s(1)*(s(7)-s(4));fe=c22*(1.0-c23*s(4))*s(5)
  bc=c26*rrain*s(9)*max(s(10)-c27*s(9)+c28,0.0_dp)
  f(1)=E_rate-fas-fl-fc
  f(2)=fas-fe-bc
  f(3)=c25-2.0_dp*bc
  f(4)=c2*s(2)+c3*s(5)+c4*s(4)*s(5)-od*s(4)-c7*s(15)+sm*(1.0+c17*s(8)) &
       +ss*cos(2.0*pi*it*.01/spd)+c12*s(2)-old*s(7)+land_source(cref,meanref,kind) &
       +sls*cos(2.0*pi*it*.01/spd)
  f(5)=(c5*s(4)+c6*s(4)*s(5)-od*s(5))/gamma_deep
 end function
 function rhs_budget(k)result(v)
  real(dp),intent(in)::k(10)
  real(dp)::v(5)
  v=[k(8),k(9),k(10),om*k(4)+olm*k(7),k(5)]
 end function
 function budget_values(s)result(v)
  real(dp),intent(in)::s(18)
  real(dp)::v(5)
  v=[s(8),s(9),s(10),om*s(4)+olm*s(7),s(5)]
 end function
 subroutine forced_step(s,it,cref,meanref,kind,flux_inc,error,audit)
  real(dp),intent(inout)::s(18),error
  integer(kind=8),intent(in)::it
  real(dp),intent(in)::cref(4),meanref
  integer,intent(in)::kind
  logical,intent(in)::audit
  real(dp),intent(out)::flux_inc(5)
  real(dp)::k1(10),k2(10),k3(10),k4(10),tmp(18),ff(5,4),hval
  k1=forced_rhs(s,it,cref(1),meanref,kind)
  if(audit)then
   ff(:,1)=independent_flux(s,it,cref(1),meanref,kind)
   error=max(error,maxval(abs(rhs_budget(k1)-ff(:,1))))
  endif
  tmp=s;tmp(1:10)=s(1:10)+.5*.01_dp*k1;k2=forced_rhs(tmp,it,cref(2),meanref,kind)
  if(audit)then
   ff(:,2)=independent_flux(tmp,it,cref(2),meanref,kind)
   error=max(error,maxval(abs(rhs_budget(k2)-ff(:,2))))
  endif
  tmp=s;tmp(1:10)=s(1:10)+.5*.01_dp*k2;k3=forced_rhs(tmp,it,cref(3),meanref,kind)
  if(audit)then
   ff(:,3)=independent_flux(tmp,it,cref(3),meanref,kind)
   error=max(error,maxval(abs(rhs_budget(k3)-ff(:,3))))
  endif
  tmp=s;tmp(1:10)=s(1:10)+.01_dp*k3;k4=forced_rhs(tmp,it,cref(4),meanref,kind)
  if(audit)then
   ff(:,4)=independent_flux(tmp,it,cref(4),meanref,kind)
   error=max(error,maxval(abs(rhs_budget(k4)-ff(:,4))))
   flux_inc=(.01_dp/6.0_dp)*(ff(:,1)+2.0_dp*ff(:,2)+2.0_dp*ff(:,3)+ff(:,4))
  else
   flux_inc=0.0_dp
  endif
  s(1:10)=s(1:10)+(.01_dp/6.0_dp)*(k1+2.0_dp*k2+2.0_dp*k3+k4)
  hval=c8*s(2)**2+c9*s(4)**2+c10*s(15)**2
  if(hval>50.0_dp)then
   s(6)=0.0_dp
  elseif(hval<10.0_dp)then
   s(6)=1.0_dp
  else
   s(6)=.5_dp*(exp(-(hval-10.0_dp)/80.0_dp)+exp(-1.0_dp/max(50.0_dp-hval,1.0e-10_dp)))
  endif
  s(15)=s(6)
 end subroutine
 function stored_row(s,q)result(row)
  real(dp),intent(in)::s(18),q
  real(dp)::row(9)
  row=[s(1),s(2),s(4),s(5),s(7),s(8),s(9),s(10),q]
 end function
end program

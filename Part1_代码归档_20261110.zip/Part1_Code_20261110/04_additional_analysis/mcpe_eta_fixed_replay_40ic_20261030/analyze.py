from pathlib import Path
import json,hashlib
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent
ORIGINAL=B.parent/'eta_fixed_replay_20261030'
N=40
completion=json.loads((B/'completion.json').read_text());assert completion['count']==40
welch=dict(fs=1.,window='hann',nperseg=2500,noverlap=1250,detrend='constant',scaling='density')
cases=['off','mean','fluctuation','full']
bands=dict(low=[.5,.75],wider=[.5,.8],display=[.5,1.5])
rng=np.random.default_rng(20261030);boot=rng.integers(0,N,(19999,N))
def stats(x):
    x=np.asarray(x,float);assert x.shape[0]==N and np.isfinite(x).all()
    samples=x[boot].mean(axis=1)
    return dict(mean=x.mean(axis=0).tolist(),ci95=np.percentile(samples,[2.5,97.5],axis=0).tolist(),by_initial_condition=x.tolist())
def select(f,band):return (f>=band[0]-1e-10)&(f<=band[1]+1e-10)
curves={};windows={};sources=[]
for case in cases:
    curves[case]=[];windows[case]=[]
    for seed in range(N):
        d=(ORIGINAL if seed<10 else B)/'data'/f'seed{seed}';p=d/(case+'.bin')
        receipt=json.loads((d/'receipt.json').read_text())
        digest=hashlib.sha256(p.read_bytes()).hexdigest()
        assert digest==next(z['sha256'] for z in receipt['files'] if z['case']==case)
        a=np.memmap(p,dtype='<f8',mode='r',shape=(200001,9))
        ps=[];rs=[]
        for j in range(20):
            v=a[j*10000+1:(j+1)*10000+1]
            f,power=signal.welch(v[:,[3,2]],axis=0,**welch)
            fd=f*100;pd=power/100;df=fd[1]-fd[0]
            fp,pp=signal.periodogram(v[:,3],fs=1.,window='boxcar',detrend='constant',scaling='density')
            assert np.isclose(pp.sum()*(fp[1]-fp[0]),v[:,3].var(),rtol=1e-11,atol=1e-12)
            row=dict(eta_mean=float(v[:,3].mean()),eta_variance=float(v[:,3].var()),
                     forcing_sample_mean=float(v[:,8].mean()),forcing_sample_std=float(v[:,8].std()))
            for key,band in bands.items():
                mask=select(fd,band)
                row[key]=float(pd[mask,0].sum()*df)
                row['input_'+key]=float(pd[mask,1].sum()*df)
                row['periodogram_'+key]=float(pp[select(fp*100,band)].sum()*(fp[1]-fp[0]))
            mask=select(fd,bands['display'])
            row['peak_frequency']=float(fd[np.flatnonzero(mask)[np.argmax(pd[mask,0])]])
            rs.append(row);ps.append(pd)
        windows[case].append(rs);curves[case].append(np.mean(ps,axis=0))
        sources.append(dict(case=case,seed=seed,sha256=digest))
    curves[case]=np.asarray(curves[case])

def effects(p):
    a=p['off'];m=100*(p['mean']-a)/a;v=100*(p['fluctuation']-a)/a
    t=100*(p['full']-a)/a;i=t-m-v
    assert np.allclose(m+v+i,t,rtol=1e-12,atol=1e-12)
    return {k:stats(x) for k,x in [('mean',m),('fluctuation',v),('interaction',i),('total',t)]}

summary={}
for metric in ['eta_variance','low','wider','display','input_low','periodogram_low','periodogram_wider','periodogram_display']:
    pp={case:np.asarray([np.mean([z[metric] for z in row]) for row in windows[case]]) for case in cases}
    summary[metric]=effects(pp)
early_late={}
for label,sl in [('early',slice(0,10)),('late',slice(10,20))]:
    pp={case:np.asarray([np.mean([z['low'] for z in row[sl]]) for row in windows[case]]) for case in cases}
    early_late[label]=effects(pp)

display=select(fd,bands['display'])
frequency_effects=effects({case:curves[case][:,display,0] for case in cases})
shift={case:stats(np.asarray([np.mean([z['peak_frequency'] for z in row]) for row in windows[case]])-
                  np.asarray([np.mean([z['peak_frequency'] for z in row]) for row in windows['off']])) for case in cases[1:]}
audit=dict(all_full_replays_exact=completion['all_full_replays_exact'],
    all_available_archives_reproduced=all(z['audit']['reference_vs_existing_M7_max_abs']==0 for z in completion['runs'] if z['seed']<10),
    existing_M7_archive_comparisons=10,
    max_native_budget_residuals=np.max([z['audit']['native_budget_max_residuals'][case] for z in completion['runs'] for case in cases],axis=0).tolist(),
    max_independent_rhs_flux_difference=max(z['audit']['independent_flux_rhs_max_abs'][case] for z in completion['runs'] for case in cases),
    fluctuation_native_mean_max_abs=max(abs(z['audit']['actual_forcing_native_time_means']['fluctuation']) for z in completion['runs']),
    native_budget_scope='All 200000 evaluation TU, all four replay cases, all forty IC, RK4-stage integrated Catm/Cocn/ALK/weighted-temperature/eta budgets.',
    algebraic_low_effect_closure_max_abs=max(abs(sum(summary['low'][k]['by_initial_condition'][seed] for k in ['mean','fluctuation','interaction'])-summary['low']['total']['by_initial_condition'][seed]) for seed in range(N)))
out=dict(configuration=json.loads((B/'configuration.json').read_text()),summary=summary,
    early_late=early_late,frequency_decade_inverse=fd[display].tolist(),
    frequency_effects=frequency_effects,peak_frequency_shift=shift,audit=audit,
    spectra={case:stats(curves[case][:,display,0]) for case in cases},
    window_metrics=windows,sources=sources,
    interpretation='Controlled responses to the mean and zero-mean fluctuation of a prescribed reference c24 forcing; c16/c17 and carbon equations remain internally active. Effects are conditional, with an explicit interaction; they are not physical-energy shares or unique upstream sediment contributions.')
out['mean_minus_fluctuation_low_percent']=stats(np.asarray(summary['low']['mean']['by_initial_condition'])-np.asarray(summary['low']['fluctuation']['by_initial_condition']))
(B/'factorial_results.json').write_text(json.dumps(out,indent=2))
(B/'summary.json').write_text(json.dumps(dict(summary=summary,early_late=early_late,audit=audit),indent=2))
print('FACTORIAL_ANALYSIS_COMPLETE',json.dumps(dict(low=summary['low'],audit=audit)),flush=True)

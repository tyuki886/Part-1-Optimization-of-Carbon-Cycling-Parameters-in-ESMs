from pathlib import Path
import concurrent.futures,subprocess,time,json,hashlib
import numpy as np
B=Path(__file__).resolve().parent
O=B.parent/'eta_fixed_replay_20261030'
OLD=B.parent/'w_feedback_20261029'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(B/'RKmethod_reference.f90').read_text();assert 'c28=1.0_dp' in source
assert sha(B/'RKmethod_reference.f90')==sha(O/'RKmethod_reference.f90')
old=json.loads((O/'completion.json').read_text());assert old['count']==10
build=B/'build';build.mkdir();(build/'RKmethod.f90').write_text(source)
subprocess.run(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90',str(B/'replay.f90'),'-o','replay'],cwd=build,check=True)
pre=B/'preflight';pre.mkdir();(pre/'RKmethod.f90').write_text(source)
driver=(B/'replay.f90').read_text().replace('nburn=1000000_8,neval=20000000_8','nburn=10000_8,neval=200000_8')
(pre/'replay.f90').write_text(driver)
subprocess.run(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90','replay.f90','-o','replay'],cwd=pre,check=True)
with (pre/'run.log').open('w') as log:
    subprocess.run([str(pre/'replay'),'0',str(OLD/'data/M7_seed0/states.bin')],cwd=pre,check=True,stdout=log,stderr=subprocess.STDOUT)
for name in ['off','mean','fluctuation','full']:
    assert sha(pre/(name+'.bin'))==sha(O/'preflight'/(name+'.bin')),'IO-only source change alters trajectory'
(B/'preflight.json').write_text(json.dumps(dict(all_four_preflight_trajectories_bitwise_identical_to_original_driver=True)))
print('EXTENSION_PREFLIGHT_PASS',flush=True)

def parse_audit(d):
    lines=(d/'audit.txt').read_text().splitlines();first=[float(x) for x in lines[0].split()]
    rows=[[float(x) for x in line.split()] for line in lines[1:5]]
    assert first[2]==0 and abs(rows[2][-1])<1e-10 and max(max(z[:5]) for z in rows)<1e-7
    return dict(reference_Catm_native_RK_mean=first[0],
        reference_vs_existing_M7_max_abs=None,existing_archive_not_available_for_new_IC=True,
        full_replay_vs_reference_max_abs=first[2],
        native_budget_max_residuals={k:v[:5] for k,v in zip(['off','mean','fluctuation','full'],rows)},
        independent_flux_rhs_max_abs={k:v[5] for k,v in zip(['off','mean','fluctuation','full'],rows)},
        actual_forcing_native_time_means={k:v[6] for k,v in zip(['off','mean','fluctuation','full'],rows)},
        native_forcing_additivity_max_increment_error=float(lines[5]))
data=B/'data';data.mkdir()
def run(seed):
    d=data/f'seed{seed}';d.mkdir();start=time.time()
    with (d/'run.log').open('w') as log:
        subprocess.run([str(build/'replay'),str(seed),'-'],cwd=d,check=True,stdout=log,stderr=subprocess.STDOUT)
    audit=parse_audit(d);files=[]
    for case in ['off','mean','fluctuation','full']:
        p=d/(case+'.bin');assert p.stat().st_size==200001*9*8
        a=np.memmap(p,dtype='<f8',mode='r',shape=(200001,9));assert np.isfinite(a).all()
        files.append(dict(case=case,sha256=sha(p),bytes=p.stat().st_size))
    receipt=dict(seed=seed,seconds=time.time()-start,c28=1,
        source_sha256=sha(B/'RKmethod_reference.f90'),driver_sha256=sha(B/'replay.f90'),files=files,audit=audit)
    (d/'receipt.json').write_text(json.dumps(receipt,indent=2))
    print('EXTENSION_SEED_DONE',seed,round(receipt['seconds'],1),flush=True)
    return receipt
t=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,range(10,40)))
runs=old['runs']+rows
out=dict(count=40,cases=4,runs=runs,new_count=30,seconds=time.time()-t,
    entire_evaluation_native_budget_audited=True,
    all_full_replays_exact=all(z['audit']['full_replay_vs_reference_max_abs']==0 for z in runs))
(B/'completion.json').write_text(json.dumps(out,indent=2))
print('ALL_40_IC_REPLAYS_COMPLETE',flush=True)
subprocess.run(['/home/b/b382207/conda/envs/yuki/bin/python',str(B/'analyze.py')],cwd=B,check=True)

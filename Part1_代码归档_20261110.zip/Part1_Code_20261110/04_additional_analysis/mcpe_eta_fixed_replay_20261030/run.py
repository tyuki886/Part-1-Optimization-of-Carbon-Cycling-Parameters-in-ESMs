from pathlib import Path
import concurrent.futures, subprocess, time, json, hashlib
import numpy as np
B=Path(__file__).resolve().parent
OLD=B.parent/'w_feedback_20261029'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(B/'RKmethod_reference.f90').read_text()
assert 'c28=1.0_dp' in source
assert source.count('c15*s(1)*(s(7)-s(4))')==2
assert 'ds(10)=c25-2.0_dp*Bcal' in source
assert 'c26 * rrain * s(9)' in source
build=B/'build';build.mkdir()
(build/'RKmethod.f90').write_text(source)
subprocess.run(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90',str(B/'replay.f90'),'-o','replay'],cwd=build,check=True)

def parse_audit(d):
    lines=(d/'audit.txt').read_text().splitlines()
    first=[float(x) for x in lines[0].split()]
    rows=[[float(x) for x in line.split()] for line in lines[1:5]]
    assert len(rows)==4 and all(len(z)==7 for z in rows)
    assert first[1]<=1e-12 and first[2]<=1e-12
    assert abs(rows[2][-1])<1e-10
    assert max(max(z[:5]) for z in rows)<1e-7
    return dict(reference_Catm_native_RK_mean=first[0],
        reference_vs_existing_M7_max_abs=first[1],full_replay_vs_reference_max_abs=first[2],
        native_budget_max_residuals={name:row[:5] for name,row in zip(['off','mean','fluctuation','full'],rows)},
        independent_flux_rhs_max_abs={name:row[5] for name,row in zip(['off','mean','fluctuation','full'],rows)},
        actual_forcing_native_time_means={name:row[6] for name,row in zip(['off','mean','fluctuation','full'],rows)},
        native_forcing_additivity_max_increment_error=float(lines[5]))

# A shortened non-production preflight retains the full original spinup.
pre=B/'preflight';pre.mkdir();(pre/'RKmethod.f90').write_text(source)
driver=(B/'replay.f90').read_text()
assert driver.count('nburn=1000000_8,neval=20000000_8')==1
(pre/'replay.f90').write_text(driver.replace('nburn=1000000_8,neval=20000000_8','nburn=10000_8,neval=200000_8'))
subprocess.run(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90','replay.f90','-o','replay'],cwd=pre,check=True)
with (pre/'run.log').open('w') as log:
    subprocess.run([str(pre/'replay'),'0',str(OLD/'data/M7_seed0/states.bin')],cwd=pre,check=True,stdout=log,stderr=subprocess.STDOUT)
pre_audit=parse_audit(pre)
(B/'preflight.json').write_text(json.dumps(pre_audit,indent=2))
print('PREFLIGHT_PASS',pre_audit['full_replay_vs_reference_max_abs'],flush=True)

data=B/'data';data.mkdir()
def run(seed):
    d=data/f'seed{seed}';d.mkdir();start=time.time()
    with (d/'run.log').open('w') as log:
        subprocess.run([str(build/'replay'),str(seed),str(OLD/'data'/f'M7_seed{seed}'/'states.bin')],cwd=d,check=True,stdout=log,stderr=subprocess.STDOUT)
    audit=parse_audit(d)
    files=[]
    for name in ['off','mean','fluctuation','full']:
        p=d/(name+'.bin');assert p.stat().st_size==200001*9*8
        a=np.memmap(p,dtype='<f8',mode='r',shape=(200001,9))
        assert np.isfinite(a).all()
        files.append(dict(case=name,sha256=sha(p),bytes=p.stat().st_size))
    receipt=dict(seed=seed,seconds=time.time()-start,c28=1,
        source_sha256=sha(B/'RKmethod_reference.f90'),driver_sha256=sha(B/'replay.f90'),
        files=files,audit=audit)
    (d/'receipt.json').write_text(json.dumps(receipt,indent=2))
    print('REPLAY_SEED_DONE',seed,round(receipt['seconds'],1),flush=True)
    return receipt
t=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    rows=list(pool.map(run,range(10)))
completion=dict(count=10,cases=4,seconds=time.time()-t,runs=rows,
    entire_evaluation_native_budget_audited=True,
    all_full_replays_exact=all(z['audit']['full_replay_vs_reference_max_abs']==0 for z in rows))
(B/'completion.json').write_text(json.dumps(completion,indent=2))
print('ALL_REPLAYS_COMPLETE',flush=True)
subprocess.run(['/home/b/b382207/conda/envs/yuki/bin/python',str(B/'analyze.py')],cwd=B,check=True)

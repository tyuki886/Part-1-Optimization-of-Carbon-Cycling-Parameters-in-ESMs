from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
from matplotlib.ticker import MaxNLocator
B=Path(__file__).resolve().parent
r=json.loads((B/'factorial_results.json').read_text());f=np.asarray(r['frequency_decade_inverse'])
assert r['audit']['all_full_replays_exact']
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix',
    'font.size':10.5,'axes.labelsize':10,'axes.titlesize':11,
    'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
    'axes.linewidth':.75,'path.simplify':False})
colors=dict(mean='#2D6191',fluctuation='#CE872B',interaction='#79678C',total='#C33E51')
labels=dict(mean='Mean forcing',fluctuation='Fluctuating forcing',interaction='Interaction',total='Combined effect')
fig=plt.figure(figsize=(10.4,4.25));gs=fig.add_gridspec(1,2,width_ratios=[1.65,1.0])
a=fig.add_subplot(gs[0,0]);b=fig.add_subplot(gs[0,1])
for ax in [a,b]:
    ax.spines[['top','right']].set_visible(False)
    ax.set_axisbelow(True)
a.axvspan(.5,.75,color='#E9D9B5',alpha=.32,lw=0)
a.axhline(0,color='#777777',lw=.8,ls='--')
a.grid(axis='y',color='#e9e9e9',lw=.55)
for k,ls,marker in [('mean','-','o'),('fluctuation','--','s'),('interaction',':','^')]:
    z=r['frequency_effects'][k];y=np.asarray(z['mean'])
    a.plot(f,y,color=colors[k],ls=ls,lw=1.5,marker=marker,ms=3,markevery=2,label=labels[k])
a.set_xlim(.5,1.5);a.set_xticks(np.arange(.5,1.51,.2))
a.set_xlabel('Frequency (Decade$^{-1}$)')
a.set_ylabel('PSD change from $c_{24}$-off (%)')
a.set_title('(a) Frequency-resolved contributions',loc='left',pad=10)
a.yaxis.set_major_locator(MaxNLocator(nbins=6))
a.legend(frameon=False,loc='best',fontsize=9)
lo,hi=a.get_ylim();a.set_ylim(lo-(hi-lo)*.07,hi+(hi-lo)*.16)

b.grid(axis='x',color='#e9e9e9',lw=.55)
b.axvline(0,color='#777777',lw=.8,ls='--')
alllo=[];allhi=[]
for j,k in enumerate(['mean','fluctuation','interaction','total']):
    z=r['summary']['low'][k];y=z['mean'];lo,hi=z['ci95'];c=colors[k]
    b.errorbar(y,j,xerr=[[y-lo],[hi-y]],fmt='o',ms=6,color=c,
        ecolor=c,elinewidth=1.4,capsize=3,capthick=1.1,zorder=3)
    b.text(y,j-.23,f'{y:+.2f}%',ha='center',va='center',color=c,fontsize=9.5)
    alllo.append(lo);allhi.append(hi)
b.set_yticks(np.arange(4),[labels[k] for k in ['mean','fluctuation','interaction','total']])
b.set_ylim(3.5,-.65)
lo=min(0,min(alllo));hi=max(0,max(allhi));span=hi-lo
b.set_xlim(lo-.12*span,hi+.15*span)
b.xaxis.set_major_locator(MaxNLocator(nbins=5))
b.set_xlabel('Band-power change from $c_{24}$-off (%)')
b.set_title('(b) Low-band contributions',loc='left',pad=10)
b.text(.98,.98,'0.50–0.75 Decade$^{-1}$',ha='right',va='top',
    transform=b.transAxes,fontsize=9,color='#555555')
fig.subplots_adjust(left=.08,right=.98,bottom=.19,top=.86,wspace=.42)
name='Eta_fixed_signal_factor_separation'
for suffix,dpi in [('',600),('_preview',170)]:
    fig.savefig(B/(name+suffix+'.png'),dpi=dpi,bbox_inches='tight',pad_inches=.08)
plt.close(fig)
manifest=dict(font='Times New Roman; STIX',dpi=600,format='PNG only',
    file=name+'.png',sha256=hashlib.sha256((B/(name+'.png')).read_bytes()).hexdigest(),
    data_sha256=hashlib.sha256((B/'factorial_results.json').read_bytes()).hexdigest(),
    panels=dict(a='Mean paired pointwise factorial effects, all divided by the same off-case PSD; descriptive curves, no pointwise significance claim.',
                b='Factorial effects on 0.5–0.75 decade^-1 integrated eta PSD power, all divided by the same per-IC off-case band power. Horizontal bars: exploratory paired 95% IC bootstrap intervals.'),
    manuscripts_modified=False,old_figures_preserved=True)
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
print('FACTOR_SEPARATION_FIGURE_COMPLETE',flush=True)

from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent
config=dict(c28=1,initial_conditions=10,
    initialization='All original states zero except x2=1+0.001*seed; 10000 TU full-model spinup. All four branches share its entire 18-entry checkpoint.',
    reference='Unmodified current-platform M7 source; verify overlap with all existing 200000-TU M7 trajectories.',
    dt_TU=.01,reference_postspinup_TU=210000,branch_adjustment_TU=10000,evaluation_TU=[10000,210000],
    evaluation_length_TU=200000,windows_per_initial_condition=20,window_length_TU=10000,
    sampling_TU=1,columns=['x1','x2','w','eta','TL','Catm','Cocn','ALK','extra_c24_forcing'],
    cases=dict(off='No extra c24 forcing; retain slm.',
               mean='slm*c24*mu, constant; mu is native RK4-quadrature Catm mean of the same full reference evaluation record.',
               fluctuation='slm*c24*(Catm_reference_stage(t)-mu), with native evaluation mean zero.',
               full='Original slm*(1+c24*Catm_reference_stage(t)); preserve arithmetic and verify exact native-step full-model replay.'),
    kept_dynamic='All carbon states and c16/c17 evolve internally within each branch. Only extra c24 forcing uses the shared prescribed reference signal.',
    replay='Four reference Catm values captured at the exact original RK4 stages each native step; no coarse-sample interpolation.',
    budget='Independent native-stage Catm/Cocn/ALK/weighted-temperature/eta flux checks integrated throughout all evaluation steps, all four cases and ten IC. Sea-land exchange unchanged; same Bcal in Cocn and twice in ALK.',
    low_band_decade_inverse=[.5,.75],sensitivity_bands_decade_inverse=[[.5,.8],[.5,1.5]],
    bootstrap='19999 paired resamples of ten IC, after averaging twenty windows per IC, seed 20261030. Exploratory pointwise 95% intervals.',
    statistics='Mean, fluctuation, interaction and total share the same per-IC off-case power denominator. Explicit interaction retained, no forced allocation shares.',
    scope='Prescribed reference c24-signal response attribution, conditional on reference and active c16/c17. No unique sediment attribution.',
    style=dict(font='Times New Roman',math_font='STIX',dpi=600,format='PNG only',figure_footnotes=False),
    manuscripts_modified=False)
(B/'configuration.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
manifest={n:hashlib.sha256((B/n).read_bytes()).hexdigest() for n in ['RKmethod_reference.f90','replay.f90','run.py','analyze.py','configuration.json','times.ttf']}
(B/'source_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('四组固定信号实验配置已保存，c28=1。')

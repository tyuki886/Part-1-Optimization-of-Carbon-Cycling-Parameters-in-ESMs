from pathlib import Path
import json, numpy as np
from scipy import signal
B=Path(__file__).resolve().parent
p=B/'revised_data.json'; r=json.loads(p.read_text()); s=r['summary']
full=np.asarray(s['low_band_change_percent']['by_initial_condition'])
c24=np.asarray(s['knockout']['c24']['difference_per_common_seven_power_percent']['by_initial_condition'])
x=full-c24
rng=np.random.default_rng(20261029); boot=rng.integers(0,10,(19999,10))
s['c24_off_vs_seven_percent']=dict(mean=float(x.mean()),
    ci95=np.percentile(x[boot].mean(axis=1),[2.5,97.5]).tolist(),
    by_initial_condition=x.tolist())
def stat(v):
    v=np.asarray(v,float)
    return dict(mean=v.mean(axis=0).tolist(),
        ci95=np.percentile(v[boot].mean(axis=1),[2.5,97.5],axis=0).tolist(),
        by_initial_condition=v.tolist())
# The linear forcing c5*w is displayed as eta's input. Keep the complete RHS
# input separately: it contains eta itself, so it must not be called an
# independent external forcing or used to claim causal closure.
linear={}
P=B.parent/'w_feedback_20261029'/'data'
for tag in ['M3','M7']:
    seeds=[]
    for seed in range(10):
        a=np.memmap(P/f'{tag}_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))
        pp=[]
        for j in range(20):
            f,power=signal.welch(a[j*10000+1:(j+1)*10000+1,2],**r['config']['welch'])
            pp.append(power/100)
        seeds.append(np.mean(pp,axis=0))
    linear[tag]=np.asarray(seeds)
fd=f*100; df=fd[1]-fd[0]
display=(fd>=.5-1e-10)&(fd<=1.5+1e-10)
low=(fd>=.5-1e-10)&(fd<=.75+1e-10)
s['c24']['linear_input']=dict(
    band_change_percent=stat(100*(linear['M7'][:,low].sum(axis=1)/linear['M3'][:,low].sum(axis=1)-1)),
    psd_ratio=stat(linear['M7'][:,display]/linear['M3'][:,display]))
p.write_text(json.dumps(r,indent=2))
(B/'summary.json').write_text(json.dumps(s,indent=2))
print('C24_OFF_VS_SEVEN',s['c24_off_vs_seven_percent'],flush=True)
print('C24_LINEAR_INPUT',s['c24']['linear_input']['band_change_percent'],flush=True)

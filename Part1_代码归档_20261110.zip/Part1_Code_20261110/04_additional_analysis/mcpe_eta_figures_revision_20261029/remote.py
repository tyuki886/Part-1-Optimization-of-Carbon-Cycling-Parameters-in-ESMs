from pathlib import Path
import sys, json, shlex, re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_figures_revision_20261029'
c=hpc.connect()
try:
    mode=sys.argv[1]
    if mode=='submit':
        with c.open_sftp() as s:
            try:
                s.stat(R)
                raise RuntimeError('独立目录已存在')
            except FileNotFoundError:
                s.mkdir(R)
            for n in ['analyze.py','times.ttf']:
                s.put(str(B/n),R+'/'+n)
        wrap='export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python analyze.py'
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=4G --time=00:10:00 --job-name=eta_revision --output=analysis-%j.log --wrap='+shlex.quote(wrap)
        rc,out,err=hpc.run(c,cmd)
        if rc: raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'submission.json').write_text(json.dumps(dict(job=job,remote=R,account='ab0246')))
        print(out)
    elif mode in ['status','plot-status']:
        marker='submission.json' if mode=='status' else 'plot_submission.json'
        prefix='analysis' if mode=='status' else 'plot'
        job=json.loads((B/marker).read_text())['job']
        rc,out,err=hpc.run(c,'sacct -n -j '+job+' --format=JobID,State,ExitCode,Elapsed; grep -E "C24_|REVISED_|SPECTRA_DONE|Traceback|Error" '+shlex.quote(R+'/'+prefix+'-'+job+'.log')+' | tail -4')
        print(out)
    elif mode=='fetch':
        with c.open_sftp() as s:
            for n in ['revised_data.json','summary.json']:
                s.get(R+'/'+n,str(B/n))
        print('统计结果已下载')
    elif mode=='plot':
        with c.open_sftp() as s:
            for n in ['plot.py','finalize_data.py']:
                s.put(str(B/n),R+'/'+n)
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=4G --time=00:05:00 --job-name=eta_revised_plot --output=plot-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python finalize_data.py && /home/b/b382207/conda/envs/yuki/bin/python plot.py')
        rc,out,err=hpc.run(c,cmd)
        if rc: raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'plot_submission.json').write_text(json.dumps(dict(job=job,remote=R,account='ab0246')))
        print(out)
    elif mode=='fetch-plot':
        with c.open_sftp() as s:
            for n in ['Eta_phenomenon_revised.png','Eta_phenomenon_revised_preview.png','Eta_feedback_revised.png','Eta_feedback_revised_preview.png','figure_manifest.json']:
                s.get(R+'/'+n,str(B/n))
        print('两张新版PNG已下载')
finally:
    c.close()

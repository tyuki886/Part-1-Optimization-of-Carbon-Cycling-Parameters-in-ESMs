from pathlib import Path
import json, hashlib
import numpy as np
from scipy import signal

B = Path(__file__).resolve().parent
P = B.parent / 'w_feedback_20261029'
WELCH = dict(fs=1., window='hann', nperseg=2500, noverlap=1250,
             detrend='constant', scaling='density')
rng = np.random.default_rng(20261029)
boot = rng.integers(0, 10, size=(19999, 10))

def stat(x):
    x = np.asarray(x, float)
    assert x.shape[0] == 10 and np.isfinite(x).all()
    z = x[boot].mean(axis=1)
    return dict(mean=x.mean(axis=0).tolist(),
                ci95=np.percentile(z, [2.5, 97.5], axis=0).tolist(),
                by_initial_condition=x.tolist())

spectra = {}; peaks = {}; sources = []
tags = [f'M{i}' for i in range(8)] + ['mean', 'anomaly']
for tag in tags:
    spectra[tag] = []; peaks[tag] = []
    for seed in range(10):
        d = P / 'data' / f'{tag}_seed{seed}'
        p = d / 'states.bin'
        receipt = json.loads((d / 'receipt.json').read_text())
        assert receipt['c28'] == 1 and p.stat().st_size == 200001 * 7 * 8
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        assert digest == receipt['states_sha256']
        sources.append(dict(tag=tag, seed=seed, sha256=digest))
        a = np.memmap(p, dtype='<f8', mode='r', shape=(200001, 7))
        pp = []; kk = []
        for j in range(20):
            s = a[j*10000+1:(j+1)*10000+1]
            # eta's complete external input in Gamma*deta/dt = F - Od*eta.
            drive = s[:, 2] + .001 * s[:, 2] * s[:, 3]
            f, power = signal.welch(np.c_[s[:, 3], drive], axis=0, **WELCH)
            fd = f * 100
            sel = (fd >= .5-1e-10) & (fd <= 1.5+1e-10)
            kk.append(float(fd[np.flatnonzero(sel)[np.argmax(power[sel, 0])]]))
            pp.append(power / 100)
        spectra[tag].append(np.mean(pp, axis=0))
        peaks[tag].append(kk)
    spectra[tag] = np.asarray(spectra[tag])
    print('SPECTRA_DONE', tag, flush=True)

df = float(fd[1] - fd[0])
display = (fd >= .5-1e-10) & (fd <= 1.5+1e-10)
low = (fd >= .5-1e-10) & (fd <= .75+1e-10)
lowp = {k: v[:, low, :].sum(axis=1)*df for k, v in spectra.items()}

# One comparison scale for the revised phenomenon panel: pointwise PSD ratio.
ratio = stat(spectra['M7'][:, display, 0] / spectra['M0'][:, display, 0])
low_effect = stat(100*(lowp['M7'][:, 0]/lowp['M0'][:, 0]-1))
old = json.loads((B.parent/'eta_only_test_20261029'/'summary.json').read_text())
assert np.isclose(low_effect['mean'], old['comparison']['low_power']['mean'], rtol=1e-12)

# Peak-window fractions, categorical bars rather than a continuous density.
edges = [.5, .6, .75, 1., 1.5000001]
freq_labels = ['0.50–0.60', '0.60–0.75', '0.75–1.00', '1.00–1.50']
hist = {}
for tag in ['M0', 'M7']:
    values = np.asarray([np.histogram(z, edges)[0]/20*100 for z in peaks[tag]])
    assert np.allclose(values.sum(axis=1), 100)
    hist[tag] = stat(values)
hist_difference = stat(np.asarray(hist['M7']['by_initial_condition'])-
                       np.asarray(hist['M0']['by_initial_condition']))

# Valid whole-feedback interventions, retaining internal exchange and Bcal pairing.
# A positive result means deleting that feedback reduces eta band power.
knockout = {}
for label, off in [('c16','M6'), ('c17','M5'), ('c24','M3')]:
    knockout[label] = dict(
        difference_per_common_seven_power_percent=stat(
            100*(lowp['M7'][:,0]-lowp[off][:,0])/lowp['M0'][:,0]),
        relative_change_on_over_off_percent=stat(
            100*(lowp['M7'][:,0]/lowp[off][:,0]-1)),
        frequency_difference_per_common_seven_psd_percent=stat(
            100*(spectra['M7'][:,display,0]-spectra[off][:,display,0])/
            spectra['M0'][:,display,0]))

# Keep complete-input and output comparisons under the same c24 on/off experiment.
c24 = {}
for name, col in [('eta',0), ('complete_input',1)]:
    c24[name] = dict(
        band_change_percent=stat(100*(lowp['M7'][:,col]/lowp['M3'][:,col]-1)),
        psd_ratio=stat(spectra['M7'][:,display,col]/spectra['M3'][:,display,col]))

split = {}
for tag in ['M7','mean','anomaly']:
    split[tag] = stat(100*(lowp[tag][:,0]/lowp['M3'][:,0]-1))

# Full factorial effect: all four backgrounds for each carbon feedback.
marginals = {}
for bit, label in enumerate(['c16','c17','c24']):
    marginals[label] = []
    for off in range(8):
        if off & (1 << bit):
            continue
        on = off | (1 << bit)
        marginals[label].append(dict(off=off, on=on,
            effect_percent_of_common_seven_power=stat(
                100*(lowp[f'M{on}'][:,0]-lowp[f'M{off}'][:,0])/lowp['M0'][:,0])))

summary = dict(low_band_change_percent=low_effect, knockout=knockout,
               c24=c24, mean_anomaly_controls=split, all_background_marginals=marginals,
               peak_fractions=hist, peak_fraction_difference=hist_difference)
out = dict(frequency=fd[display].tolist(), phenomenon_psd_ratio=ratio,
           peak_categories=freq_labels, summary=summary, sources=sources,
           config=dict(c28=1, initial_conditions=10, windows_per_condition=20,
                       window_TU=10000, sampling_TU=1, welch=WELCH,
                       low_band=[.5,.75], displayed_band=[.5,1.5],
                       uncertainty='19999 paired bootstraps of 10 initial-condition units, after averaging 20 windows within each unit; pointwise exploratory intervals',
                       driving_term='F_eta = c5*w + c6*w*eta; the complete RHS input, not w alone',
                       knockout_scope='Switch c16/c17/c24 off throughout spinup and production. Entire equations retain exchange and sediment stoichiometric pairing. Conditional effects do not add.',
                       causal_limit='Whole-feedback total effects; no unique sediment contribution and no unique mean-versus-anomaly attribution'))
(B/'revised_data.json').write_text(json.dumps(out,indent=2))
(B/'summary.json').write_text(json.dumps(summary,indent=2))
print('SUMMARY', json.dumps(dict(low=low_effect,
    knockout={k:v['difference_per_common_seven_power_percent'] for k,v in knockout.items()},
    input=c24['complete_input']['band_change_percent'])), flush=True)

from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_response_20261029'
c=hpc.connect()
try:
 mode=sys.argv[1]
 if mode=='submit':
  with c.open_sftp() as s:
   try:s.stat(R);raise RuntimeError('独立η响应诊断目录已存在')
   except FileNotFoundError:s.mkdir(R)
   s.put(str(B/'analyze.py'),R+'/analyze.py')
  cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=4G --time=00:05:00 --job-name=eta_response --output=analysis-%j.log --wrap='+shlex.quote('export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python analyze.py')
  rc,out,err=hpc.run(c,cmd)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
 elif mode=='status':
  job=json.loads((B/'submission.json').read_text())['job']
  rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -5 '+shlex.quote(R+'/analysis-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/eta_response_diagnostic.json')+' && echo RESPONSE_COMPLETE')
  print(out)
 elif mode=='fetch':
  with c.open_sftp() as s:s.get(R+'/eta_response_diagnostic.json',str(B/'eta_response_diagnostic.json'))
  print('η方程响应诊断已下载。')
finally:c.close()

from pathlib import Path
import json
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent
P=B.parent/'w_feedback_20261029'
cfg=dict(fs=1.,window='hann',nperseg=2500,noverlap=1250,detrend='constant',scaling='density')
band=(.5,.75)
rng=np.random.default_rng(20261029);boot=rng.integers(0,10,size=(19999,10))
def stats(v):
 v=np.array(v,float)
 return {'mean':float(v.mean()),'ci95':np.percentile(v[boot].mean(axis=1),[2.5,97.5]).tolist(),'by_initial_condition':v.tolist()}
rows={};spectra={}
for label,mask in [('seven',0),('full',7)]:
 rows[label]=[];spectra[label]=[]
 for seed in range(10):
  a=np.memmap(P/'data'/f'M{mask}_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))
  rr=[];ss=[]
  for j in range(20):
   y=a[j*10000+1:(j+1)*10000+1,3]
   z=a[j*10000+1:(j+1)*10000+1,2]
   ybar=float(y.mean());zbar=float(z.mean())
   # Exact scalar eta equation: Gamma*deta/dt = c5*z - (Od-c6*z)*eta.
   # Around fixed window means, a=Od-c6*zbar and b=c5+c6*ybar.
   aa=1.-.001*zbar;bb=1.+.001*ybar;tau=100./aa
   f,py=signal.welch(y,**cfg)
   _,pz=signal.welch(z,**cfg)
   _,cz=signal.csd(z,y,**cfg)
   idx=(f*100>=.5-1e-10)&(f*100<=.75+1e-10);df=f[1]-f[0]
   g_emp=np.abs(cz)**2/np.maximum(pz*pz,1e-300)
   coherent=np.abs(cz)**2/np.maximum(pz,1e-300)
   remain=py-coherent
   assert remain.min()>-1e-10
   g_lin=bb*bb/(aa*aa+(2*np.pi*f*100.)**2)
   pyb=float(py[idx].sum()*df);inputb=float(pz[idx].sum()*df)
   pred=float((g_lin[idx]*pz[idx]).sum()*df)
   nl=.001*((z-zbar)*(y-ybar)-np.mean((z-zbar)*(y-ybar)))
   linear=bb*(z-zbar)
   rr.append({'effective_restoring':aa,'linear_drive_coefficient':bb,'relaxation_TU':tau,
    'eta_band_power':pyb,'effective_drive_band_power':inputb,
    'linearized_eta_band_prediction':pred,'linearized_prediction_error_percent':100*(pred/pyb-1),
    'coherent_eta_band_fraction':float(coherent[idx].sum()*df/pyb),
    'nonlinear_to_linear_drive_rms_ratio':float(np.std(nl)/np.std(linear)),
    'eta_mean':ybar})
   ss.append({'eta':py[idx].tolist(),'drive':pz[idx].tolist(),'empirical_gain':g_emp[idx].tolist(),
    'linearized_gain':g_lin[idx].tolist(),'coherent':coherent[idx].tolist(),'remaining':remain[idx].tolist()})
  rows[label].append({'windows':rr,'mean':{k:float(np.mean([z[k] for z in rr])) for k in rr[0]}})
  spectra[label].append({k:np.mean([np.array(s[k]) for s in ss],axis=0).tolist() for k in ss[0]})
out={}
for key in ['effective_restoring','linear_drive_coefficient','relaxation_TU','eta_band_power','effective_drive_band_power','linearized_eta_band_prediction']:
 out[key+'_relative_change_percent']=stats([100*(rows['full'][i]['mean'][key]/rows['seven'][i]['mean'][key]-1) for i in range(10)])
for label in rows:
 out[label+'_coherent_fraction']=stats([r['mean']['coherent_eta_band_fraction'] for r in rows[label]])
 out[label+'_nonlinear_linear_rms_ratio']=stats([r['mean']['nonlinear_to_linear_drive_rms_ratio'] for r in rows[label]])
 out[label+'_linearized_prediction_error_percent']=stats([r['mean']['linearized_prediction_error_percent'] for r in rows[label]])
# Nonintrusive spectral regression check. This is a statistical factorization,
# not an independently perturbed causal transfer function or energy allocation.
fband=f[idx];dd=f[1]-f[0]
fixed_input_changes=[];fixed_gain_pred_errors=[];gainratios=[];linear_gainratios=[]
for seed in range(10):
 s0=spectra['seven'][seed];s1=spectra['full'][seed]
 # Reconstruct each model exactly as G*D + residual using all window terms.
 # Avoid multiplying separately averaged G,D, which would lose covariance.
 fixed_predictions=[];base_coherent=[];new_coherent=[];rat=[];lrat=[]
 for j in range(20):
  a=np.memmap(P/'data'/f'M0_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))[j*10000+1:(j+1)*10000+1]
  b=np.memmap(P/'data'/f'M7_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))[j*10000+1:(j+1)*10000+1]
  ff,d0=signal.welch(a[:,2],**cfg);_,d1=signal.welch(b[:,2],**cfg)
  _,y0=signal.welch(a[:,3],**cfg);_,y1=signal.welch(b[:,3],**cfg)
  _,c0=signal.csd(a[:,2],a[:,3],**cfg);_,c1=signal.csd(b[:,2],b[:,3],**cfg)
  g0=np.abs(c0)**2/(d0*d0);g1=np.abs(c1)**2/(d1*d1)
  fixed_predictions.append(float((g0[idx]*d1[idx]).sum()*dd))
  base_coherent.append(float((g0[idx]*d0[idx]).sum()*dd));new_coherent.append(float((g1[idx]*d1[idx]).sum()*dd))
  common=(y0[idx]+y1[idx]);common=common/common.sum()
  rat.append(float((common*(g1[idx]/g0[idx])).sum()))
  aa0=rows['seven'][seed]['windows'][j]['effective_restoring'];bb0=rows['seven'][seed]['windows'][j]['linear_drive_coefficient']
  aa1=rows['full'][seed]['windows'][j]['effective_restoring'];bb1=rows['full'][seed]['windows'][j]['linear_drive_coefficient']
  gl0=bb0*bb0/(aa0*aa0+(2*np.pi*ff[idx]*100.)**2)
  gl1=bb1*bb1/(aa1*aa1+(2*np.pi*ff[idx]*100.)**2)
  lrat.append(float((common*(gl1/gl0)).sum()))
 fixed_input_changes.append(100*(np.mean(fixed_predictions)/np.mean(base_coherent)-1))
 fixed_gain_pred_errors.append(100*(np.mean(fixed_predictions)/np.mean(new_coherent)-1))
 gainratios.append(100*(np.mean(rat)-1));linear_gainratios.append(100*(np.mean(lrat)-1))
out['fixed_response_new_drive_predicted_change_percent']=stats(fixed_input_changes)
out['fixed_response_new_drive_prediction_error_vs_full_coherent_percent']=stats(fixed_gain_pred_errors)
out['common_weight_empirical_gain_relative_change_percent']=stats(gainratios)
out['common_weight_linearized_gain_relative_change_percent']=stats(linear_gainratios)
result={'scope':'eta scalar response diagnostics from unchanged full model trajectories; low band 0.5–0.75 decade^-1, 10 initial conditions and 20 windows each',
 'equation':'Gamma*deta/dt=c5*z-(Od-c6*z)*eta, with z the existing eta-driving state; Gamma=100, c5=1, c6=0.001, Od=1 unchanged in both models.',
 'interpretation':'Linearization at each window mean is approximate. Empirical coherent regression is statistical, not an independent causal intervention transfer function. No equations, fluxes, or trajectories were altered.',
 'statistics':out,'data':rows,'band_frequency_TU_inverse':fband.tolist()}
(B/'eta_response_diagnostic.json').write_text(json.dumps(result,indent=2))
print(json.dumps(out,indent=2),flush=True)

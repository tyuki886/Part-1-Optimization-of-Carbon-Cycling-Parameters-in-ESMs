from pathlib import Path
from datetime import datetime
import json,shutil,hashlib
B=Path(__file__).resolve().parent
D=Path(r'D:\科研王！\MCPE\1.0\part12\Part1补充模式诊断_20261028\eta专用检验_20261029')
r=json.loads((B/'eta_response_diagnostic.json').read_text(encoding='utf-8'));s=r['statistics']
def v(k):
 z=s[k];return f"{z['mean']:+.4f}% [{z['ci95'][0]:+.4f}%, {z['ci95'][1]:+.4f}%]"
text=f'''# η低频谱功率增强的方程响应解释

## 核心解释

本次结果更符合：η原有的恢复和响应结构基本保留，但其接收的原低频段驱动更强，因而该频段谱功率增加。它不是η自身响应增益明显提高的证据，也不是已识别出一个新振荡周期的证据。

使用当前一致的七变量等价基准与完整10VCC，各十组初态、每组二十个10000 TU窗口，频带为0.5—0.75 decade⁻¹。只读既有完整轨迹，不改变方程、通量或收支；正式分析在Levante yuki、ab0246完成，作业28544375。

## 方程与近似

η原方程可写成：

    Γ dη/dt = c5 z − (Od−c6 z)η

这里z只表示原方程里已有的η驱动状态。本分析只讨论η，不另展开该状态的谱图。两模式使用相同Γ=100、c5=1、c6=0.001、Od=1。

在各窗口均值附近展开，线性恢复系数为a=Od−c6 mean(z)，线性驱动系数为b=c5+c6 mean(η)，恢复时间τ=Γ/a。忽略小的二阶扰动项时，有近似响应关系：

    Sη(f) ≈ b² Sz(f) / [a²+(2πΓf)²]

频率在该式中使用TU⁻¹。η峰位由驱动谱与响应谱共同决定；Γ不变并不能单独证明所有峰位必须不变。这里的谱功率关系不是物理能量流的守恒分摊。

## 当前长记录的定量结果

| 诊断量 | 10VCC相对七变量等价基准 |
|---|---:|
| η接收的低频驱动功率 | {v('effective_drive_band_power_relative_change_percent')} |
| η实际低频功率 | {v('eta_band_power_relative_change_percent')} |
| η有效恢复系数 | {v('effective_restoring_relative_change_percent')} |
| η有效恢复时间 | {v('relaxation_TU_relative_change_percent')} |
| 共同频率权重下的线性化响应增益平方 | {v('common_weight_linearized_gain_relative_change_percent')} |
| 共同频率权重下的经验响应增益平方 | {v('common_weight_empirical_gain_relative_change_percent')} |

恢复时间只变化约0.0073%，线性化响应增益平方只变化约0.0155%；经验响应增益平方约变化−0.1287%，区间跨零。相较之下，低频驱动功率的变化约+5.82%，量级明显更大。这支持驱动谱变化是η所示频带增强的主要解释，不能解释成η自身的放大能力显著增强。

## 保持旧响应关系的谱重建

按同一Welch设置计算驱动与η的互谱和自谱，得到经验关系H=S_drive,eta/S_drive。保持七变量等价基准的经验增益平方，代入完整10VCC的驱动谱，重建相干响应部分。

- 重建的低频功率增幅为 {v('fixed_response_new_drive_predicted_change_percent')}。
- 实际η增幅约+5.58%，与重建的约+5.74%接近。
- 相对完整模式相干谱功率的重建误差均值为 {v('fixed_response_new_drive_prediction_error_vs_full_coherent_percent')}。
- 该低频段中，η与其已有驱动的线性相干功率比例在两模式均约99.8%。

这是一项非侵入的谱响应诊断，不是独立干预测得的因果传递函数。它说明无需假设η自身响应发生明显变化，就能较好重建所观察到的低频功率增幅；不能据此确定上游碳过程的唯一因果贡献。

按均值线性化的η功率增幅预测约+5.75%；两模式线性化预测相对实际功率的平均误差约−0.49%、−0.26%。η方程中二阶扰动项与线性驱动项的RMS之比约0.049%。这仅说明η在这些轨迹上的局地标量响应可较好近似，不意味着整个耦合模式为线性系统。

## 为什么峰位基本保留

恢复时间与响应谱形的变化很小，而驱动增强位于η原本就有响应的低频段，因此可以出现原有频带功率提高、平均峰位无可分辨系统迁移。这里不把显示频带中的最大值认定为已通过红噪声检验的内禀周期，也不声称每个窗口的峰位完全相同。

## 为什么总方差不一定增加

目标低频带在当前完整估计谱中约占5%左右。一个只占总谱少量的频带增加数个百分点的相对功率，对总谱的直接影响量级仍很小，而且其他频段也可以变化。因此目标频带偏强与总方差没有稳定增大可以同时成立，无需假定物理能量在频段之间严格守恒转移。

## 可以写到哪一步

可写：η原有恢复与响应特征基本保留，低频驱动增强使原有低频段的谱功率提高，主要表现为功率分布的调制。

尚不能写：沉积是唯一主因；碳反馈均值分量或时变分量被唯一确定为主导；已经获得保持物理收支的细分贡献百分比。完整c24反馈开/关已经支持该通路参与，但均值与异常对照仍不足以将上游来源唯一分开。

输出原始JSON为eta_response_diagnostic.json；没有改动论文或既有图件。
'''
(B/'eta响应机理分析.md').write_text(text,encoding='utf-8')
D.mkdir(parents=True,exist_ok=True)
for n in ['eta_response_diagnostic.json','eta响应机理分析.md']:
 target=D/n
 if target.exists():assert target.read_bytes()==(B/n).read_bytes(),'不覆盖不同版本'
 else:shutil.copy2(B/n,target)
Path(r'D:\ClaudeFiles\运行记录\2026-10-29-eta驱动与恢复响应诊断.md').write_text(text,encoding='utf-8')
receipt={'recorded_at':datetime.now().astimezone().isoformat(),'record':str(D/'eta响应机理分析.md'),
 'results_sha256':hashlib.sha256((B/'eta_response_diagnostic.json').read_bytes()).hexdigest(),
 'equations_fluxes_trajectories_unchanged':True,'manuscripts_modified':False}
(B/'delivery_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False,indent=2))

from pathlib import Path
import json, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt, font_manager
from matplotlib.ticker import MultipleLocator

B=Path(__file__).resolve().parent
r=json.loads((B/'revised_data.json').read_text()); s=r['summary']; f=np.asarray(r['frequency'])
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix',
    'font.size':10.5,'axes.labelsize':10,'axes.titlesize':11,
    'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
    'axes.linewidth':.75,'path.simplify':False,'savefig.facecolor':'white'})
blue='#2D6191'; red='#C33E51'; gray='#707070'; gold='#E9D9B5'
manifest=dict(font='Times New Roman; STIX',dpi=600,format='PNG',
    data_sha256=hashlib.sha256((B/'revised_data.json').read_bytes()).hexdigest(),
    manuscripts_modified=False, old_figures_preserved=True, files=[])

def frame(ax,kind='freq'):
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y' if kind=='freq' else 'x',color='#e8e8e8',lw=.55)
    ax.set_axisbelow(True)
    if kind=='freq':
        ax.set_xlim(.5,1.5);ax.set_xticks(np.arange(.5,1.51,.2))
        ax.set_xlabel('Frequency (Decade$^{-1}$)')
        ax.axhline(0,color=gray,lw=.8,ls='--',zorder=1)

def arr(z):
    return np.asarray(z['mean']), np.asarray(z['ci95'])

def save(fig,name):
    for suffix,dpi in [('',600),('_preview',170)]:
        fig.savefig(B/(name+suffix+'.png'),dpi=dpi,bbox_inches='tight',pad_inches=.08)
    manifest['files'].append(dict(file=name+'.png',
        sha256=hashlib.sha256((B/(name+'.png')).read_bytes()).hexdigest()))
    plt.close(fig)

# a-c of the original are replaced by ONE pointwise comparison metric.
# No normalized-share or cumulative-difference percentage is overlaid.
fig=plt.figure(figsize=(10.4,4.1))
gs=fig.add_gridspec(1,2,width_ratios=[1.75,1.0])
a=fig.add_subplot(gs[0,0]); b=fig.add_subplot(gs[0,1])
frame(a);frame(b,'bar')
y,ci=arr(r['phenomenon_psd_ratio']);y=100*(y-1);ci=100*(ci-1)
a.plot(f,y,color=red,lw=1.55,marker='o',ms=2.6,label='10VCC')
a.axhline(0,color=blue,lw=1.1,ls='--',label='Seven-variable reference')
a.set_ylabel('PSD change relative to seven-variable (%)')
a.set_title(r'(a) $\eta$ spectral difference',loc='left',pad=10)
a.legend(frameon=False,loc='lower left',fontsize=8.5)
a.text(.98,.97,f'0.50–0.75 Decade'+r'$^{-1}$'+f' power: {s["low_band_change_percent"]["mean"]:+.1f}%',
    ha='right',va='top',transform=a.transAxes,fontsize=9.5,color=red)
lo=min(ci[0].min(),-8);hi=max(ci[1].max(),12)
a.set_ylim(lo-2,hi+4);a.yaxis.set_major_locator(MultipleLocator(5))

idx=[0,1,2]
labels=['0.50–0.60','0.60–0.75','0.75–1.50']
for tag,offset,color,label,hatch in [('M0',-.17,blue,'Seven-variable','///'),('M7',.17,red,'10VCC',None)]:
    mean=np.asarray(s['peak_fractions'][tag]['mean'])
    ci=np.asarray(s['peak_fractions'][tag]['ci95'])
    values=np.r_[mean[0],mean[1],mean[2]+mean[3]]
    # The last source category is identically zero for every IC; merging is exact.
    assert np.all(np.asarray(s['peak_fractions'][tag]['by_initial_condition'])[:,3]==0)
    errors=np.vstack([values-ci[0,:3],ci[1,:3]-values])
    yp=np.arange(3)+offset
    b.barh(yp,values,height=.27,color=color,alpha=.88,label=label,
           hatch=hatch,edgecolor='white',linewidth=.3)
    b.errorbar(values,yp,xerr=errors,fmt='none',ecolor='#3d3d3d',
        elinewidth=.65,capsize=2,capthick=.65)
    for pos,v,upper in zip(yp,values,ci[1,:3]):
        b.text(upper+1.3,pos,f'{v:g}%',ha='left',va='center',fontsize=9)
b.set_yticks(np.arange(3),labels)
b.invert_yaxis();b.set_xlim(0,86);b.set_xticks([0,20,40,60,80])
b.set_xlabel('Windows with peak in each band (%)')
b.set_ylabel('Peak frequency (Decade$^{-1}$)',labelpad=6)
b.set_title('(b) Peak-frequency distribution',loc='left',pad=10)
b.legend(frameon=False,loc='lower right',fontsize=8.5)
fig.subplots_adjust(left=.075,right=.98,bottom=.18,top=.88,wspace=.38)
save(fig,'Eta_phenomenon_unshaded')

manifest['removed']=['Left-panel pink PSD-interval shading','Left-panel pale-yellow target-band background']
manifest['preserved']=['All curves and numbers','Axis limits and ticks','Fonts and layout','Right-panel bars, hatching and uncertainty intervals']
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
print('UNSHADED_FIGURE_COMPLETE',flush=True)

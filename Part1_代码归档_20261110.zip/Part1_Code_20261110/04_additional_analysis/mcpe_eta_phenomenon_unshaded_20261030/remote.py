from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,r'D:\ClaudeFiles\项目2-Levante超算')
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_phenomenon_unshaded_20261030'
c=hpc.connect()
try:
    mode=sys.argv[1]
    if mode=='submit':
        with c.open_sftp() as s:
            try:s.stat(R);raise RuntimeError('目标已存在，拒绝覆盖')
            except FileNotFoundError:s.mkdir(R)
            for n in ['plot.py','revised_data.json','times.ttf','source_manifest.json']:
                s.put(str(B/n),R+'/'+n)
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=2G --time=00:05:00 --job-name=eta_no_shading --output=plot-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python plot.py')
        rc,out,err=hpc.run(c,cmd)
        if rc:raise RuntimeError(err)
        j=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'submission.json').write_text(json.dumps(dict(job=j,remote=R,account='ab0246')))
        print(out)
    elif mode=='status':
        j=json.loads((B/'submission.json').read_text())['job']
        rc,out,err=hpc.run(c,'sacct -n -j '+j+' --format=JobID,State,ExitCode,Elapsed; grep -E "COMPLETE|Error|Traceback" '+shlex.quote(R+'/plot-'+j+'.log'))
        print(out)
    elif mode=='fetch':
        with c.open_sftp() as s:
            for n in ['Eta_phenomenon_unshaded.png','Eta_phenomenon_unshaded_preview.png','figure_manifest.json']:
                s.get(R+'/'+n,str(B/n))
        print('无阴影版PNG已下载')
finally:c.close()

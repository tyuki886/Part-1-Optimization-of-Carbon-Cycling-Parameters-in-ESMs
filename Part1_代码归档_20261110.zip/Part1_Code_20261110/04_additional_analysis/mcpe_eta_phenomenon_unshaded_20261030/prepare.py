from pathlib import Path
import json,hashlib,shutil
B=Path(__file__).resolve().parent
O=B.parent/'mcpe_eta_figures_revision_20261029'
old=json.loads((O/'figure_manifest.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(O/'revised_data.json')==old['data_sha256']
for n in ['revised_data.json','times.ttf']:
    shutil.copy2(O/n,B/n)
s=(O/'plot.py').read_text(encoding='utf-8')
cut='\n# Mechanism evidence is now an actual whole-feedback intervention'
assert s.count(cut)==1
s=s.split(cut)[0]
yellow="        ax.axvspan(.5,.75,color=gold,alpha=.32,lw=0,zorder=0)\n"
pink="a.fill_between(f,ci[0],ci[1],color=red,alpha=.12,lw=0)\n"
assert s.count(yellow)==1 and s.count(pink)==1
s=s.replace(yellow,'').replace(pink,'')
s=s.replace("save(fig,'Eta_phenomenon_revised')","save(fig,'Eta_phenomenon_unshaded')")
s+='''
manifest['removed']=['Left-panel pink PSD-interval shading','Left-panel pale-yellow target-band background']
manifest['preserved']=['All curves and numbers','Axis limits and ticks','Fonts and layout','Right-panel bars, hatching and uncertainty intervals']
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
print('UNSHADED_FIGURE_COMPLETE',flush=True)
'''
(B/'plot.py').write_text(s,encoding='utf-8')
(B/'source_manifest.json').write_text(json.dumps(dict(
    original_plot_sha256=sha(O/'plot.py'),original_png_sha256=sha(O/'Eta_phenomenon_revised.png'),
    unchanged_data_sha256=sha(B/'revised_data.json'),font_sha256=sha(B/'times.ttf'),
    updated_plot_sha256=sha(B/'plot.py'),numerical_analysis_repeated=False),indent=2))
print('仅移除左图两类底色，保留原轴范围与右图。')

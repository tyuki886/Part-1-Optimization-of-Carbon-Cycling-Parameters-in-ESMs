from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,time,os
import numpy as np
B=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=(B/'RKmethod_reference.f90').read_text()
assert 'c28=1.0_dp' in source
assert source.count('if(n>=9) ds(2)=ds(2)+c16*s(8)')==1
assert source.count('sm*(1.0+c17*s(8))')==1
assert source.count('slm*(1.0+c24*s(8))')==1
(B/'builds').mkdir();(B/'data').mkdir()
for mask in range(8):
    d=B/'builds'/f'M{mask}';d.mkdir()
    s=source
    if not mask&1:s=s.replace('if(n>=9) ds(2)=ds(2)+c16*s(8)','! carbon feedback to x2 disabled')
    if not mask&2:s=s.replace('sm*(1.0+c17*s(8))','sm')
    if not mask&4:s=s.replace('slm*(1.0+c24*s(8))','slm')
    (d/'RKmethod.f90').write_text(s)
    subprocess.run(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90',str(B/'experiment.f90'),'-o','experiment'],cwd=d,check=True)
    (d/'source_audit.json').write_text(json.dumps({'mask':mask,'c28':1,'source_sha256':sha(d/'RKmethod.f90'),'binary_sha256':sha(d/'experiment')},indent=2))
identity=B/'identity';identity.mkdir()
(identity/'RKmethod.f90').write_text(source)
off=(B/'builds/M0/RKmethod.f90').read_text().replace('module RKmethod','module Off_reference',1)
(identity/'Off_reference.f90').write_text(off)
subprocess.run(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90','Off_reference.f90',str(B/'identity.f90'),'-o','identity_check'],cwd=identity,check=True)
subprocess.run([str(identity/'identity_check')],cwd=identity,check=True)
def run(item):
    mask,seed=item;d=B/'data'/f'M{mask}_seed{seed}';d.mkdir();start=time.time()
    with (d/'run.log').open('w') as f:subprocess.run([str(B/'builds'/f'M{mask}'/'experiment'),str(seed),'10'],cwd=d,check=True,stdout=f,stderr=subprocess.STDOUT)
    p=d/'states.bin';assert p.stat().st_size==200001*7*8
    a=np.memmap(p,dtype='<f8',mode='r',shape=(200001,7));assert np.isfinite(a).all()
    row={'mask':mask,'seed':seed,'c28':1,'seconds':time.time()-start,'source_sha256':sha(B/'builds'/f'M{mask}'/'RKmethod.f90'),'states_sha256':sha(p)}
    (d/'receipt.json').write_text(json.dumps(row,indent=2));print('RUN_DONE',mask,seed,round(row['seconds'],1),flush=True);return row
start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:receipts=list(pool.map(run,[(m,s) for s in range(10) for m in range(8)]))
(B/'completion.json').write_text(json.dumps({'runs':receipts,'seconds':time.time()-start,'count':len(receipts)},indent=2))
subprocess.run(['/home/b/b382207/conda/envs/yuki/bin/python',str(B/'analyze.py')],cwd=B,check=True)
print('ALL_DONE',flush=True)

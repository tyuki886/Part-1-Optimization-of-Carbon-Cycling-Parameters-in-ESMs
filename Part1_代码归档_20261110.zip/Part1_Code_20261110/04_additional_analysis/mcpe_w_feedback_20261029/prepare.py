from pathlib import Path
import shutil,json,hashlib
B=Path(__file__).resolve().parent
P=Path(r'D:\ClaudeFiles\项目2-Levante超算\MCPE26.0_C81\paper_revision_20260915\c28_mechanism_diagnostic')
T=Path(r'D:\ClaudeFiles\mcpe_eta_peak_20261028')
sources=[]
for src,dest in [(P/'RKmethod_reference.f90','RKmethod_reference.f90'),(T/'times.ttf','times.ttf')]+[(T/f,f) for f in ['w7.txt','w10.txt','eta7.txt','eta10.txt','eta_peak_results.json']]:
    shutil.copy2(src,B/dest)
    sources.append({'source':str(src),'copy':dest,'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
config={'c28':1,'feedbacks':{'bit0':'c16 Catm -> x2','bit1':'sm c17 Catm -> w','bit2':'slm c24 Catm -> TL'},'masks':list(range(8)),'initial_conditions':[{'seed':s,'x2_initial':1+.001*s,'other_state_initial':0} for s in range(10)],'spinup_TU':10000,'postspinup_TU':200000,'dt_TU':.01,'sampling_TU':1,'original_figure_window_TU_inclusive':[10000,20000],'robustness_windows':'20 consecutive nonoverlapping (j*10000,(j+1)*10000] TU windows in each initial-condition realization; uncertainty resamples 10 initial-condition units only','target_frequency_TU_inverse':.0056,'target_frequency_year_inverse':.056,'target_frequency_decade_inverse':.56,'w_band_year_inverse':[.05,.15],'eta_band_decade_inverse':[.5,1.5],'welch':{'fs':1,'window':'hann','nperseg':2500,'noverlap':1250,'detrend':'constant','scaling':'spectrum'},'intervention_timing':'Each feedback setting applies throughout its spinup and analysis integration, matching original model comparison; no assimilation.','frozen_values':'none','storage_columns':['x1','x2','w','eta','TL','Catm','x1(TL-w)']}
(B/'configuration.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
(B/'source_manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
print('Prepared exact source, archive checkpoints, font and fixed analysis design.')

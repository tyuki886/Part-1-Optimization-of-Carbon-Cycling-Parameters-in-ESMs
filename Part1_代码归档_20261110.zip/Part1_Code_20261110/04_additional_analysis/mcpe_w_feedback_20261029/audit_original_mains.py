from pathlib import Path
import subprocess,json,hashlib
import numpy as np
B=Path(__file__).resolve().parent
audit={}
for n,m in [(7,0),(10,7)]:
    d=B/f'original_main_audit_{n}';d.mkdir()
    source=(B/f'RK4main{n}_archive.f90').read_text()
    assert 'step_total = 200000000_8' in source
    short=source.replace('step_total = 200000000_8','step_total = 2000000_8')
    (d/'main.f90').write_text(short)
    subprocess.run(['gfortran','-O3','-ffree-line-length-none',str(B/'RKmethod_reference.f90'),'main.f90','-o','original_main'],cwd=d,check=True)
    with (d/'run.log').open('w') as f:subprocess.run([str(d/'original_main')],cwd=d,stdout=f,stderr=subprocess.STDOUT,check=True)
    a=np.memmap(B/'data'/f'M{m}_seed0'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))
    w=np.loadtxt(d/f'wTL_{n}var.txt');eta=np.loadtxt(d/('eta_7var.txt' if n==7 else 'etaCatm_10var.txt'))
    assert np.array_equal(w[:,0],np.arange(1,20001))
    dw=float(np.max(np.abs(w[:,1]-a[1:20001,2])));de=float(np.max(np.abs(eta[:,1]-a[1:20001,3])))
    assert dw<1e-10 and de<1e-10,(n,dw,de)
    audit[str(n)]={'w_max_abs':dw,'eta_max_abs':de,'modification':'Only shorten postspinup duration from 2000000 to 20000 TU; original driver and source otherwise preserved.','original_main_sha256':hashlib.sha256((B/f'RK4main{n}_archive.f90').read_bytes()).hexdigest()}
out={'same_source_shortened_original_mains_reproduce_new_driver':True,'comparisons':audit,'compiler':subprocess.check_output(['gfortran','--version'],text=True).splitlines()[0],'meaning':'Checks the new driver against the original main on the current platform; does not claim bitwise reproduction of the old-platform trajectory.'}
(B/'same_source_driver_audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)
subprocess.run(['/home/b/b382207/conda/envs/yuki/bin/python',str(B/'analyze.py')],cwd=B,check=True)

from pathlib import Path
import json,hashlib
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
B=Path(__file__).resolve().parent
r=json.loads((B/'feedback_results.json').read_text());original=r['original_window']
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'axes.linewidth':.75,'path.simplify':False})
blue='#24578D';red='#C6324B';gold='#B77A22';gray='#808080'
fig,axes=plt.subplots(2,2,figsize=(8.2,6.0));axes=axes.ravel()
cfg=dict(fs=1.,window='hann',nperseg=2500,noverlap=1250,detrend='constant',scaling='spectrum')
maxp=0.
for n,col,ls,label in [(7,blue,'--','Seven-variable archive'),(10,red,'-','10VCC archive')]:
    z=np.loadtxt(B/f'w{n}.txt')[:,1];f,p=signal.welch(z-z.mean(),**cfg);fx=f*10
    axes[0].plot(fx,p,c=col,ls=ls,lw=1,label=label);mask=(fx>=.05)&(fx<=.15);maxp=max(maxp,float(p[mask].max()))
axes[0].set_xlim(.05,.15);axes[0].set_ylim(0,maxp*1.16);axes[0].set_xlabel(r'Frequency (Year$^{-1}$)');axes[0].set_ylabel('Spectral power');axes[0].set_title('(a) Archived realization: low-frequency $w$',pad=5);axes[0].axvline(.056,c='#555555',ls=':',lw=.8);axes[0].text(.12,.92,'17.86 years',transform=axes[0].transAxes,fontsize=8);axes[0].ticklabel_format(axis='y',style='sci',scilimits=(-2,2));axes[0].grid(alpha=.18,ls=':')
labels=['None','16','17','16+17','24','16+24','17+24','All']
values=[original[str(m)]['w_point']/original['0']['w_point'] for m in range(8)]
axes[1].bar(range(8),values,color=[gray]*7+[red],width=.68)
axes[1].set_xticks(range(8),labels,rotation=35,ha='right');axes[1].axhline(1,c='#333333',ls='--',lw=.8)
axes[1].set_xlabel('Active feedback coefficients');axes[1].set_ylabel('Power / all-feedback-off power');axes[1].set_title('(b) New-platform replicate: 8 settings',pad=5);axes[1].set_ylim(0,max(values)*1.20)
for i,v in enumerate(values):axes[1].text(i,v+max(values)*.025,f'{v:.2f}',ha='center',fontsize=7)
channels=['c16','c17','c24'];v=[r['single_channel_off']['w_point'][x]['original_change_percent_vs_full'] for x in channels]
axes[2].bar(range(3),v,color=[blue if x<0 else gold for x in v],width=.6)
axes[2].axhline(0,c='#333333',lw=.8);axes[2].set_xticks(range(3),[r'No $c_{16}$',r'No $c_{17}$',r'No $c_{24}$']);axes[2].set_ylabel('Change from full feedback (%)');axes[2].set_title('(c) Replicate window: individual switch-off',pad=5)
span=max(max(v),0)-min(min(v),0);pad=max(span*.12,3)
axes[2].set_ylim(min(min(v),0)-pad,max(max(v),0)+pad)
for i,x in enumerate(v):axes[2].text(i,x+(pad*.20 if x>=0 else -pad*.20),f'{x:+.1f}%',ha='center',va='bottom' if x>=0 else 'top',fontsize=8)
for dx,metric,color,marker,label in [(-.09,'w_point',blue,'o','At 17.86 years'),(.09,'w_band',gold,'s','0.05–0.15 year$^{-1}$ band')]:
    means=[];lo=[];hi=[]
    for c in channels:
        z=r['single_channel_off'][metric][c]['long_record_change_percent_vs_full'];means.append(z['mean']);lo.append(z['mean']-z['ci95'][0]);hi.append(z['ci95'][1]-z['mean'])
    axes[3].errorbar(np.arange(3)+dx,means,yerr=[lo,hi],fmt=marker,c=color,capsize=3,ms=4,lw=1,label=label)
axes[3].axhline(0,c='#333333',lw=.8);axes[3].set_xticks(range(3),[r'No $c_{16}$',r'No $c_{17}$',r'No $c_{24}$']);axes[3].set_ylabel('Change from full feedback (%)');axes[3].set_title('(d) Long-record switch-off effects',pad=5);axes[3].legend(loc='best',frameon=False,fontsize=7)
handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,.94))
fig.suptitle('Carbon-feedback controls on decadal surface-ocean variability',fontsize=12.5,y=.99)
fig.subplots_adjust(left=.09,right=.985,bottom=.10,top=.82,hspace=.62,wspace=.34)
name='W_feedback_pathways_20261029'
fig.savefig(B/(name+'.png'),dpi=600,bbox_inches='tight',pad_inches=.06);fig.savefig(B/(name+'_preview.png'),dpi=160,bbox_inches='tight',pad_inches=.06)
manifest={'file':name+'.png','sha256':hashlib.sha256((B/(name+'.png')).read_bytes()).hexdigest(),'dpi':600,'font':'Times New Roman; STIX math','panels':{'a':'Original archived realization only; different from the new-platform replicate in b/c.','b':'New-platform seed0, same 10000--20000 TU time bounds, all eight factorial settings; relative to all off.','c':'New-platform seed0, conditional switch-off effect at fixed .056 year^-1, relative to all on.','d':'Each initial condition first averages 20 windows; points are means of 10 paired initial-condition percent changes, bars pointwise 95% bootstrap intervals. Consecutive windows are not independent bootstrap units.'},'data_source':'feedback_results.json and original w7/w10 window extracts','no_original_paper_modified':True}
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print('FIGURE_DONE',flush=True)

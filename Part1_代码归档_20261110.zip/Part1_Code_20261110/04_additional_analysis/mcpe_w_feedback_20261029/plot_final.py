from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
B=Path(__file__).resolve().parent
r=json.loads((B/'feedback_results.json').read_text());split=json.loads((B/'mean_split_results.json').read_text())
assert r['archive_reproduction']['10']['archive_trajectory_reproduced']
assert r['all_feedback_off_identity_max_abs']==0
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'axes.linewidth':.75,'path.simplify':False})
blue='#24578D';red='#C6324B';gold='#B77A22'
fig,axs=plt.subplots(2,2,figsize=(8.2,6.1));axs=axs.ravel()
channels=['c16','c17','c24'];x=np.arange(3)
for dx,metric,color,label in [(-.18,'w_point',blue,r'$w$'),(.18,'eta_point',red,r'$\eta$')]:
    v=[r['single_channel_off'][metric][c]['original_change_percent_vs_full'] for c in channels]
    axs[0].bar(x+dx,v,width=.34,color=color,label=label)
    for xx,yy in zip(x+dx,v):axs[0].text(xx,yy-1,f'{yy:+.1f}',ha='center',va='top',fontsize=7)
axs[0].set_title('(a) Original 10VCC window: switch-off',pad=5);axs[0].set_xticks(x,[r'No $c_{16}$',r'No $c_{17}$',r'No $c_{24}$']);axs[0].set_ylabel('Point-power change (%)');axs[0].axhline(0,c='#333333',lw=.8);axs[0].set_ylim(min(axs[0].get_ylim()[0]-7,-10),8);axs[0].legend(frameon=False,loc='lower right',ncol=2)
for dx,metric,color,marker,label in [(-.09,'w_point',blue,'o','At 17.86 years'),(.09,'w_band',gold,'s','0.05–0.15 year$^{-1}$ band')]:
    means=[];lo=[];hi=[]
    for c in channels:
        z=r['single_channel_off'][metric][c]['long_record_change_percent_vs_full'];means.append(z['mean']);lo.append(z['mean']-z['ci95'][0]);hi.append(z['ci95'][1]-z['mean'])
    axs[1].errorbar(x+dx,means,yerr=[lo,hi],fmt=marker,c=color,capsize=3,ms=4,lw=1,label=label)
axs[1].set_title('(b) Long-record $w$ switch-off effects',pad=5);axs[1].set_xticks(x,[r'No $c_{16}$',r'No $c_{17}$',r'No $c_{24}$']);axs[1].set_xlim(-.5,2.5);axs[1].set_ylabel('Change from full feedback (%)');axs[1].axhline(0,c='#333333',lw=.8);axs[1].legend(frameon=False,loc='upper center',fontsize=7);lo,hi=axs[1].get_ylim();axs[1].set_ylim(lo,hi+(hi-lo)*.28)
zs=r['all_background_marginals']['w_band']['c24'];means=[z['long_record_increase_per_off_reference_percent']['mean'] for z in zs];cis=np.array([z['long_record_increase_per_off_reference_percent']['ci95'] for z in zs])
axs[2].bar(range(4),means,color='#777777',width=.62)
axs[2].errorbar(range(4),means,yerr=[np.array(means)-cis[:,0],cis[:,1]-means],fmt='none',c='#222222',capsize=3,lw=.9)
axs[2].set_title(r'(c) $c_{24}$ across feedback backgrounds',pad=5);axs[2].set_xticks(range(4),['None',r'$c_{16}$',r'$c_{17}$',r'$c_{16}$ + $c_{17}$']);axs[2].set_xlabel('Other active feedbacks');axs[2].set_ylabel('Increase / all-off reference power (%)');axs[2].axhline(0,c='#333333',lw=.8);axs[2].set_ylim(0,max(cis[:,1])*1.16)
for i,v in enumerate(means):axs[2].text(i,.2,f'{v:.2f}',ha='center',color='white',fontsize=8)
keys=['full','mean','anomaly'];zs=[split['summary']['w_band'][k] for k in keys];means=np.array([z['mean'] for z in zs]);cis=np.array([z['ci95'] for z in zs])
axs[3].bar(range(3),means,color=['#444444','#888888','#BBBBBB'],width=.62)
axs[3].errorbar(range(3),means,yerr=[means-cis[:,0],cis[:,1]-means],fmt='none',c='#222222',capsize=3,lw=.9)
axs[3].set_xticks(range(3),['Full $c_{24}$','Fixed mean','Reference\nanomaly']);axs[3].set_ylabel('Band-power change from no $c_{24}$ (%)');axs[3].set_title(r'(d) Mean and variable $c_{24}$ forcing',pad=5);axs[3].axhline(0,c='#333333',lw=.8);axs[3].set_ylim(min(0,float(cis[:,0].min())),float(cis[:,1].max())*1.16)
for i,v in enumerate(means):axs[3].text(i+(.16 if i==2 else 0),.15,f'{v:+.2f}',ha='center',color='white' if i<2 else '#222222',fontsize=8)
fig.suptitle('Carbon-feedback controls on decadal ocean variability',fontsize=12.5,y=.98)
fig.subplots_adjust(left=.10,right=.985,bottom=.11,top=.87,hspace=.48,wspace=.35)
name='W_feedback_pathways_20261029'
fig.savefig(B/(name+'.png'),dpi=600,bbox_inches='tight',pad_inches=.06);fig.savefig(B/(name+'_preview.png'),dpi=160,bbox_inches='tight',pad_inches=.06)
manifest={'file':name+'.png','sha256':hashlib.sha256((B/(name+'.png')).read_bytes()).hexdigest(),'dpi':600,'font':'Times New Roman; STIX math','panels':{'a':'At fixed 0.056 year^-1 = 0.56 decade^-1, compare three individually disabled feedback configurations with full 10VCC in 10000--20000 TU. Full 10VCC reproduces the archived realization. Switches apply throughout separate spinup and integration.','b':'Each initial condition first averages 20 windows; points are means of 10 paired initial-condition percent changes, bars pointwise 95% bootstrap intervals. Blue: fixed-frequency w power; gold: w power integrated over 0.05--0.15 year^-1.','c':'Turn c24 on in each of four c16/c17 backgrounds; normalize the power difference by the all-feedback-off reference within each initial condition. Same band as b. This is not a unique physical energy allocation.','d':'Compare full, fixed-reference mean, and fixed-reference anomaly c24 interventions with c24 off, keeping c16/c17 dynamic. Nonlinear interventions are not additive.'},'archive_warning':'Full 10VCC trajectory reproduced; the old seven-variable trajectory was not reproduced pointwise on the current platform. Long-record baseline uses the self-consistent current-platform all-feedback-off configuration, verified equivalent to seven-variable equations.','data_source':['feedback_results.json','mean_split_results.json'],'no_original_paper_modified':True}
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print('FIGURE_DONE',flush=True)

from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/w_feedback_20261029'
c=hpc.connect()
try:
    mode=sys.argv[1]
    if mode=='submit':
        rc,space,err=hpc.run(c,'df -Pk '+shlex.quote('/work/ab0246/wuyuhang'))
        if rc:raise RuntimeError(err)
        available=int(space.strip().splitlines()[-1].split()[3])*1024
        if available<3_000_000_000:raise RuntimeError('Insufficient free filesystem space for the independent diagnostic.')
        with c.open_sftp() as s:
            try:s.stat(R);raise RuntimeError('Independent directory already exists')
            except FileNotFoundError:s.mkdir(R)
            names=['RKmethod_reference.f90','experiment.f90','identity.f90','run_experiment.py','analyze.py','times.ttf','configuration.json','source_manifest.json','w7.txt','w10.txt','eta7.txt','eta10.txt','eta_peak_results.json']
            for n in names:s.put(str(B/n),R+'/'+n)
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=4 --mem=4G --time=00:15:00 --job-name=w_feedback --output=compute-%j.log --wrap='+shlex.quote('export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python run_experiment.py')
        rc,out,err=hpc.run(c,cmd)
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
    elif mode=='audit-and-analyze':
        with c.open_sftp() as s:
            for n in ['audit_original_mains.py','analyze.py','RK4main7_archive.f90','RK4main10_archive.f90']:s.put(str(B/n),R+'/'+n)
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=4G --time=00:05:00 --job-name=w_driver_audit --output=compute-%j.log --wrap='+shlex.quote('export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python audit_original_mains.py')
        rc,out,err=hpc.run(c,cmd)
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'analysis_submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
    elif mode=='mean-split':
        with c.open_sftp() as s:s.put(str(B/'mean_split.py'),R+'/mean_split.py')
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=4 --mem=4G --time=00:10:00 --job-name=w_c24_split --output=split-%j.log --wrap='+shlex.quote('export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python mean_split.py')
        rc,out,err=hpc.run(c,cmd)
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'split_submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
    elif mode=='split-status':
        job=json.loads((B/'split_submission.json').read_text())['job']
        rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -7 '+shlex.quote(R+'/split-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/mean_split_results.json')+' && echo SPLIT_ANALYSIS_DONE')
        print(out);print(err.strip())
    elif mode=='fetch-split':
        with c.open_sftp() as s:s.get(R+'/mean_split_results.json',str(B/'mean_split_results.json'))
        print('SPLIT_DOWNLOADED')
    elif mode=='status':
        marker=B/'analysis_submission.json' if (B/'analysis_submission.json').exists() else B/'submission.json'
        job=json.loads(marker.read_text())['job']
        rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -7 '+shlex.quote(R+'/compute-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/summary.json')+' && echo ANALYSIS_DONE')
        print(out);print(err.strip())
    elif mode=='fetch':
        with c.open_sftp() as s:
            for n in ['feedback_results.json','original_spectra.json','summary.json','completion.json','same_source_driver_audit.json']:s.get(R+'/'+n,str(B/n))
        print('DOWNLOADED')
    elif mode=='plot':
        with c.open_sftp() as s:s.put(str(B/'plot_final.py'),R+'/plot.py')
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=2G --time=00:05:00 --job-name=w_feedback_plot --output=plot-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python plot.py')
        rc,out,err=hpc.run(c,cmd)
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'plot_submission.json').write_text(json.dumps({'job':job,'remote':R},indent=2));print(out)
    elif mode=='plot-status':
        job=json.loads((B/'plot_submission.json').read_text())['job']
        rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -7 '+shlex.quote(R+'/plot-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/figure_manifest.json')+' && echo FIGURE_DONE')
        print(out);print(err.strip())
    elif mode=='fetch-plot':
        with c.open_sftp() as s:
            for n in ['W_feedback_pathways_20261029.png','W_feedback_pathways_20261029_preview.png','figure_manifest.json']:s.get(R+'/'+n,str(B/n))
        print('FIGURE_DOWNLOADED')
finally:c.close()

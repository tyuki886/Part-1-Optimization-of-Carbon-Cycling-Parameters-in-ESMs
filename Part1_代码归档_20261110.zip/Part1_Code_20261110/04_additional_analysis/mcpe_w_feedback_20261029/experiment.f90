program feedback_experiment
 use RKmethod
 implicit none
 integer(kind=8)::i,spin_up=1000000_8,step_total=20000000_8
 integer::n,seed,u
 real(dp)::x(18),row(7)
 character(len=32)::arg
 call get_command_argument(1,arg);read(arg,*)seed
 call get_command_argument(2,arg);read(arg,*)n
 x=0._dp;x(2)=1._dp+.001_dp*seed
 do i=1,spin_up
   call adv_true_state(x,i,n)
 enddo
 open(newunit=u,file='states.bin',access='stream',form='unformatted',status='new')
 row=[x(1),x(2),x(4),x(5),x(7),x(8),x(1)*(x(7)-x(4))];write(u)row
 do i=1,step_total
   call adv_true_state(x,i,n)
   if(mod(i,100_8)==0)then
     row=[x(1),x(2),x(4),x(5),x(7),x(8),x(1)*(x(7)-x(4))];write(u)row
   endif
 enddo
 close(u)
 print *,'DONE',seed,n,x(4),x(5)
end program

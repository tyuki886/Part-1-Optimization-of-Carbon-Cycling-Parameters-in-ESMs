from pathlib import Path
import json,math
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent
cfg=dict(fs=1.,window='hann',nperseg=2500,noverlap=1250,detrend='constant',scaling='spectrum')
data={(m,s):np.memmap(B/'data'/f'M{m}_seed{s}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7)) for m in range(8) for s in range(10)}
old=json.loads((B/'eta_peak_results.json').read_text())
reproduction={}
for m,n in [(0,7),(7,10)]:
    w=np.loadtxt(B/f'w{n}.txt');e=np.loadtxt(B/f'eta{n}.txt');a=data[m,0][10000:20001]
    dw=float(np.max(np.abs(w[:,1]-a[:,2])));de=float(np.max(np.abs(e[:,1]-a[:,3])))
    reproduction[str(n)]={'w_archive_max_abs':dw,'eta_archive_max_abs':de,'archive_trajectory_reproduced':bool(dw<1e-10 and de<1e-10)}
def metrics(a,include_spectrum=False):
    out={};curves={}
    for name,col in [('w',2),('eta',3)]:
        f,p=signal.welch(a[:,col]-np.mean(a[:,col]),**cfg)
        k=int(np.argmin(abs(f-.0056)));assert abs(f[k]-.0056)<1e-12
        band=(f*100>=.5)&(f*100<=1.5)
        out[name+'_point']=float(p[k]);out[name+'_band']=float(p[band].sum()/1.5)
        if include_spectrum:curves[name]={'frequency_year_inverse':(f[f<=.015]*10).tolist(),'power':p[f<=.015].tolist()}
    out.update({'w_mean':float(a[:,2].mean()),'eta_mean':float(a[:,3].mean()),'Catm_mean':float(a[:,5].mean())})
    return (out,curves) if include_spectrum else out
original={};curves={};blocks={};seed_means={}
for m in range(8):
    v,c=metrics(data[m,0][10000:20001],True);original[str(m)]=v;curves[str(m)]=c
    for s in range(10):
        rr=[metrics(data[m,s][j*10000+1:(j+1)*10000+1]) for j in range(20)]
        blocks[f'{m}_{s}']=rr;seed_means[f'{m}_{s}']={k:float(np.mean([z[k] for z in rr])) for k in rr[0]}
driver_audit=json.loads((B/'same_source_driver_audit.json').read_text())
assert driver_audit['same_source_shortened_original_mains_reproduce_new_driver']
rng=np.random.default_rng(20261029);boot=rng.integers(0,10,size=(19999,10))
def stats(x):
    x=np.asarray(x,float);return {'mean':float(x.mean()),'ci95':np.percentile(x[boot].mean(1),[2.5,97.5]).tolist(),'by_initial_condition':x.tolist()}
metrics_keys=['w_point','w_band','eta_point','eta_band']
single_off={};overall={};marginal={};shapley={}
for metric in metrics_keys:
    baseline=original['0'][metric];full=original['7'][metric]
    overall[metric]={'original_ratio_all_on_over_off':full/baseline,'long_record_ratio':stats([seed_means[f'7_{s}'][metric]/seed_means[f'0_{s}'][metric] for s in range(10)]),'original_seed_block_ratios':[blocks[f'7_0'][j][metric]/blocks[f'0_0'][j][metric] for j in range(20)]}
    single_off[metric]={};marginal[metric]={}
    for bit,label in enumerate(['c16','c17','c24']):
        without=7^(1<<bit)
        single_off[metric][label]={'mask_without':without,'original_change_percent_vs_full':100*(original[str(without)][metric]/full-1),'long_record_change_percent_vs_full':stats([100*(seed_means[f'{without}_{s}'][metric]/seed_means[f'7_{s}'][metric]-1) for s in range(10)])}
        marginal[metric][label]=[]
        for mask in range(8):
            if mask&(1<<bit):continue
            on=mask|(1<<bit)
            marginal[metric][label].append({'background_mask':mask,'on_mask':on,'original_increase_per_off_reference_percent':100*(original[str(on)][metric]-original[str(mask)][metric])/baseline,'long_record_increase_per_off_reference_percent':stats([100*(seed_means[f'{on}_{s}'][metric]-seed_means[f'{mask}_{s}'][metric])/seed_means[f'0_{s}'][metric] for s in range(10)])})
    shares={}
    for bit,label in enumerate(['c16','c17','c24']):
        contribution=0.
        for mask in range(8):
            if mask&(1<<bit):continue
            n=bin(mask).count('1');weight=math.factorial(n)*math.factorial(2-n)/6
            contribution+=weight*(original[str(mask|(1<<bit))][metric]-original[str(mask)][metric])
        shares[label]={'power_change':contribution,'per_off_reference_percent':100*contribution/baseline}
    assert np.isclose(sum(r['power_change'] for r in shares.values()),full-baseline,rtol=1e-10,atol=1e-12)
    shapley[metric]=shares
result={'configuration':json.loads((B/'configuration.json').read_text()),'archive_reproduction':reproduction,'same_source_driver_audit':driver_audit,'all_feedback_off_identity_max_abs':float(np.loadtxt(B/'identity/identity.txt')),'original_window':original,'window_label_warning':'original_window means the same time bounds 10000--20000 TU in the new-platform controlled replicate. The old archived trajectory was NOT pointwise reproduced; this replicate must not be presented as the original figure realization.','overall':overall,'single_channel_off':single_off,'all_background_marginals':marginal,'original_window_shapley':shapley,'seed_means':seed_means,'blocks':blocks,'uncertainty':'Exploratory pointwise paired initial-condition bootstrap, 19999 resamples of 10 initial-condition units; each unit first averages its 20 consecutive windows. No resampling of consecutive windows as independent seeds.','shapley_limit':'An allocation of the factorial counterfactual difference, including distributed interactions; not a unique physical energy partition.'}
(B/'feedback_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(B/'original_spectra.json').write_text(json.dumps(curves),encoding='utf-8')
summary={'archive_reproduction':reproduction,'w_original_power_by_mask':{m:original[m]['w_point'] for m in original},'w_overall':overall['w_point'],'w_single_off':single_off['w_point'],'w_band_single_off':single_off['w_band'],'shapley_w':shapley['w_point']}
(B/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary,indent=2),flush=True)

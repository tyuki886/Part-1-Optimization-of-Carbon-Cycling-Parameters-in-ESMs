from pathlib import Path
import json,subprocess,concurrent.futures,time,hashlib
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent
r=json.loads((B/'feedback_results.json').read_text());source=(B/'RKmethod_reference.f90').read_text()
assert source.count('slm*(1.0+c24*s(8))')==1
def run(item):
    kind,seed=item;start=time.time()
    full=np.memmap(B/'data'/f'M7_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))
    reference=float(full[1:,5].mean());value=format(reference,'.17g')+'_dp'
    replacement=value if kind=='mean' else '(s(8)-'+value+')'
    s=source.replace('slm*(1.0+c24*s(8))','slm*(1.0+c24*'+replacement+')')
    d=B/'data'/f'{kind}_seed{seed}';d.mkdir()
    (d/'RKmethod.f90').write_text(s)
    subprocess.run(['gfortran','-O3','-ffree-line-length-none','RKmethod.f90',str(B/'experiment.f90'),'-o','experiment'],cwd=d,check=True)
    with (d/'run.log').open('w') as f:subprocess.run([str(d/'experiment'),str(seed),'10'],cwd=d,check=True,stdout=f,stderr=subprocess.STDOUT)
    a=np.memmap(d/'states.bin',dtype='<f8',mode='r',shape=(200001,7));assert np.isfinite(a).all()
    row={'kind':kind,'seed':seed,'fixed_reference_Catm':reference,'reference_source':f'M7_seed{seed}, all postspinup 1-TU samples in (0,200000] TU','c16_c17':'remain dynamic','c28':1,'source_sha256':hashlib.sha256((d/'RKmethod.f90').read_bytes()).hexdigest(),'states_sha256':hashlib.sha256((d/'states.bin').read_bytes()).hexdigest(),'seconds':time.time()-start}
    (d/'receipt.json').write_text(json.dumps(row,indent=2));print('SPLIT_DONE',kind,seed,round(row['seconds'],1),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:receipts=list(pool.map(run,[(k,s) for s in range(10) for k in ['mean','anomaly']]))
cfg=dict(fs=1.,window='hann',nperseg=2500,noverlap=1250,detrend='constant',scaling='spectrum')
values={}
for kind in ['mean','anomaly']:
    for s in range(10):
        a=np.memmap(B/'data'/f'{kind}_seed{s}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7));rr=[]
        for j in range(20):
            aa=a[j*10000+1:(j+1)*10000+1];row={}
            for variable,col in [('w',2),('eta',3)]:
                f,p=signal.welch(aa[:,col]-aa[:,col].mean(),**cfg);k=np.argmin(abs(f-.0056));band=(f*100>=.5)&(f*100<=1.5)
                row[variable+'_point']=float(p[k]);row[variable+'_band']=float(p[band].sum()/1.5)
            rr.append(row)
        values[f'{kind}_{s}']={k:float(np.mean([v[k] for v in rr])) for k in rr[0]}
rng=np.random.default_rng(20261029);boot=rng.integers(0,10,size=(19999,10))
def stats(a):
    a=np.array(a);return {'mean':float(a.mean()),'ci95':np.percentile(a[boot].mean(1),[2.5,97.5]).tolist(),'by_initial_condition':a.tolist()}
out={}
for metric in ['w_point','w_band','eta_point','eta_band']:
    out[metric]={}
    for kind in ['full','mean','anomaly']:
        rows=[r['seed_means'][f'7_{s}'][metric] if kind=='full' else values[f'{kind}_{s}'][metric] for s in range(10)]
        baseline=[r['seed_means'][f'3_{s}'][metric] for s in range(10)]
        out[metric][kind]=stats([100*(a/b-1) for a,b in zip(rows,baseline)])
result={'reference_arm':'M3: c16 and c17 dynamic, c24 off','interventions':'Applied throughout separate spinup and integration; only replace Catm within the c24 term of the TL equation. Carbon equations and c16/c17 remain active.','fixed_reference_warning':'Anomaly intervention subtracts a fixed reference mean; its own time mean need not be exactly zero. These nonlinear interventions are not additive.','summary':out,'seed_means':values,'receipts':receipts,'bootstrap':'19999 pointwise paired resamples of 10 initial-condition units; each unit first averages 20 windows.'}
(B/'mean_split_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(out,indent=2),flush=True)

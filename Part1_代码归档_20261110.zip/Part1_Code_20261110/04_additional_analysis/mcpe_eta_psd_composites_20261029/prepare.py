from pathlib import Path
import shutil,json,hashlib
B=Path(__file__).resolve().parent
P=Path(r'D:\ClaudeFiles\mcpe_eta_only_test_20261029')
shutil.copy2(P/'times.ttf',B/'times.ttf')
cfg={'variable':'eta only','c28':1,'sampling_TU':1,'spinup_TU':10000,'postspinup_TU':200000,
 'initial_conditions':10,'nonoverlapping_windows_per_initial_condition':20,'window_length_TU':10000,
 'welch':{'fs':1,'window':'hann','nperseg':2500,'noverlap':1250,'detrend':'constant','scaling':'density'},
 'display_band_decade_inverse':[.5,1.5],'low_band_decade_inverse':[.5,.75],
 'low_frequency_zoom_decade_inverse':[.5,.8],
 'new_model_integrations':False,'equations_and_fluxes_unchanged':True,
 'baseline':'Current-platform all-carbon-feedback-off M0, verified equivalent to seven-variable core; full=M7. No legacy seven-variable archive in new panels.',
 'panels':{
  'phenomenon_a':'Paired relative eta PSD change in low-frequency zoom; not a repeated absolute PSD overlay.',
  'phenomenon_b':'Paired relative change of full-power-normalized eta PSD.',
  'phenomenon_c':'Cumulative eta PSD excess from 0.5 to f, normalized by seven-variable 0.5–1.5 band power.',
  'phenomenon_d':'Displayed-band eta PSD maximum-frequency distribution; each IC contributes twenty windows. Not a significant intrinsic-period test.',
  'mechanism_a':'Relative PSD change of the existing driving term of the eta equation.',
  'mechanism_b':'Relative squared-gain changes, empirical and local linearization, resolved by frequency.',
  'mechanism_c':'Relative eta PSD reconstruction error using original response; empirical reconstruction retains original incoherent residual, linearized prediction uses original mean-state response.'},
 'uncertainty':'Exploratory pointwise paired bootstrap across ten IC units, 19999 resamples; windows are averaged within each IC before resampling; no multiple-comparison correction.',
 'normalization':'Complete one-sided Welch power includes 0–50 decade^-1. Fractions use this full denominator, not displayed-band power.',
 'style':{'font':'Times New Roman','math_font':'STIX','dpi':600,'image_format':'PNG only','figure_footnotes':False},
 'reuse_policy':'Generate new spectral-detail panels; do not paste/crop previous panel images or include previous time series, score bars, original multivariable PSD, or single-window archive.',
 'mechanism_scope':'Response diagnostics of unchanged trajectories, not independent causal transfer functions or physical-energy contribution fractions.',
 'manuscripts_modified':False}
(B/'configuration.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
(B/'source_manifest.json').write_text(json.dumps({'font_sha256':hashlib.sha256((B/'times.ttf').read_bytes()).hexdigest(),
 'previous_spectral_results':str(P/'eta_test_results.json'),'previous_spectral_sha256':hashlib.sha256((P/'eta_test_results.json').read_bytes()).hexdigest(),
 'previous_response_results':r'D:\ClaudeFiles\mcpe_eta_response_20261029\eta_response_diagnostic.json'},ensure_ascii=False,indent=2),encoding='utf-8')
print('两图的新增面板与谱细分口径已固定。')

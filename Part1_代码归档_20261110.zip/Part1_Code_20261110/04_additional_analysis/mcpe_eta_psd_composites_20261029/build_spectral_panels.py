from pathlib import Path
import json,hashlib
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent;P=B.parent/'w_feedback_20261029'
cfg=json.loads((B/'configuration.json').read_text());welch=cfg['welch']
rng=np.random.default_rng(20261029);boot=rng.integers(0,10,size=(19999,10))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def interval(a):
 a=np.asarray(a,float);assert a.shape[0]==10 and np.isfinite(a).all()
 samples=a[boot].mean(axis=1)
 return {'mean':a.mean(axis=0).tolist(),'ci95':np.percentile(samples,[2.5,97.5],axis=0).tolist(),'by_initial_condition':a.tolist()}
f=None;all_seeds=[];sources=[]
for seed in range(10):
 raw={}
 for label,mask in [('seven',0),('full',7)]:
  p=P/'data'/f'M{mask}_seed{seed}'/'states.bin'
  receipt=json.loads((p.parent/'receipt.json').read_text())
  assert receipt['c28']==1 and p.stat().st_size==200001*7*8
  actual_sha=sha(p);assert actual_sha==receipt['states_sha256']
  sources.append({'model':label,'seed':seed,'path':str(p),'sha256':actual_sha})
  raw[label]=np.memmap(p,dtype='<f8',mode='r',shape=(200001,7))
 windows=[]
 for j in range(20):
  spectra={}
  for label in ['seven','full']:
   s=raw[label][j*10000+1:(j+1)*10000+1]
   drive=s[:,2];eta=s[:,3]
   f,psd=signal.welch(eta,**welch);_,d=signal.welch(drive,**welch);_,cross=signal.csd(drive,eta,**welch)
   gain=np.abs(cross)**2/(d*d);coherent=gain*d;remain=psd-coherent
   assert remain.min()>-1e-10
   aa=1-.001*drive.mean();bb=1+.001*eta.mean()
   linear_gain=bb*bb/(aa*aa+(2*np.pi*100*f)**2)
   fd=f*100;sel=(fd>=.5-1e-10)&(fd<=1.5+1e-10)
   peak=np.flatnonzero(sel)[np.argmax(psd[sel])]
   spectra[label]={'psd':psd,'drive':d,'gain':gain,'linear_gain':linear_gain,
    'remaining':remain,'peak':int(peak),'total':float(psd.sum()*(f[1]-f[0]))}
  a=spectra['seven'];b=spectra['full']
  prediction=a['gain']*b['drive']+a['remaining']
  linprediction=a['linear_gain']*b['drive']
  windows.append({'seven':a,'full':b,'gain_change':100*(b['gain']/a['gain']-1),
   'linear_gain_change':100*(b['linear_gain']/a['linear_gain']-1),
   'prediction':prediction,'linear_prediction':linprediction})
 df=f[1]-f[0];fd=f*100;sel=(fd>=.5-1e-10)&(fd<=1.5+1e-10);idx=np.flatnonzero(sel)
 avg={}
 for label in ['seven','full']:
  p=np.mean([w[label]['psd'] for w in windows],axis=0)
  d=np.mean([w[label]['drive'] for w in windows],axis=0)
  hist=np.array([sum(w[label]['peak']==k for w in windows) for k in idx],float)/20*100
  assert abs(hist.sum()-100)<1e-10
  avg[label]={'psd':p,'drive':d,'total':p.sum()*df,'histogram_percent':hist}
 a=avg['seven'];b=avg['full']
 relative=100*(b['psd'][sel]/a['psd'][sel]-1)
 normalized=100*((b['psd'][sel]/b['total'])/(a['psd'][sel]/a['total'])-1)
 cum=100*np.cumsum((b['psd'][sel]-a['psd'][sel])*df)/(a['psd'][sel].sum()*df)
 prediction=np.mean([w['prediction'] for w in windows],axis=0)
 linprediction=np.mean([w['linear_prediction'] for w in windows],axis=0)
 item={'initial_condition':seed,'psd_change_percent':relative,
  'normalized_psd_change_percent':normalized,'cumulative_excess_percent':cum,
  'seven_peak_probability_percent':a['histogram_percent'],'full_peak_probability_percent':b['histogram_percent'],
  'drive_psd_change_percent':100*(b['drive'][sel]/a['drive'][sel]-1),
  'empirical_gain_change_percent':np.mean([w['gain_change'][sel] for w in windows],axis=0),
  'linear_gain_change_percent':np.mean([w['linear_gain_change'][sel] for w in windows],axis=0),
  'fixed_response_reconstruction_error_percent':100*(prediction[sel]/b['psd'][sel]-1),
  'linearized_reconstruction_error_percent':100*(linprediction[sel]/b['psd'][sel]-1),
  'eta_psd_seven_density_decade':a['psd'][sel]/100,
  'eta_psd_full_density_decade':b['psd'][sel]/100,
  'total_spectral_power_seven':a['total'],'total_spectral_power_full':b['total']}
 all_seeds.append(item)
 assert np.isclose(cum[-1],100*(b['psd'][sel].sum()/a['psd'][sel].sum()-1),atol=1e-10)
fields=[k for k in all_seeds[0] if k not in ['initial_condition','total_spectral_power_seven','total_spectral_power_full']]
curves={k:interval(np.array([s[k] for s in all_seeds])) for k in fields}
# Match the previously verified displayed-band integrated change exactly.
old=json.loads((B.parent/'eta_only_test_20261029'/'summary.json').read_text())
assert np.isclose(curves['cumulative_excess_percent']['mean'][-1],old['comparison']['display_power']['mean'],rtol=1e-12)
output={'configuration':cfg,'frequency_decade_inverse':fd[sel].tolist(),'curves':curves,'sources':sources,
 'complete_spectrum_totals':[{'initial_condition':s['initial_condition'],
  'seven':s['total_spectral_power_seven'],'full':s['total_spectral_power_full']} for s in all_seeds],
 'checks':{'hashes_match_existing_production':True,'cumulative_endpoint_matches_previous_display_band_change':True,
  'histogram_probabilities_sum_to_100':True,'all_intervals_resample_10_initial_conditions':True},
 'reconstruction':'Empirical: |H7|^2 D10 + (S_eta7 - |H7|^2 D7). Linearized: G7_linear D10. Each window is reconstructed before averaging; the denominator is actual full-model eta PSD.',
 'warning':'Empirical spectral reconstruction is not an independently intervened causal transfer function. No model equations or exchange/sediment pairs are altered.'}
(B/'spectral_panel_data.json').write_text(json.dumps(output,indent=2))
print('SPECTRAL_PANELS_READY',float(curves['cumulative_excess_percent']['mean'][-1]),flush=True)

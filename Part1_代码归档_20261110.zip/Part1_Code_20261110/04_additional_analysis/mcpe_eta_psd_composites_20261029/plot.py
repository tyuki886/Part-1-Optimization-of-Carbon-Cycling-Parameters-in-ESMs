from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
B=Path(__file__).resolve().parent
r=json.loads((B/'spectral_panel_data.json').read_text());f=np.array(r['frequency_decade_inverse'])
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9.5,
 'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
 'axes.linewidth':.75,'path.simplify':False})
blue='#24578D';red='#C6324B';gray='#777777';gold='#B77A22'
manifest={'font':'Times New Roman; STIX math','dpi':600,'format':'PNG','files':[],
 'data_sha256':hashlib.sha256((B/'spectral_panel_data.json').read_bytes()).hexdigest(),
 'all_panels_new_spectral_details':True,'old_panel_images_reused':False,
 'old_figures_preserved':True,'manuscripts_modified':False,
 'uncertainty':r['configuration']['uncertainty'],'mechanism_scope':r['configuration']['mechanism_scope']}
def get(key):
 z=r['curves'][key];return np.array(z['mean']),np.array(z['ci95'])
def base(ax,low_shading=True):
 ax.set_xlim(.5,1.5);ax.set_xlabel('Frequency (Decade$^{-1}$)')
 ax.grid(color='#eeeeee',lw=.55);ax.set_axisbelow(True)
 if low_shading:ax.axvspan(.5,.75,color=gold,alpha=.07,lw=0,zorder=0)
def delta(ax,key,color=red,ls='-',label=None,select=None,markers=False):
 v,ci=get(key)
 if select is None:select=np.ones(len(f),dtype=bool)
 ax.fill_between(f[select],ci[0,select],ci[1,select],color=color,alpha=.15 if color==red else .10,lw=0)
 ax.plot(f[select],v[select],c=color,ls=ls,lw=1.2,marker='o' if markers else None,ms=3,label=label)
 ax.axhline(0,c='#333333',lw=.75,zorder=1)
def save(fig,name,description):
 for suffix,dpi in [('',600),('_preview',160)]:fig.savefig(B/(name+suffix+'.png'),dpi=dpi,bbox_inches='tight',pad_inches=.07)
 manifest['files'].append({'file':name+'.png','sha256':hashlib.sha256((B/(name+'.png')).read_bytes()).hexdigest(),'panels':description})
 plt.close(fig)

fig,axs=plt.subplots(2,2,figsize=(8.8,6.5));axs=axs.ravel()
for ax in axs:base(ax)
delta(axs[0],'psd_change_percent',select=f<=.8+1e-10,markers=True)
axs[0].set_xlim(.5,.8);axs[0].set_xticks([.5,.6,.7,.8])
axs[0].set_ylabel('PSD change (%)');axs[0].set_title('(a) Low-band PSD contrast',pad=6)
delta(axs[1],'normalized_psd_change_percent')
axs[1].set_ylabel('Normalized PSD change (%)');axs[1].set_title('(b) Spectral concentration',pad=6)
v,ci=get('cumulative_excess_percent');ff=np.r_[.5,f]
axs[2].fill_between(ff,np.r_[0.,ci[0]],np.r_[0.,ci[1]],color=red,alpha=.15,lw=0)
axs[2].plot(ff,np.r_[0.,v],c=red,lw=1.2)
axs[2].axhline(0,c='#333333',lw=.75);axs[2].axvline(.75,c=gray,ls=':',lw=.8)
axs[2].set_ylabel('Cumulative power excess (%)');axs[2].set_title('(c) Accumulated spectral difference',pad=6)
edges=np.r_[f[0]-.02,(f[:-1]+f[1:])/2,f[-1]+.02]
for key,c,ls,label in [('seven_peak_probability_percent',blue,'--','Seven-variable'),('full_peak_probability_percent',red,'-','10VCC')]:
 v,ci=get(key)
 axs[3].stairs(v,edges,color=c,linestyle=ls,linewidth=1.25,label=label)
 axs[3].fill_between(f,ci[0],ci[1],step='mid',color=c,alpha=.10,lw=0)
axs[3].set_ylim(bottom=0);lo,hi=axs[3].get_ylim();axs[3].set_ylim(0,hi*1.12)
axs[3].set_ylabel('Windows (%)');axs[3].set_title('(d) PSD-maximum frequency distribution',pad=6)
axs[3].legend(frameon=False,loc='upper right')
fig.suptitle(r'$\eta$: low-frequency spectral characteristics',fontsize=12.5,y=.98)
fig.subplots_adjust(left=.105,right=.985,bottom=.09,top=.88,hspace=.44,wspace=.35)
save(fig,'Eta_phenomenon_analysis',{
 'a':'Paired relative eta PSD change in the 0.5–0.8 decade^-1 zoom: 100*(PSD10/PSD7−1). Each initial condition first averages twenty windows. Shading marks 0.5–0.75 decade^-1.',
 'b':'Relative eta PSD change after each complete spectrum is normalized by all-frequency one-sided Welch power. Complete normalization uses 0–50 decade^-1, not the displayed band. Values are relative percentages, not fraction percentage points.',
 'c':'Cumulative PSD10−PSD7 from 0.5 to each frequency, divided by the same initial-condition seven-variable 0.5–1.5 decade^-1 power. The zero origin is a definition; the final point reproduces the previously verified displayed-band power contrast. This is a spectral-power diagnostic, not a physical energy transfer.',
 'd':'Distribution of displayed-band eta PSD maxima. Each initial condition contributes twenty windows; initial-condition distributions are averaged. Shaded intervals resample ten initial-condition units, not 200 independent windows. This is not an intrinsic-period significance test.'})

fig=plt.figure(figsize=(8.8,6.35));gs=fig.add_gridspec(2,2,height_ratios=[1,1])
ax1=fig.add_subplot(gs[0,0]);ax2=fig.add_subplot(gs[0,1]);ax3=fig.add_subplot(gs[1,:])
for ax in [ax1,ax2,ax3]:base(ax)
delta(ax1,'drive_psd_change_percent')
ax1.set_ylabel('Driving-term PSD change (%)');ax1.set_title(r'(a) Driving spectrum of $\eta$',pad=6)
delta(ax2,'empirical_gain_change_percent',label='Empirical response')
delta(ax2,'linear_gain_change_percent',color=gray,ls='--',label='Linearized response')
ax2.set_ylabel('Squared-gain change (%)');ax2.set_title('(b) Frequency-dependent response',pad=6)
ax2.legend(frameon=False,loc='upper right',fontsize=7.5)
lo,hi=ax2.get_ylim();ax2.set_ylim(lo-(hi-lo)*.05,hi+(hi-lo)*.22)
delta(ax3,'fixed_response_reconstruction_error_percent',label='Original empirical response')
delta(ax3,'linearized_reconstruction_error_percent',color=gray,ls='--',label='Original linearized response')
ax3.set_ylabel('Reconstruction error (%)');ax3.set_title(r'(c) Reconstructed $\eta$ PSD versus actual 10VCC PSD',pad=6)
ax3.legend(frameon=False,loc='best',fontsize=8,ncol=2)
lo,hi=ax3.get_ylim();ax3.set_ylim(lo-(hi-lo)*.05,hi+(hi-lo)*.20)
fig.suptitle(r'$\eta$: driving and response spectra',fontsize=12.5,y=.98)
fig.subplots_adjust(left=.105,right=.985,bottom=.09,top=.88,hspace=.49,wspace=.35)
save(fig,'Eta_mechanism_explanation',{
 'a':'Paired relative PSD change of the driving term in the unchanged eta equation. With c5=1, its spectrum is that of the existing input state. No separate state-variable spectrum is displayed.',
 'b':'Paired relative squared-gain changes by frequency. Empirical H=S_drive,eta/S_drive; local mean-state linearization gives G=b^2/[a^2+(2*pi*Gamma*f_TU)^2]. Ratios are formed within paired windows, averaged within each initial condition, then averaged across conditions. Empirical gain is not an independently intervened causal transfer function.',
 'c':'Reconstruction error 100*(reconstructed PSD/actual eta PSD10−1). Red: keep original empirical response and original incoherent residual, insert new driving PSD. Gray: keep original linearized response, insert new driving PSD. Each window is reconstructed before averaging. Zero is exact PSD agreement; this is response consistency, not a physical contribution allocation.'})
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
print('TWO_ETA_COMPOSITES_COMPLETE',flush=True)

from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_psd_composites_20261029'
c=hpc.connect()
try:
 mode=sys.argv[1]
 if mode=='submit':
  with c.open_sftp() as s:
   try:s.stat(R);raise RuntimeError('新组合图目录已存在，拒绝覆盖')
   except FileNotFoundError:s.mkdir(R)
   for name in ['configuration.json','source_manifest.json','times.ttf','build_spectral_panels.py','plot.py']:
    s.put(str(B/name),R+'/'+name)
  wrap='export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python build_spectral_panels.py && /home/b/b382207/conda/envs/yuki/bin/python plot.py'
  cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=8G --time=00:10:00 --job-name=eta_psd_composites --output=plot-%j.log --wrap='+shlex.quote(wrap)
  rc,out,err=hpc.run(c,cmd)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
 elif mode=='status':
  marker=B/'replot_submission.json' if (B/'replot_submission.json').exists() else B/'submission.json'
  job=json.loads(marker.read_text())['job'];prefix='replot' if marker.name.startswith('replot') else 'plot'
  rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -8 '+shlex.quote(R+'/'+prefix+'-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/figure_manifest.json')+' && echo FIGURES_COMPLETE')
  print(out)
 elif mode=='fetch':
  with c.open_sftp() as s:
   for name in ['spectral_panel_data.json','figure_manifest.json','Eta_phenomenon_analysis.png','Eta_phenomenon_analysis_preview.png','Eta_mechanism_explanation.png','Eta_mechanism_explanation_preview.png']:
    s.get(R+'/'+name,str(B/name))
  print('两张η组合图已下载。')
 elif mode=='replot':
  with c.open_sftp() as s:s.put(str(B/'plot.py'),R+'/plot.py')
  cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=4G --time=00:05:00 --job-name=eta_psd_replot --output=replot-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python plot.py')
  rc,out,err=hpc.run(c,cmd)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'replot_submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
 else:raise RuntimeError('未知操作')
finally:c.close()

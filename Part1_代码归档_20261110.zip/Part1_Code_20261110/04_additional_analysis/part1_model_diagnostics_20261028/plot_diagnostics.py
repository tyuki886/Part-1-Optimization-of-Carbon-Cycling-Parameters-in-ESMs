"""Source-backed Part 1 diagnostic figures; formal runtime is remote yuki."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from PIL import Image

B=Path(__file__).resolve().parent
O=B/'figures';O.mkdir(exist_ok=True)
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9,
 'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,
 'axes.linewidth':.7,'lines.linewidth':1.05,'savefig.facecolor':'white',
 'path.simplify':False,'agg.path.chunksize':10000})
assert Path(font_manager.findfont('Times New Roman')).resolve()==(B/'times.ttf').resolve()
colors={'reference':'#222222','high':'#B52D43','low':'#24578D','mean':'#CC8131','anomaly':'#3E8074'}
manifest=[]

def finish(fig,name):
    p=O/name
    fig.savefig(p,dpi=600,bbox_inches='tight',pad_inches=.055)
    plt.close(fig)
    with Image.open(p) as im:
        size=im.size;im.thumbnail((1600,1350));im.save(O/(p.stem+'_preview.png'))
    manifest.append({'file':name,'pixels':size,'dpi':600,'font':'Times New Roman',
        'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})

def style(ax,axis='both'):
    ax.set_axisbelow(True);ax.grid(axis=axis,color='#DDDDDD',alpha=.65,lw=.4,ls=':')

# The completed c28=1 feedback experiments are re-used with their original scope.
r=json.loads((B/'diagnostic_results.json').read_text())
z=json.loads((B/'mean_split_results.json').read_text())
assert r['equivalence']['water_equal']
assert all(x['c28']==1 for x in json.loads((B/'completion.json').read_text()))
assert float((B/'identity.txt').read_text())==0

fig,ax=plt.subplots(2,2,figsize=(8.2,6.2))
fig.subplots_adjust(left=.12,right=.985,bottom=.09,top=.865,wspace=.35,hspace=.42)
labels=['None',r'$c_{16}$',r'$c_{17}$',r'$c_{16}+c_{17}$',r'$c_{24}$',
        r'$c_{16}+c_{24}$',r'$c_{17}+c_{24}$','All three']
for a,key,title in [(ax[0,0],'TL_band',r'(a) $T_L$: 0–0.5 year$^{-1}$'),
                    (ax[0,1],'eta_band',r'(b) $\eta$: 0–0.2 decade$^{-1}$')]:
    ref=r['block_means']['M0'][key]
    values=[100*(r['block_means']['M'+str(k)][key]/ref-1) for k in range(8)]
    for k,value in enumerate(values):
        cc=colors['low'] if k<4 else colors['high']
        a.barh(k,value,color=cc,height=.58,alpha=.85,zorder=2)
        blockvals=[100*(q[key]-rr[key])/ref for q,rr in zip(r['blocks']['M'+str(k)],r['blocks']['M0'])]
        a.scatter(blockvals,k+np.linspace(-.18,.18,20),color='#777777',alpha=.4,s=5,zorder=3,linewidths=0)
    a.axvline(0,color='#333333',lw=.6);a.set_yticks(range(8));a.set_yticklabels(labels)
    a.invert_yaxis();a.set_title(title,pad=5);a.set_xlabel('Difference / mean reference power (%)');style(a,'x')
    a.margins(x=.12)
groups=[r['blocks']['M3'],r['blocks']['M7'],z['mean_c24']['blocks'],z['anomaly_c24']['blocks']]
means=[r['block_means']['M3']['TL_band'],r['block_means']['M7']['TL_band'],
       z['mean_c24']['means']['TL_band'],z['anomaly_c24']['means']['TL_band']]
ref=means[0]
for i,(gg,mm,cc) in enumerate(zip(groups,means,['#888888',colors['high'],colors['mean'],colors['anomaly']])):
    ax[1,0].bar(i,100*(mm/ref-1),color=cc,width=.6,alpha=.85,zorder=2)
    dv=[100*(q['TL_band']-rr['TL_band'])/ref for q,rr in zip(gg,groups[0])]
    ax[1,0].scatter(i+np.linspace(-.16,.16,20),dv,color='#777777',alpha=.4,s=6,zorder=3,linewidths=0)
ax[1,0].axhline(0,color='#333333',lw=.6)
ax[1,0].set_xticks(range(4));ax[1,0].set_xticklabels(['No $c_{24}$','Full\n$c_{24}$','Mean\nonly','Anomaly\nonly'])
ax[1,0].set_ylabel('Difference / mean reference power (%)');ax[1,0].set_title(r'(c) $T_L$: mean and variable carbon forcing',pad=5);style(ax[1,0],'y')
for key,col,label in [('eta_first_bin',colors['low'],'First nonzero bin'),('eta_band',colors['high'],'Integrated band')]:
    vals=[a[key]/b[key] for a,b in zip(r['blocks']['M7'],r['blocks']['seven'])]
    ax[1,1].plot(range(1,21),vals,'o-',color=col,label=label,ms=2.6,lw=.85)
ax[1,1].axhline(1,color='#333333',ls='--',lw=.7)
ax[1,1].set(xlim=(.5,20.5),xticks=[1,5,10,15,20],xlabel='Consecutive 10000-TU window',
    ylabel='10VCC / seven-variable power')
ax[1,1].set_title(r'(d) $\eta$: variation among windows',pad=5)
ax[1,1].legend(fontsize=7.3,frameon=False,loc='upper right');style(ax[1,1])
fig.suptitle('Carbon-feedback pathways and spectral variability',fontsize=12.5,y=.985)
fig.legend(handles=[Patch(color=colors['low'],label='Without $c_{24}$ (a, b)'),Patch(color=colors['high'],label='With $c_{24}$ (a, b)'),
    Line2D([],[],color='#777777',marker='o',ls='',ms=3,label='Individual windows')],
    loc='upper center',bbox_to_anchor=(.5,.953),ncol=3,frameon=False,fontsize=8)
finish(fig,'P1_feedback_pathways.png')

# New matched branches, integrated with original model arithmetic.
summary=np.loadtxt(B/'summary.txt');assert summary.shape==(25,21) and np.isfinite(summary).all()
data={};blocks={}
for seed in range(5):
    for arm in range(5):
        d=np.fromfile(B/f'data/seed{seed}_arm{arm}.bin',dtype='<f8').reshape(-1,22)
        a=np.fromfile(B/f'data/seed{seed}_arm{arm}_blocks.bin',dtype='<f8').reshape(-1,22)
        assert d.shape==(20001,22) and a.shape==(200,22)
        assert np.isfinite(d).all() and np.isfinite(a).all()
        np.testing.assert_allclose(d[:,0],np.arange(20001),atol=1e-10)
        assert np.max(np.abs(d[:,18:20]))<1e-7
        data[seed,arm]=d;blocks[seed,arm]=a
    for arm in range(1,5):np.testing.assert_array_equal(data[seed,arm][0,1:11],data[seed,0][0,1:11])
arm_means={arm:summary[summary[:,1]==arm,12:19] for arm in range(5)}
styles=[(0,'Reference',colors['reference']),(1,'High emissions',colors['high']),(2,'Low emissions',colors['low'])]
fig,ax=plt.subplots(2,2,figsize=(8.2,6.45))
fig.subplots_adjust(left=.09,right=.96,bottom=.09,top=.865,wspace=.35,hspace=.46)
for arm,label,col in styles:
    f=arm_means[arm].mean(0)
    offset=(arm-1)*.22
    atm=[f[0],-f[1],-f[2],-f[3],f[0]-f[1]-f[2]-f[3]]
    ocn=[f[1],-f[4],-f[5],f[1]-f[4]-f[5]]
    ax[0,0].bar(np.arange(5)+offset,atm,width=.22,color=col,alpha=.9,label=label)
    ax[0,1].bar(np.arange(4)+offset,ocn,width=.22,color=col,alpha=.9)
    ratio=2*arm_means[arm][:,5]/.0018
    ax[1,0].bar(arm,ratio.mean(),width=.6,color=col,alpha=.85)
    ax[1,0].scatter(arm+np.linspace(-.12,.12,5),ratio,s=12,facecolors='white',edgecolors=col,linewidths=.7,zorder=5)
for a in ax[0]:a.axhline(0,color='#333333',lw=.65);a.set_ylabel(r'Budget contribution (TU$^{-1}$)');style(a,'y')
ax[0,0].set_xticks(range(5));ax[0,0].set_xticklabels([r'$E$',r'$-F_{\rm as}$',r'$-F_L$',r'$-F_{\rm conv}$','Net'])
ax[0,1].set_xticks(range(4));ax[0,1].set_xticklabels([r'$F_{\rm as}$',r'$-F_{\rm exp}$',r'$-B_{\rm cal}$','Net'])
ax[0,0].set_title(r'(a) Atmospheric-carbon budget',pad=5)
ax[0,1].set_title(r'(b) Ocean-carbon budget',pad=5)
ax[1,0].axhline(1,color='#777777',ls='--',lw=.8)
ax[1,0].set_xticks(range(3));ax[1,0].set_xticklabels(['Reference','High','Low'])
ax[1,0].set(ylim=(0,1.17),ylabel=r'$2\overline{B}_{\rm cal}/c_{25}$')
ax[1,0].set_title('(c) Alkalinity input and removal',pad=5);style(ax[1,0],'y')

paths=[data[0,a][:5001] for a in range(3)]
allc=np.concatenate([d[:,9] for d in paths]);alla=np.concatenate([d[:,10] for d in paths])
clo=max(.1,allc.min()-.8);chi=allc.max()+.8;alo=alla.min()-.65;ahi=alla.max()+.65
cc=np.linspace(clo,chi,220);aa=np.linspace(alo,ahi,220);C,A=np.meshgrid(cc,aa)
rem=9e-5*C*np.maximum(A-.5*C+1,0)
im=ax[1,1].pcolormesh(C,A,2*rem/.0018,cmap='YlOrBr',vmin=0,vmax=3,shading='auto',rasterized=True)
ax[1,1].plot(cc,.5*cc-1,color='#777777',ls=':',lw=1,label=r'$Q=0$')
ax[1,1].plot(cc,.5*cc-1+10/cc,color='#222222',ls='--',lw=1,label=r'$d\mathrm{ALK}/dt=0$')
for (arm,label,col),d in zip(styles,paths):
    ax[1,1].plot(d[:,9],d[:,10],color=col,lw=.95)
    ax[1,1].plot(d[-1,9],d[-1,10],'o',color=col,ms=3)
ax[1,1].set(xlim=(clo,chi),ylim=(alo,ahi),xlabel=r'$C_{\rm ocn}$',ylabel='ALK')
ax[1,1].set_title('(d) Carbonate-removal phase plane',pad=5)
ax[1,1].legend(loc='lower right',fontsize=7.2,frameon=False)
cb=fig.colorbar(im,ax=ax[1,1],pad=.025,fraction=.045,extend='max');cb.set_label(r'$2B_{\rm cal}/c_{25}$',fontsize=8);cb.ax.tick_params(labelsize=7)
fig.suptitle('Carbon and alkalinity budgets in the 10VCC model',fontsize=12.5,y=.985)
fig.legend(*ax[0,0].get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.5,.95),ncol=3,frameon=False,fontsize=8)
finish(fig,'P1_carbon_alkalinity_budgets.png')

fig,axes=plt.subplots(2,2,figsize=(8.2,5.5),sharex=True)
fig.subplots_adjust(left=.085,right=.985,bottom=.105,top=.86,wspace=.28,hspace=.34)
variables=[(8,r'$C_{\rm atm}$'),(9,r'$C_{\rm ocn}$'),(10,'ALK'),(7,r'$T_L$')]
pulse_metrics={}
for i,(a,(col,var)) in enumerate(zip(axes.flat,variables)):
    for arm,label,color in [(3,'Positive pulse',colors['high']),(4,'Negative pulse',colors['low'])]:
        delta=np.array([blocks[s,arm][:,col]-blocks[s,0][:,col] for s in range(5)])
        mean=delta.mean(0);sd=delta.std(0,ddof=1);t=blocks[0,0][:,0]
        a.fill_between(t,mean-sd,mean+sd,color=color,alpha=.15,linewidth=0)
        a.plot(np.r_[0,t],np.r_[0,mean],color=color,label=label,lw=1.1)
        pulse_metrics[f'{var}_arm{arm}']={'max_abs_block_mean':float(np.max(np.abs(mean))),
             'terminal_10000TU_anomaly_mean':float(mean[t>=10000].mean()),
             'last_block_mean':float(mean[-1])}
    a.axhline(0,color='#555555',lw=.65);a.axvspan(0,1000,color='#AAAAAA',alpha=.15,zorder=0)
    a.set_title(f'({chr(97+i)}) '+var,pad=5);a.set_ylabel('Anomaly relative to reference')
    a.set_xlim(0,10000);a.set_xticks([0,2000,4000,6000,8000,10000]);style(a)
    a.ticklabel_format(axis='y',style='sci',scilimits=(-2,3))
for a in axes[1]:a.set_xlabel('Time since pulse onset (TU)')
fig.suptitle('Pulse recovery (5 initial conditions; 100-TU means)',fontsize=12.5,y=.99)
fig.legend(handles=[Line2D([],[],color=colors['high'],label='Positive pulse'),
    Line2D([],[],color=colors['low'],label='Negative pulse'),
    Patch(color=colors['high'],alpha=.15,label=r'$\pm$1 SD'),
    Patch(color='#777777',alpha=.15,label='Pulse active')],
    loc='upper center',bbox_to_anchor=(.5,.948),ncol=4,frameon=False,fontsize=8)
finish(fig,'P1_pulse_and_recovery.png')

results={'configuration':json.loads((B/'configuration.json').read_text()),
 'identity_max_abs':float((B/'identity.txt').read_text()),'budget_max_abs':summary[:,19:21].max(0).tolist(),
 'budget_terms':['E','F_as','F_land','F_convection','F_export','Bcal','alkalinity_input'],
 'native_tail_flux_means':{str(a):arm_means[a].mean(0).tolist() for a in range(5)},
 'alkalinity_removal_to_input_ratio':{str(a):(2*arm_means[a][:,5]/.0018).tolist() for a in range(3)},
 'pulse_metrics':pulse_metrics,
 'pulse_uncertainty':'Shading: +/- one SD across five paired initial-condition experiments; not a confidence interval',
 'pulse_plot_window_TU':[0,10000],'budget_averaging_window_TU':[10000,20000],
 'phase_plane':'Representative seed 0, first 5000 TU; field and nullclines are instantaneous diagnostics',
 'feedback_effects':r['shapley']['twenty_window_mean'],
 'feedback_mean_split':{k:v['ratio_to_M3_no_c24'] for k,v in z.items()},
 'feedback_bar_and_dot_definition':'Bars: mean power difference divided by common reference mean. Gray dots: individual-window power differences divided by the same reference mean. The dots therefore average to the bars.',
 'caveats':['The 20 feedback windows are consecutive windows, not independent seeds.',
            'The nonlinear ALK zero-tendency curve is not a full-system equilibrium curve.',
            'This is a conceptual nondimensional model, not validation against the real carbon cycle.']}
(B/'analysis_results.json').write_text(json.dumps(results,indent=2))
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'figures':manifest,'budget_max_abs':results['budget_max_abs'],'pulse_metrics':pulse_metrics},indent=2))

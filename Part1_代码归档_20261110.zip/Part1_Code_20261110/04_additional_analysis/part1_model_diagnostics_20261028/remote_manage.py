from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
PROJECT=B.parents[1]
sys.path.insert(0,str(PROJECT))
import hpc
REMOTE='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/part1_diagnostics_20261028'
mode=sys.argv[1]
c=hpc.connect()
try:
    if mode=='submit':
        f=c.open_sftp()
        try:
            f.stat(REMOTE)
            raise RuntimeError('Independent remote directory already exists; inspect before reusing')
        except FileNotFoundError:f.mkdir(REMOTE)
        names=list(json.loads((B/'source_manifest.json').read_text()))+['source_manifest.json','compute.sh']
        for name in names:f.put(str(B/name),REMOTE+'/'+name)
        f.close()
        rc,out,err=hpc.run(c,'cd '+shlex.quote(REMOTE)+' && sbatch compute.sh')
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'submission.json').write_text(json.dumps({'job_id':job,'remote':REMOTE,'account':'ab0246'},indent=2))
        print(out)
    elif mode=='status':
        job=json.loads((B/'submission.json').read_text())['job_id']
        rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -6 '+shlex.quote(REMOTE+'/compute-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(REMOTE+'/COMPUTE_DONE')+' && echo COMPUTE_DONE')
        print(out);print(err.strip())
    elif mode=='plot':
        with c.open_sftp() as f:f.put(str(B/'plot_diagnostics.py'),REMOTE+'/plot_diagnostics.py')
        command='cd '+shlex.quote(REMOTE)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=2G --time=00:05:00 --job-name=MCPE_P1_plot --output=plot-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python plot_diagnostics.py')
        rc,out,err=hpc.run(c,command)
        if rc:raise RuntimeError(err)
        job=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'plot_submission.json').write_text(json.dumps({'job_id':job,'remote':REMOTE},indent=2))
        print(out)
    elif mode=='plot-status':
        job=json.loads((B/'plot_submission.json').read_text())['job_id']
        rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -8 '+shlex.quote(REMOTE+'/plot-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(REMOTE+'/analysis_results.json')+' && echo FIGURES_DONE')
        print(out);print(err.strip())
    elif mode=='fetch':
        dest=B/'results';dest.mkdir(exist_ok=True)
        with c.open_sftp() as f:
            for name in ['analysis_results.json','figure_manifest.json','identity.txt','summary.txt','compute_receipt.json']:
                f.get(REMOTE+'/'+name,str(dest/name))
            for name in f.listdir(REMOTE+'/figures'):
                if name.endswith('.png'):f.get(REMOTE+'/figures/'+name,str(dest/name))
        print('RESULTS_DOWNLOADED',dest)
finally:c.close()

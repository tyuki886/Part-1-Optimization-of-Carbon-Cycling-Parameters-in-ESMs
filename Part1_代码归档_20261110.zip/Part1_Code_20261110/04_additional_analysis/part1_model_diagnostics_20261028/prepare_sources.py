from pathlib import Path
import hashlib,json,shutil
B=Path(__file__).resolve().parent
OLD=B.parent/'paper_revision_20260915/c28_mechanism_diagnostic'
source=(OLD/'RKmethod_reference.f90').read_text(encoding='utf-8')
assert 'c28=1.0_dp' in source and 'c28=10.0_dp' not in source
(B/'RKmethod_reference.f90').write_text(source,encoding='utf-8')
s=source.replace('module RKmethod','module VCC_diagnostics',1)
s=s.replace('contains','real(dp) :: current_E=0.8_dp\ncontains',1)
s=s.replace('ds(8)=E_rate-','ds(8)=current_E-')
assert s.count('current_E-')==1
flux='''
    function fluxes(s) result(f)
       real(dp),intent(in)::s(18)
       real(dp)::f(7),p,b
       p=max(c29*s(9)-c30*s(10),0._dp)
       b=c26*rrain*s(9)*max(s(10)-c27*s(9)+c28,0._dp)
       f=[current_E,c18*(1._dp-c19*s(4))*(s(8)-p),c20*s(8)*s(7), &
          c21*s(1)*(s(7)-s(4)),c22*(1._dp-c23*s(4))*s(5),b,c25]
    end function
'''
s=s.replace('end module',flux+'\nend module')
(B/'VCC_diagnostics.f90').write_text(s,encoding='utf-8')
for name in ['diagnostic_results.json','mean_split_results.json','completion.json','mean_split_completion.json','identity_check.json']:
    shutil.copy2(OLD/name,B/name)
shutil.copy2(B.parent/'saturation_remeasure_20260911/times.ttf',B/'times.ttf')
config={'c28':1.0,'reference_c26_effective':9e-5,'spinup_TU':10000,'postspinup_TU':20000,
 'pulse_duration_TU':1000,'dt_TU':.01,'saved_state_interval_TU':1,'pulse_plot_block_mean_TU':100,
 'initial_condition_ensemble':5,'initial_x2':[1+.001*i for i in range(5)],
 'arms':{'0':'Reference E=0.8','1':'Sustained E=1.2','2':'Sustained E=0.4',
 '3':'E=1.2 for 1000 TU, then 0.8','4':'E=0.4 for 1000 TU, then 0.8'},
 'native_flux_quadrature':'RK4 weights at the same four model stage states',
 'budget_average_window_TU':[10000,20000],
 'feedback_source':'Completed 2026-09-15 c28=1 8-switch factorial plus mean/anomaly interventions',
 'feedback_windows':'20 consecutive 10000-TU windows, not independent initial-condition ensembles',
 'model_time_forcing':'Original archived per-step forcing retained, including frozen forcing time within RK stages'}
(B/'configuration.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
files=['RKmethod_reference.f90','VCC_diagnostics.f90','experiment.f90','configuration.json',
        'diagnostic_results.json','mean_split_results.json','completion.json','mean_split_completion.json','identity_check.json','times.ttf']
receipt={name:hashlib.sha256((B/name).read_bytes()).hexdigest() for name in files}
(B/'source_manifest.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print('SOURCE_READY',len(receipt),'files; c28=1; original model arithmetic retained')

#!/bin/bash
#SBATCH --job-name=MCPE_P1_diagnostics
#SBATCH --account=ab0246
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --time=00:10:00
#SBATCH --output=compute-%j.log
set -euo pipefail
cd /work/ab0246/wuyuhang/SRDP/output/MCPE21.0/part1_diagnostics_20261028
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MPLBACKEND=Agg
gfortran -O3 -ffree-line-length-none RKmethod_reference.f90 VCC_diagnostics.f90 experiment.f90 -o experiment
./experiment
/home/b/b382207/conda/envs/yuki/bin/python -c 'import json,hashlib,pathlib; b=pathlib.Path("."); (b/"compute_receipt.json").write_text(json.dumps({"status":"complete","c28":1,"parameters_source":hashlib.sha256((b/"RKmethod_reference.f90").read_bytes()).hexdigest(),"experiment_sha256":hashlib.sha256((b/"experiment.f90").read_bytes()).hexdigest(),"data":{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in b.glob("data/*.bin")}},indent=2))'

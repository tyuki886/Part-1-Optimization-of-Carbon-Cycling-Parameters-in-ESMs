! Diagnostic free integrations only. c28=1; no assimilation or parameter estimation.
program part1_experiment
 use VCC_diagnostics, only: dp,adv_true_state,derivs,current_E,fluxes
 use RKmethod, only: adv_reference=>adv_true_state
 implicit none
 integer,parameter::nseed=5,narm=5,nout=22
 integer(kind=8),parameter::spin=1000000_8,total=2000000_8,pulse=100000_8,block=10000_8
 real(dp),parameter::dt=.01_dp
 real(dp)::x(18),checkpoint(18),xr(18),test(18),fint(7),q(7),bm(10),bf(7)
 real(dp)::tailx(10),tailf(7),row(nout),res(2),maxres(2),startc,starta,t
 real(dp)::identity_error
 real(dp)::comp(7),ky(7),kt(7)
 integer(kind=8)::it,j,ntail
 integer::seed,arm,u,ub,us,unit,io
 character(len=80)::name
 call execute_command_line('mkdir -p data')
 ! The diagnostic integrator must reproduce the archived reference arithmetic.
 current_E=.8_dp;test=0._dp;test(2)=1._dp;xr=test;identity_error=0._dp
 do it=1,10000_8
   call adv_budget(test,it,q)
   call adv_reference(xr,it,10)
   identity_error=max(identity_error,maxval(abs(test-xr)))
 enddo
 if(identity_error/=0._dp)error stop 'diagnostic/reference integration mismatch'
 open(newunit=unit,file='identity.txt',status='new');write(unit,*)identity_error;close(unit)
 open(newunit=us,file='summary.txt',status='new')
 do seed=0,nseed-1
   current_E=.8_dp;x=0._dp;x(2)=1._dp+.001_dp*seed
   do it=1,spin
     call adv_true_state(x,it,10)
   enddo
   checkpoint=x
   do arm=0,narm-1
     x=checkpoint;current_E=.8_dp;fint=0._dp;comp=0._dp;bm=0._dp;bf=0._dp
     tailx=0._dp;tailf=0._dp;ntail=0_8;maxres=0._dp
     startc=x(8)+x(9);starta=x(10)
     write(name,'("data/seed",I1,"_arm",I1,".bin")')seed,arm
     open(newunit=u,file=trim(name),access='stream',form='unformatted',status='new')
     write(name,'("data/seed",I1,"_arm",I1,"_blocks.bin")')seed,arm
     open(newunit=ub,file=trim(name),access='stream',form='unformatted',status='new')
     row=0._dp;row(2:11)=x(1:10);row(12:18)=fluxes(x);write(u)row
     do j=1,total
       current_E=.8_dp
       if(arm==1.or.(arm==3.and.j<=pulse))current_E=1.2_dp
       if(arm==2.or.(arm==4.and.j<=pulse))current_E=.4_dp
       call adv_budget(x,spin+j,q)
       ky=dt*q-comp;kt=fint+ky;comp=(kt-fint)-ky;fint=kt
       bm=bm+x(1:10);bf=bf+q
       if(j>total/2)then
         tailx=tailx+x(1:10);tailf=tailf+q;ntail=ntail+1_8
       endif
       if(mod(j,100_8)==0)then
         res(1)=(x(8)+x(9)-startc)-(fint(1)-fint(3)-fint(4)-fint(5)-fint(6))
         res(2)=(x(10)-starta)-(fint(7)-2._dp*fint(6))
         maxres=max(maxres,abs(res))
         row(1)=real(j,dp)*dt;row(2:11)=x(1:10);row(12:18)=fint
         row(19:20)=res;row(21)=current_E;row(22)=real(seed,dp);write(u)row
       endif
       if(mod(j,block)==0)then
         row=0._dp;row(1)=(real(j,dp)-.5_dp*real(block,dp))*dt
         row(2:11)=bm/real(block,dp);row(12:18)=bf/real(block,dp)
         row(21)=current_E;row(22)=real(seed,dp);write(ub)row
         bm=0._dp;bf=0._dp
       endif
     enddo
     close(u);close(ub)
     if(.not.all(abs(x)<huge(1._dp)))error stop 'nonfinite final state'
     if(maxval(maxres)>1.e-7_dp)error stop 'budget closure tolerance'
     write(us,'(2I3,19ES25.16E3)')seed,arm,tailx/real(ntail,dp),tailf/real(ntail,dp),maxres
     flush(us)
     print *,'DONE',seed,arm,'budget closure',maxres
   enddo
 enddo
 close(us)
 open(newunit=unit,file='COMPUTE_DONE',status='new');write(unit,*)nseed,narm;close(unit)
contains
 subroutine adv_budget(s,it,quad)
   real(dp),intent(inout)::s(18)
   integer(kind=8),intent(in)::it
   real(dp),intent(out)::quad(7)
   real(dp)::k1(10),k2(10),k3(10),k4(10),tmp(18),f1(7),f2(7),f3(7),f4(7),h
   k1=derivs(s,it,10);f1=fluxes(s)
   tmp=s;tmp(1:10)=s(1:10)+.5*dt*k1
   k2=derivs(tmp,it,10);f2=fluxes(tmp)
   tmp=s;tmp(1:10)=s(1:10)+.5*dt*k2
   k3=derivs(tmp,it,10);f3=fluxes(tmp)
   tmp=s;tmp(1:10)=s(1:10)+dt*k3
   k4=derivs(tmp,it,10);f4=fluxes(tmp)
   s(1:10)=s(1:10)+(dt/6._dp)*(k1+2._dp*k2+2._dp*k3+k4)
   quad=(f1+2._dp*f2+2._dp*f3+f4)/6._dp
   h=.1_dp*s(2)**2+.1_dp*s(4)**2+10._dp*s(15)**2
   if(h>50._dp)then
     s(6)=0._dp
   elseif(h<10._dp)then
     s(6)=1._dp
   else
     s(6)=.5_dp*(exp(-(h-10._dp)/80._dp)+exp(-1._dp/max(50._dp-h,1.e-10_dp)))
   endif
   s(15)=s(6)
 end subroutine
end program

from pathlib import Path
import json, hashlib
import numpy as np
B=Path(__file__).resolve().parent
source=B.parent/'eta_figures_revision_20261029'/'revised_data.json'
r=json.loads(source.read_text()); s=r['summary']['mean_anomaly_controls']
A=np.asarray(s['mean']['by_initial_condition'])
D=np.asarray(s['anomaly']['by_initial_condition'])
T=np.asarray(s['M7']['by_initial_condition'])
I=T-A-D
mean_alloc=A+.5*I
anomaly_alloc=D+.5*I
rng=np.random.default_rng(20261030)
boot=rng.integers(0,10,(19999,10))
def stats(x):
    return dict(mean=float(x.mean()),
                ci95=np.percentile(x[boot].mean(axis=1),[2.5,97.5]).tolist(),
                by_initial_condition=x.tolist())
rows={k:stats(x) for k,x in [('mean_setting',A),('anomaly_setting',D),
    ('interaction',I),('total',T),('mean_half_interaction_allocation',mean_alloc),
    ('anomaly_half_interaction_allocation',anomaly_alloc)]}
closure=float(np.max(np.abs(A+D+I-T)))
assert closure<1e-12
assert np.max(np.abs(mean_alloc+anomaly_alloc-T))<1e-12

# Audit the important distinction between subtracting a fixed reference mean
# and enforcing a zero mean in the counterfactual anomaly-feedback trajectory.
P=B.parent/'w_feedback_20261029'/'data'
audit=[]
for seed in range(10):
    receipt=json.loads((P/f'anomaly_seed{seed}'/'receipt.json').read_text())
    ref=receipt['fixed_reference_Catm']
    a=np.memmap(P/f'anomaly_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))
    residual=a[1:,5]-ref
    audit.append(dict(seed=seed,fixed_reference_Catm=ref,
        anomaly_run_Catm_mean=float(a[1:,5].mean()),
        residual_mean=float(residual.mean()),residual_std=float(residual.std()),
        residual_mean_relative_to_std=float(residual.mean()/residual.std())))

result=dict(source_path=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    c28=1,low_band_decade_inverse=[.5,.75],reference='M3: c24 off, c16/c17 remain dynamic',
    definition='All effects 100*(P_case-P_M3)/P_M3 within each IC, then average 10 IC. Each power first averages 20 windows.',
    factors='Fixed reference mean term and state-dependent residual term within c24; NOT guaranteed pure zero-mean fluctuation attribution.',
    decomposition=rows,closure_max_abs_percent_points=closure,
    uncertainty='19999 paired IC bootstraps, seed 20261030; exploratory 95% intervals; consecutive windows not resampled as independent realizations',
    anomaly_mean_audit=audit,
    allocation_warning='Half-interaction allocation is a convention averaging the two activation orders, not a uniquely measured physical contribution.',
    physical_warning='Algebraic closure of an intervention effect, not energy-budget closure. No new integrations, no single-sided flux modifications.')
(B/'factor_separation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(decomposition=rows,closure=closure,anomaly_mean_audit=audit),indent=2),flush=True)

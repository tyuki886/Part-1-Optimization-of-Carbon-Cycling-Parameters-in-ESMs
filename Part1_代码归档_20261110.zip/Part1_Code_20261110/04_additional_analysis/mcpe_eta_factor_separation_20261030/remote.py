from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,r'D:\ClaudeFiles\项目2-Levante超算')
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/eta_factor_separation_20261030'
c=hpc.connect()
try:
    mode=sys.argv[1]
    if mode=='submit':
        with c.open_sftp() as f:
            try:
                f.stat(R);raise RuntimeError('目录已存在，拒绝覆盖')
            except FileNotFoundError:f.mkdir(R)
            f.put(str(B/'analyze.py'),R+'/analyze.py')
        cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=1G --time=00:03:00 --job-name=eta_factor --output=factor-%j.log --wrap='+shlex.quote('/home/b/b382207/conda/envs/yuki/bin/python analyze.py')
        rc,out,err=hpc.run(c,cmd)
        if rc:raise RuntimeError(err)
        j=re.search(r'Submitted batch job (\d+)',out).group(1)
        (B/'submission.json').write_text(json.dumps(dict(job=j,remote=R,account='ab0246')))
        print(out)
    elif mode=='status':
        j=json.loads((B/'submission.json').read_text())['job']
        rc,out,err=hpc.run(c,'sacct -n -j '+j+' --format=JobID,State,ExitCode,Elapsed; test -f '+shlex.quote(R+'/factor_separation.json')+' && echo RESULT_COMPLETE')
        print(out)
    elif mode=='fetch':
        with c.open_sftp() as f:f.get(R+'/factor_separation.json',str(B/'factor_separation.json'))
        print('因子分离结果已下载')
finally:c.close()

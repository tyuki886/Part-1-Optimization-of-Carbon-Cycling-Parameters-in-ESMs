using System;
using System.IO;
using System.Globalization;
public static class TermExperiment {
 const double Dt=0.01;
 public static double[] Derivative(double[] s,long it) {
   double[] d=new double[10]; double[] f=new double[5]; Eval(s,it,d,f); return d;
 }
 static void Eval(double[] s,long it,double[] d,double[] f) {
   double p=Math.Max(s[8]-1.2*s[9],0.0);
   f[0]=0.1*(1.0-0.01*s[3])*(s[7]-p);
   f[1]=0.01*s[7]*s[6];
   f[2]=0.001*s[0]*(s[6]-s[3]);
   f[3]=0.01*(1.0-0.01*s[3])*s[4];
   f[4]=0.00009*s[8]*Math.Max(s[9]-0.5*s[8]+1.0,0.0);
   d[0]=9.95*(s[1]-s[0])-(0.3+0.01*s[6])+0.1*(s[6]-s[3]);
   d[1]=-s[0]*s[2]+(1.0+0.1*s[3])*28.0*s[0]-s[1]+0.01*28.0*s[6]*s[0]+0.1*s[7];
   d[2]=s[0]*s[1]-(8.0/3.0)*s[2];
   d[3]=(s[1]+0.01*s[4]+0.01*s[3]*s[4]-s[3]-0.1*s[14]+0.05*s[0]*(s[6]-s[3])+10.0*(1.0+0.001*s[7])+Math.Cos(2.0*Math.PI*it*0.01/10.0))/10.0;
   d[4]=(s[3]+0.001*s[3]*s[4]-s[4])/100.0;
   d[5]=0.0;
   d[6]=(0.5*s[1]-0.4*s[6]-0.05*s[0]*(s[6]-s[3])+5.0*(1.0+0.005*s[7])+Math.Cos(2.0*Math.PI*it*0.01/10.0))/2.0;
   d[7]=0.8-f[0]-f[1]-f[2];
   d[8]=f[0]-f[3]-f[4];
   d[9]=0.0018-2.0*f[4];
 }
 static void Add(double[] a,double[] c,int i,double v) {
   double y=v-c[i],t=a[i]+y;c[i]=(t-a[i])-y;a[i]=t;
 }
 public static void Run(string directory,int id,double initialX2) {
   CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;
   double[] s=new double[18];s[1]=initialX2;
   double[][] k={new double[10],new double[10],new double[10],new double[10]};
   double[][] f={new double[5],new double[5],new double[5],new double[5]};
   double[] tmp=new double[18],tot=new double[5],comp=new double[5],start=new double[3];
   double[,] native=new double[5,6];
   for(int j=0;j<5;j++){native[j,3]=Double.PositiveInfinity;native[j,4]=Double.NegativeInfinity;}
   long spin=1000000,end=6000000;
   using(var b=new BinaryWriter(File.Create(Path.Combine(directory,"states_"+id+".bin"))))
   using(var early=new StreamWriter(Path.Combine(directory,"early_"+id+".csv")))
   using(var budget=new StreamWriter(Path.Combine(directory,"budgets_"+id+".csv"))) {
     budget.WriteLine("end_TU,Fas_integral,Fland_integral,Fconv_integral,Fexp_integral,Bcal_integral,delta_Catm,delta_Cocn,delta_ALK");
     for(long it=1;it<=end;it++) {
       Eval(s,it,k[0],f[0]);
       Array.Copy(s,tmp,18);for(int j=0;j<10;j++)tmp[j]=s[j]+0.5*Dt*k[0][j];Eval(tmp,it,k[1],f[1]);
       Array.Copy(s,tmp,18);for(int j=0;j<10;j++)tmp[j]=s[j]+0.5*Dt*k[1][j];Eval(tmp,it,k[2],f[2]);
       Array.Copy(s,tmp,18);for(int j=0;j<10;j++)tmp[j]=s[j]+Dt*k[2][j];Eval(tmp,it,k[3],f[3]);
       for(int j=0;j<10;j++)s[j]+=(Dt/6.0)*(k[0][j]+2.0*k[1][j]+2.0*k[2][j]+k[3][j]);
       double h=0.1*s[1]*s[1]+0.1*s[3]*s[3]+10.0*s[14]*s[14];
       if(h>50.0)s[5]=0.0;else if(h<10.0)s[5]=1.0;
       else s[5]=0.5*(Math.Exp(-(h-10.0)/80.0)+Math.Exp(-1.0/Math.Max(50.0-h,1e-10)));
       s[14]=s[5];
       if(it<=100) {early.Write(it);for(int j=0;j<18;j++)early.Write(","+s[j].ToString("R"));early.WriteLine();}
       if(it==spin)for(int j=0;j<3;j++)start[j]=s[7+j];
       if(it>spin) {
         for(int j=0;j<5;j++) {
           double v=f[0][j];native[j,0]+=v;native[j,1]+=Math.Abs(v);native[j,2]+=v*v;
           if(v<native[j,3])native[j,3]=v;if(v>native[j,4])native[j,4]=v;if(v<0)native[j,5]+=1.0;
         }
         for(int j=0;j<5;j++)Add(tot,comp,j,(Dt/6.0)*(f[0][j]+2.0*f[1][j]+2.0*f[2][j]+f[3][j]));
         if(it%10==0)for(int j=0;j<10;j++)b.Write(s[j]);
         if(it%1000000==0) {
           budget.Write((it*Dt).ToString("R"));for(int j=0;j<5;j++)budget.Write(","+tot[j].ToString("R"));
           for(int j=0;j<3;j++)budget.Write(","+(s[7+j]-start[j]).ToString("R"));budget.WriteLine();budget.Flush();
           Console.WriteLine("Run "+id+": "+(it*Dt)+" TU completed");
           for(int j=0;j<5;j++){tot[j]=0;comp[j]=0;}for(int j=0;j<3;j++)start[j]=s[7+j];
         }
       }
       if(!Double.IsFinite(s[7]) || !Double.IsFinite(s[9]))throw new Exception("Nonfinite state at step "+it);
     }
   }
   using(var output=new StreamWriter(Path.Combine(directory,"native_flux_"+id+".csv"))) {
     output.WriteLine("term,mean,mean_abs,rms,min,max,negative_fraction");
     string[] names={"Fas","Fland","Fconv","Fexp","Bcal"};
     for(int j=0;j<5;j++)output.WriteLine(names[j]+","+(native[j,0]/(end-spin)).ToString("R")+","+(native[j,1]/(end-spin)).ToString("R")+","+Math.Sqrt(native[j,2]/(end-spin)).ToString("R")+","+native[j,3].ToString("R")+","+native[j,4].ToString("R")+","+(native[j,5]/(end-spin)).ToString("R"));
   }
 }
}

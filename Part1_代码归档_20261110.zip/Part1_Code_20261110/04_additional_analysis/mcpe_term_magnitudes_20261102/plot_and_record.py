from pathlib import Path
import sys,json,csv
import numpy as np
sys.path.append(r'D:\python\Lib\site-packages')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
sys.stdout.reconfigure(encoding='utf-8')
B=Path(__file__).resolve().parent
r=json.loads((B/'results.json').read_text(encoding='utf-8'))
s=r['summary'];native=r['native_step_flux_summary']
font=Path(r'C:\Windows\Fonts\times.ttf');fm.fontManager.addfont(str(font))
plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'mathtext.fontset':'stix',
    'axes.labelsize':12,'axes.titlesize':14,'xtick.labelsize':11,'ytick.labelsize':13,
    'axes.linewidth':.8,'savefig.dpi':300,'figure.facecolor':'white'})
groups=[('Atmospheric carbon',[(r'$E_0$',.8,.8),(r'$F_{as}$',native['Fas']['mean'],native['Fas']['rms']),
    (r'$F_{land}$',native['Fland']['mean'],native['Fland']['rms']),
    (r'$F_{conv}$',native['Fconv']['mean'],native['Fconv']['rms'])]),
    ('Oceanic carbon',[(r'$F_{as}$',native['Fas']['mean'],native['Fas']['rms']),
    (r'$F_{exp}$',native['Fexp']['mean'],native['Fexp']['rms']),
    (r'$B_{cal}$',native['Bcal']['mean'],native['Bcal']['rms'])]),
    ('Ocean alkalinity',[(r'$A_0$',.0018,.0018),
    (r'$2B_{cal}$',2*native['Bcal']['mean'],2*native['Bcal']['rms'])])]
fig,axs=plt.subplots(1,3,figsize=(14.4,4.5),layout=None)
for i,(ax,(title,items)) in enumerate(zip(axs,groups)):
    for j,(label,mean,rms) in enumerate(items):
        ax.plot([mean,rms],[j,j],color='#b5b5b5',lw=1.2,zorder=1)
        ax.scatter(mean,j,c='#cc8736',marker='o',s=54,zorder=3,label='Signed mean' if i==0 and j==0 else None)
        ax.scatter(rms,j,c='#356aa3',marker='D',s=32,zorder=4,label='RMS' if i==0 and j==0 else None)
        ax.annotate(f'{mean:.3g} / {rms:.3g}',(min(mean,rms),j),xytext=(0,11),textcoords='offset points',fontsize=11,ha='left')
    ax.set_yticks(range(len(items)),[x[0] for x in items]);ax.set_ylim(len(items)-.55,-.9)
    ax.set_xscale('log');ax.set_xlim(2e-4,2)
    ax.set_xticks([1e-3,1e-2,1e-1,1]);ax.grid(axis='x',which='major',color='#dedede',lw=.7,zorder=0)
    ax.set_xlabel('Term magnitude (nondimensional / TU)')
    ax.set_title(f'({chr(97+i)}) {title}',pad=13)
    ax.spines[['right','top']].set_visible(False)
handles,labels=axs[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.91),ncol=2,frameon=False,columnspacing=2.0)
fig.suptitle('Measured magnitudes of the carbon-budget terms',fontsize=16,y=.995)
fig.subplots_adjust(left=.057,right=.985,bottom=.22,top=.77,wspace=.28)
fig.text(.5,.035,'Labels: mean / RMS.  Three nearby initial states; evaluation: 10000–60000 TU.  '+
         r'$F_{conv}<0$ during 41.3% of the native integration steps.',ha='center',fontsize=11)
fig.savefig(B/'Carbon_budget_term_magnitudes.png',dpi=300)
fig.savefig(B/'Carbon_budget_term_magnitudes_preview.png',dpi=130)
plt.close(fig)

exact={n:float(np.mean([v['window_mean_'+n] for v in r['manifest']['budget_validation']]))
    for n in ['Fas','Fland','Fconv','Fexp','Bcal']}
closure={'Catm_mean_tendency':.8-exact['Fas']-exact['Fland']-exact['Fconv'],
    'Cocn_mean_tendency':exact['Fas']-exact['Fexp']-exact['Bcal'],
    'ALK_mean_tendency':.0018-2*exact['Bcal']}
r['integrator_weighted_means']=exact;r['mean_budget_net_tendencies']=closure
(B/'results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
with (B/'原生步长通量统计.csv').open('w',encoding='utf-8-sig',newline='') as f:
    names=['term','mean_native','mean_abs_native','rms_native','negative_fraction_native','mean_RK4_quadrature']
    w=csv.DictWriter(f,fieldnames=names);w.writeheader()
    for n,x in native.items():w.writerow(dict(term=n,mean_native=x['mean'],mean_abs_native=x['mean_abs'],
        rms_native=x['rms'],negative_fraction_native=x['negative_fraction'],mean_RK4_quadrature=exact[n]))

notes=f'''# 当前参考模式各项量级实测\n\n运行日期：2026-11-02。未更改论文、原代码或参数值。\n\n## 方法\n\n来源：{r['manifest']['source']}\n\n源文件SHA256：{r['manifest']['source_sha256']}\n\n沿用最新参数命名，c29=1，c28=0.5，c27=9×10⁻⁵，E0=0.8，A0=0.0018。不进行同化、不更换参数。三个初态仅x2取1、1.01、1.1，其余为零；分别起转10000 TU，随后测量10000–60000 TU。五个10000-TU窗，共15个描述性时间窗，不作为独立随机种子显著性样本。\n\n采用当前Fortran参考自由模式的RK4与海冰滞后一致实现。四个RK阶段均沿用原it*0.01季节时刻，不自行修正积分算法。C#计算内核与独立Python逐步实现前100步比较的最大差异不超过{max(x['first_100_steps_max_abs_difference'] for x in r['manifest']['numerical_validation']):.2e}。碳通量逐0.01 TU统计，共15000000点；状态、分位数及热强迫逐0.1 TU采样。\n\n三条收支均用RK4四阶段加权通量积分核对状态变化，最大窗口闭合残差{max(max(x['max_abs_integrated_budget_residuals']) for x in r['manifest']['budget_validation']):.3e}；积分步点统计均值与RK4求积均值分开保存，不混用来主张精确闭合。c27的自由代码常量乘积与字面值9e-5只相差一个浮点舍入单位，不声称长期混沌轨迹逐位相同。增加原生统计计数器后，三个轨迹文件哈希均未改变。\n\n## 三条直接反馈\n\n|项|均值|参考比较|\n|---|---:|---|\n|c16 Catm|{s['c16_Catm']['mean']:.6f}|RMS为同一10VCC轨迹上x2非碳右端RMS的{100*s['c16_Catm']['rms']/s['x2_noncarbon']['rms']:.3f}%|\n|Slm c17 Catm|{s['Slm_c17_Catm']['mean']:.6f}|占Slm=5的{100*s['land_fraction']['mean']:.3f}%|\n|Sm c18 Catm|{s['Sm_c18_Catm']['mean']:.6f}|占Sm=10的{100*s['ocean_fraction']['mean']:.3f}%|\n\n除以热容量后的新增TL倾向均值{s['thermal_land_tendency']['mean']:.6f}，w倾向均值{s['thermal_ocean_tendency']['mean']:.6f}。这是直接倾向幅度，不等于长期耦合影响或能量贡献。\n\n## 碳预算通量\n\n|定义项|逐步均值|逐步RMS|负值时间比例|\n|---|---:|---:|---:|\n'''
for n,x in native.items():notes+=f"|{n}|{x['mean']:.8g}|{x['rms']:.8g}|{100*x['negative_fraction']:.5g}%|\n"
notes+=f'''\nE0为0.8；A0为0.0018。Fconv的平均绝对值{native['Fconv']['mean_abs']:.8g}，大于其带符号均值，不能用其均值代表波动幅度。Fconv为负时，Catm方程里的−Fconv是正源项，故当前公式不支持将其描述为始终单向的埋藏碳汇。\n\nRK4加权均值：{json.dumps(exact,ensure_ascii=False)}\n\n平均净倾向：{json.dumps(closure,ensure_ascii=False)}\n\n平均温度因子1−c20w=1−c24w为{s['temperature_factor']['mean']:.6f}；采样极值{s['temperature_factor']['min']:.6f}–{s['temperature_factor']['max']:.6f}。这不是理论边界，状态也未被归一化到[-1,1]。参考试验海洋大多吸收大气碳，不能把温度修正项直接说成导致持续海洋放碳。\n\n原先假设状态Catm=6、Cocn=10、ALK=5、TL=12等的手算例子应替换为本次轨迹统计。当前参考值的运行量级验证并不等于重建这些系数当初的标定历史，亦不证明该组取值唯一最优。\n\n细项、所有状态、各窗均值与分位数见results.json及项量级统计.csv；分位数为各轨迹分位数的均值，未当作置信区间。\n'''
(B/'量级测试记录.md').write_text(notes,encoding='utf-8')
Path(r'D:\ClaudeFiles\运行记录\2026-11-02-MCPE方程各项量级实测.md').write_text(notes,encoding='utf-8')
print('EXACT WEIGHTED MEANS',exact)
print('MEAN NET TENDENCIES',closure)
print('Figure, numerical records and statistics saved.')

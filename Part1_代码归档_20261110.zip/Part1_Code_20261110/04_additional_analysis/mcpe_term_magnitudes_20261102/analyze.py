from pathlib import Path
from zipfile import ZipFile
import sys,json,hashlib,shutil,csv
import numpy as np
sys.stdout.reconfigure(encoding='utf-8')
B=Path(__file__).resolve().parent
SRC=Path(r'D:\科研王！\MCPE\1.0\part12\拆分稿_20261027\c29同步更新_20261030\最终代码\free_model\RKmethod_reference.f90')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
text=SRC.read_text(encoding='utf-8')
for clause in ['c29=1.0_dp','c17=0.005_dp','c18=0.001_dp','A0=0.0018_dp','E0=0.8_dp']:
    assert clause in text,clause
shutil.copy2(SRC,B/'reference_source.f90')

def derivative(s,it):
    x1,x2,x3,w,eta,phi,tl,ca,co,alk=s[:10]
    p=max(co-1.2*alk,0);b=.01*.009*co*max(alk-.5*co+1,0)
    fas=.1*(1-.01*w)*(ca-p);fl=.01*ca*tl;fc=.001*x1*(tl-w);fe=.01*(1-.01*w)*eta
    z=np.zeros(10)
    z[0]=9.95*(x2-x1)-(.3+.01*tl)+.1*(tl-w)
    z[1]=-x1*x3+(1+.1*w)*28*x1-x2+.01*28*tl*x1+.1*ca
    z[2]=x1*x2-(8/3)*x3
    z[3]=(x2+.01*eta+.01*w*eta-w-.1*s[14]+.05*x1*(tl-w)+10*(1+.001*ca)+np.cos(2*np.pi*it*.01/10))/10
    z[4]=(w+.001*w*eta-eta)/100
    z[6]=(.5*x2-.4*tl-.05*x1*(tl-w)+5*(1+.005*ca)+np.cos(2*np.pi*it*.01/10))/2
    z[7]=.8-fas-fl-fc;z[8]=fas-fe-b;z[9]=.0018-2*b
    return z

verification=[]
for run,x2 in enumerate([1,1.01,1.1]):
    s=np.zeros(18);s[1]=x2
    ref=np.loadtxt(B/f'early_{run}.csv',delimiter=',')
    maxerr=0
    for it in range(1,101):
        k1=derivative(s,it);a=s.copy();a[:10]+=.005*k1
        k2=derivative(a,it);a=s.copy();a[:10]+=.005*k2
        k3=derivative(a,it);a=s.copy();a[:10]+=.01*k3;k4=derivative(a,it)
        s[:10]+=(.01/6)*(k1+2*k2+2*k3+k4)
        h=.1*s[1]**2+.1*s[3]**2+10*s[14]**2
        s[5]=0 if h>50 else 1 if h<10 else .5*(np.exp(-(h-10)/80)+np.exp(-1/max(50-h,1e-10)))
        s[14]=s[5];maxerr=max(maxerr,float(np.max(np.abs(s-ref[it-1,1:]))))
    assert maxerr<1e-9,(run,maxerr)
    verification.append({'run':run,'first_100_steps_max_abs_difference':maxerr})

def metrics(s):
    x1,x2,x3,w,eta,phi,tl,ca,co,alk=s.T
    time=10000+.1*np.arange(1,len(s)+1)
    p=np.maximum(co-1.2*alk,0);q=alk-.5*co+1;b=.00009*co*np.maximum(q,0)
    fas=.1*(1-.01*w)*(ca-p);fl=.01*ca*tl;fc=.001*x1*(tl-w);fe=.01*(1-.01*w)*eta
    m=dict(x1=x1,x2=x2,x3=x3,w=w,eta=eta,ice=phi,TL=tl,Catm=ca,Cocn=co,ALK=alk,
        pCO2oc=p,Q=q,carbon_contrast=ca-p,temperature_factor=1-.01*w,
        c16_Catm=.1*ca,Slm_c17_Catm=5*.005*ca,Sm_c18_Catm=10*.001*ca,
        land_fraction=.005*ca,ocean_fraction=.001*ca,c20_w=.01*w,
        E0=np.full(len(s),.8),Fas=fas,Fland=fl,Fconv=fc,Fexp=fe,Bcal=b,
        A0=np.full(len(s),.0018),two_Bcal=2*b,
        dCatm=.8-fas-fl-fc,dCocn=fas-fe-b,dALK=.0018-2*b,
        x2_noncarbon=-x1*x3+(1+.1*w)*28*x1-x2+.01*28*tl*x1,
        x2_quadratic=-x1*x3,x2_base_forcing=28*x1,x2_ocean_forcing=.1*w*28*x1,
        x2_damping=-x2,x2_land_forcing=.01*28*tl*x1,
        w_atmosphere=x2,w_deep_linear=.01*eta,w_deep_nonlinear=.01*w*eta,
        w_damping=-w,w_ice=-.1*phi,w_land=.05*x1*(tl-w),
        Sm=np.full(len(s),10.0),w_season=np.cos(2*np.pi*time/10),
        TL_atmosphere=.5*x2,TL_damping=-.4*tl,TL_ocean=-.05*x1*(tl-w),
        Slm=np.full(len(s),5.0),TL_season=np.cos(2*np.pi*time/10),
        thermal_land_tendency=5*.005*ca/2,thermal_ocean_tendency=10*.001*ca/10)
    return m

def describe(v):
    q=np.percentile(v,[5,50,95])
    return dict(mean=float(v.mean()),mean_abs=float(np.abs(v).mean()),rms=float(np.sqrt(np.mean(v*v))),
        std=float(v.std()),p05=float(q[0]),median=float(q[1]),p95=float(q[2]),min=float(v.min()),max=float(v.max()),
        negative_fraction=float(np.mean(v<0)))

all_stats=[];window_stats=[];ratios=[];budget_checks=[]
for run in range(3):
    p=B/f'states_{run}.bin';assert p.stat().st_size==500000*10*8
    s=np.memmap(p,dtype='<f8',mode='r',shape=(500000,10));assert np.isfinite(s).all()
    m=metrics(s)
    st={name:describe(v) for name,v in m.items()}
    all_stats.append(st)
    for win in range(5):
        ix=slice(win*100000,(win+1)*100000)
        window_stats.append(dict(run=run,start_TU=10000+win*10000,end_TU=20000+win*10000,
            metrics={name:describe(v[ix]) for name,v in m.items()}))
    ratios.append(dict(run=run,land_heat_input_percent=100*st['land_fraction']['mean'],
        ocean_heat_input_percent=100*st['ocean_fraction']['mean'],
        atmospheric_rhs_rms_ratio=st['c16_Catm']['rms']/st['x2_noncarbon']['rms'],
        Fconv_mean_over_E0=st['Fconv']['mean']/.8,
        Fconv_rms_over_E0=st['Fconv']['rms']/.8,
        burial_over_export=st['Bcal']['mean']/st['Fexp']['mean']))
    d=np.genfromtxt(B/f'budgets_{run}.csv',delimiter=',',names=True)
    ca=.8*10000-d['Fas_integral']-d['Fland_integral']-d['Fconv_integral']
    co=d['Fas_integral']-d['Fexp_integral']-d['Bcal_integral']
    alk=.0018*10000-2*d['Bcal_integral']
    err=np.array([np.max(np.abs(ca-d['delta_Catm'])),np.max(np.abs(co-d['delta_Cocn'])),np.max(np.abs(alk-d['delta_ALK']))])
    assert err.max()<1e-8,err
    budget_checks.append(dict(run=run,max_abs_integrated_budget_residuals=err.tolist(),
       window_mean_Fas=(d['Fas_integral']/10000).tolist(),
       window_mean_Fland=(d['Fland_integral']/10000).tolist(),
       window_mean_Fconv=(d['Fconv_integral']/10000).tolist(),
       window_mean_Fexp=(d['Fexp_integral']/10000).tolist(),
       window_mean_Bcal=(d['Bcal_integral']/10000).tolist()))
    print('MEASURED RUN',run,flush=True)

pooled={}
for k in all_stats[0]:
    pooled[k]={n:float(np.mean([x[k][n] for x in all_stats])) for n in all_stats[0][k]}
    pooled[k]['rms']=float(np.sqrt(np.mean([x[k]['rms']**2 for x in all_stats])))
    pooled[k]['mean_run_min']=min(x[k]['mean'] for x in all_stats)
    pooled[k]['mean_run_max']=max(x[k]['mean'] for x in all_stats)
    pooled[k]['mean_window_min']=min(x['metrics'][k]['mean'] for x in window_stats)
    pooled[k]['mean_window_max']=max(x['metrics'][k]['mean'] for x in window_stats)
    pooled[k]['min']=min(x[k]['min'] for x in all_stats)
    pooled[k]['max']=max(x[k]['max'] for x in all_stats)
    # Percentiles remain explicitly averages of each trajectory's percentiles.
    pooled[k]['percentile_definition']='Mean of three within-trajectory percentiles; not pooled quantiles'

manifest=dict(source=str(SRC),source_sha256=sha(SRC),solver='Faithful C# transcription of current reference RK4',
    dt_TU=.01,spinup_TU=10000,evaluation_TU=[10000,60000],sample_interval_TU=.1,
    initials_x2=[1,1.01,1.1],other_initial_states=0,parameter_changes=False,
    seasonal_timing='As in original Fortran: all RK stages use it*0.01; sea ice lag updated after full step',
    c27_float_note='C# uses literal 9e-5; Fortran free-model constant .01*.009 differs by at most one rounding unit',
    numerical_validation=verification,budget_validation=budget_checks,
    statistic_note='Means and RMS over equally long trajectories. Window ranges are descriptive, not confidence intervals.',
    samples_per_run=500000,number_of_initial_conditions=3,
    files={p.name:sha(p) for p in B.glob('states_*.bin')})
out=dict(manifest=manifest,summary=pooled,per_run=all_stats,windows=window_stats,ratios=ratios)
(B/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
with (B/'项量级统计.csv').open('w',encoding='utf-8-sig',newline='') as f:
    names=['term','mean','mean_abs','rms','p05','p95','min','max','negative_fraction','mean_window_min','mean_window_max']
    w=csv.DictWriter(f,fieldnames=names);w.writeheader()
    for name,v in pooled.items():w.writerow({'term':name,**{k:v[k] for k in names[1:]}})
for name in ['Catm','Cocn','ALK','c16_Catm','Slm_c17_Catm','Sm_c18_Catm','temperature_factor','E0','Fas','Fland','Fconv','Fexp','Bcal','A0','two_Bcal','dCatm','dCocn','dALK']:
    x=pooled[name];print(name,json.dumps({k:x[k] for k in ['mean','mean_abs','rms','p05','p95','negative_fraction','mean_window_min','mean_window_max']}))
print('RATIOS',json.dumps(ratios))
print('BUDGET MAX RESIDUAL',max(max(x['max_abs_integrated_budget_residuals']) for x in budget_checks))

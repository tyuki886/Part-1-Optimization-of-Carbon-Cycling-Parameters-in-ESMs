from pathlib import Path
import sys,shlex,json,re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/tl_route_sediment_20261029/extra'
c=hpc.connect()
try:
 mode=sys.argv[1]
 if mode=='submit':
  with c.open_sftp() as s:
   try:s.stat(R);raise RuntimeError('额外目录已存在')
   except FileNotFoundError:s.mkdir(R)
   for n in ['extra_module.f90','extra_experiment.f90','run_extra.py']:s.put(str(B/n),R+'/'+n)
  cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=4 --mem=8G --time=00:15:00 --job-name=tl_atmos_split --output=compute-%j.log --wrap='+shlex.quote('export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python run_extra.py')
  rc,out,err=hpc.run(c,cmd)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'extra_submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
 elif mode=='status':
  job=json.loads((B/'extra_submission.json').read_text())['job']
  rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -6 '+shlex.quote(R+'/compute-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/completion.json')+' && echo EXTRA_COMPLETE')
  print(out)
 elif mode=='analyze':
  with c.open_sftp() as s:
   for n in ['analyze_extra.py','plot_extra.py']:s.put(str(B/n),R+'/'+n)
  cmd='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=8G --time=00:10:00 --job-name=tl_atmos_analysis --output=analysis-%j.log --wrap='+shlex.quote('export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python analyze_extra.py && /home/b/b382207/conda/envs/yuki/bin/python plot_extra.py')
  rc,out,err=hpc.run(c,cmd)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'extra_analysis_submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
 elif mode=='analysis-status':
  job=json.loads((B/'extra_analysis_submission.json').read_text())['job']
  rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -8 '+shlex.quote(R+'/analysis-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/extra_figure_manifest.json')+' && echo EXTRA_ANALYSIS_COMPLETE')
  print(out)
 elif mode=='fetch':
  with c.open_sftp() as s:
   for name in ['completion.json','atmosphere_split.json','atmosphere_summary.json','extra_figure_manifest.json','Atmosphere_route_split.png','Atmosphere_route_split_preview.png']:
    s.get(R+'/'+name,str(B/('extra_completion.json' if name=='completion.json' else name)))
  print('大气内部拆分结果已下载。')
finally:c.close()

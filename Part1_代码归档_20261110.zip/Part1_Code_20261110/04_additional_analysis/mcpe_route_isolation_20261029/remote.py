from pathlib import Path
import sys,json,shlex,re
B=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(r'D:\ClaudeFiles\项目2-Levante超算')))
import hpc
R='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/tl_route_sediment_20261029'
c=hpc.connect()
try:
 mode=sys.argv[1]
 if mode=='submit':
  rc,out,err=hpc.run(c,'df -Pk /work/ab0246/wuyuhang')
  if rc:raise RuntimeError(err)
  assert int(out.strip().splitlines()[-1].split()[3])*1024>5_000_000_000,'可用文件系统空间不足'
  with c.open_sftp() as s:
   try:s.stat(R);raise RuntimeError('独立实验目录已经存在，拒绝覆盖')
   except FileNotFoundError:s.mkdir(R)
   for name in ['RKmethod_reference.f90','path_module.f90','experiment.f90','check.f90','run_compute.py','configuration.json','source_manifest.json','times.ttf']:
    s.put(str(B/name),R+'/'+name)
  wrap='export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python run_compute.py'
  command='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=4 --mem=8G --time=00:30:00 --job-name=tl_route_sediment --output=compute-%j.log --wrap='+shlex.quote(wrap)
  rc,out,err=hpc.run(c,command)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2))
  print(out)
 elif mode=='status':
  job=json.loads((B/'submission.json').read_text())['job']
  rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -8 '+shlex.quote(R+'/compute-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/completion.json')+' && echo COMPLETE')
  print(out);print(err.strip())
 elif mode=='analysis':
  with c.open_sftp() as s:
   for name in ['analyze.py','plot.py']:s.put(str(B/name),R+'/'+name)
  wrap='export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1; /home/b/b382207/conda/envs/yuki/bin/python analyze.py && /home/b/b382207/conda/envs/yuki/bin/python plot.py'
  command='cd '+shlex.quote(R)+' && sbatch --account=ab0246 --partition=shared --ntasks=1 --cpus-per-task=1 --mem=8G --time=00:10:00 --job-name=tl_route_analysis --output=analysis-%j.log --wrap='+shlex.quote(wrap)
  rc,out,err=hpc.run(c,command)
  if rc:raise RuntimeError(err)
  job=re.search(r'Submitted batch job (\d+)',out).group(1)
  (B/'analysis_submission.json').write_text(json.dumps({'job':job,'remote':R,'account':'ab0246'},indent=2));print(out)
 elif mode=='analysis-status':
  job=json.loads((B/'analysis_submission.json').read_text())['job']
  rc,out,err=hpc.run(c,'squeue -h -j '+job+' -o "%i %T %M %R"; tail -10 '+shlex.quote(R+'/analysis-'+job+'.log')+' 2>/dev/null; test -f '+shlex.quote(R+'/figure_manifest.json')+' && echo COMPLETE')
  print(out);print(err.strip())
 elif mode=='fetch':
  with c.open_sftp() as s:
   for name in ['completion.json','isolation_results.json','summary.json','figure_manifest.json','TL_route_isolation.png','TL_route_isolation_preview.png','Sediment_isolation.png','Sediment_isolation_preview.png']:
    s.get(R+'/'+name,str(B/name))
  print('结果和两张图已下载。')
 else:raise RuntimeError('unknown operation')
finally:c.close()

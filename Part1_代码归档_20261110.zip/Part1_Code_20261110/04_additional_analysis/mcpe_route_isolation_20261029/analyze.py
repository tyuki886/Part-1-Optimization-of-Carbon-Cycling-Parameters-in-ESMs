from pathlib import Path
import json,math,itertools
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent
completion=json.loads((B/'completion.json').read_text())
assert len(completion['groups'])==20
cfg=json.loads((B/'configuration.json').read_text())
welch=cfg['welch']
KEYS=['w_band','eta_band','w_point','eta_point']
rng=np.random.default_rng(20261029)
boot=rng.integers(0,10,size=(19999,10))
def stats(v):
 v=np.asarray(v,float)
 assert v.shape==(10,) and np.isfinite(v).all()
 return {'mean':float(v.mean()),'ci95':np.percentile(v[boot].mean(axis=1),[2.5,97.5]).tolist(),
         'positive_count':int((v>0).sum()),'negative_count':int((v<0).sum()),'by_initial_condition':v.tolist()}
def metric(a,curves=False):
 out={};sp={}
 for v,col in [('w',2),('eta',3)]:
  f,p=signal.welch(a[:,col]-a[:,col].mean(),**welch)
  point=int(np.argmin(abs(f-.0056)));assert abs(f[point]-.0056)<1e-12
  band=(f*100>=.5)&(f*100<=1.5)
  out[v+'_point']=float(p[point]);out[v+'_band']=float(p[band].sum()/1.5)
  out[v+'_variance']=float(np.var(a[:,col]))
  if curves:sp[v]={'f':f.tolist(),'power':p.tolist()}
 for name,col in [('w',2),('eta',3),('TL',4),('Catm',5),('Cocn',6),('ALK',7),('Bcal_potential',8)]:
  out[name+'_mean']=float(a[:,col].mean())
  out[name+'_variance']=float(a[:,col].var())
 f,pw=signal.welch(a[:,2],**welch)
 _,pe=signal.welch(a[:,3],**welch)
 _,cs=signal.csd(a[:,2],a[:,3],**welch)
 k=int(np.argmin(abs(f-.0056)))
 out['gain2_point']=float(abs(cs[k]/pw[k])**2)
 out['coherence_point']=float(abs(cs[k])**2/(pw[k]*pe[k]))
 return (out,sp) if curves else out

all_data={};spectra={};validation={}
for mode in (1,2):
 masks=['reference']+[f'R{i}' for i in range(8)] if mode==1 else [f'S{i}' for i in range(4)]
 all_data[str(mode)]={};spectra[str(mode)]={}
 for label in masks:
  seedrows=[];seedcurves=[]
  for seed in range(10):
   a=np.memmap(B/'data'/f'mode{mode}_seed{seed}'/(label+'.bin'),dtype='<f8',mode='r',shape=(200001,9))
   rr=[];ss=[]
   for j in range(20):
    mm,sp=metric(a[j*10000+1:(j+1)*10000+1],True)
    rr.append(mm);ss.append(sp)
   seedrows.append({'blocks':rr,'mean':{k:float(np.mean([r[k] for r in rr])) for k in rr[0]},
                    'selected_window':metric(a[10000:20001])})
   seedcurves.append({v:np.mean([np.array(s[v]['power']) for s in ss],axis=0).tolist() for v in ['w','eta']})
  all_data[str(mode)][label]=seedrows
  spectra[str(mode)][label]={'f':ss[0]['eta']['f'],
    'w':np.mean([s['w'] for s in seedcurves],axis=0).tolist(),
    'eta':np.mean([s['eta'] for s in seedcurves],axis=0).tolist()}
 # All-gates-blocked reference identity is checked independently on saved states.
 if mode==1:
  errors=[]
  for seed in range(10):
   d=B/'data'/f'mode1_seed{seed}'
   a=np.memmap(d/'R0.bin',dtype='<f8',mode='r',shape=(200001,9))
   r=np.memmap(d/'reference.bin',dtype='<f8',mode='r',shape=(200001,9))
   errors.append(float(np.max(abs(a[:,[0,1,2,3,5,6,7,8]]-r[:,[0,1,2,3,5,6,7,8]]))))
  assert max(errors)<1e-12
  validation['all_routes_blocked_saved_nonland_max_abs']=errors

def subset_masks(mask):return [m for m in range(mask+1) if m&mask==m]
def factorial(mode,n,period='mean'):
 labels=[('R' if mode==1 else 'S')+str(i) for i in range(2**n)]
 out={}
 for key in KEYS:
  y=np.array([[all_data[str(mode)][label][s][period][key] for s in range(10)] for label in labels])
  base=y[0];assert (base>0).all()
  terms={}
  for m in range(1,2**n):
   term=sum((-1)**(m.bit_count()-t.bit_count())*y[t] for t in subset_masks(m))
   terms[str(m)]=100*term/base
  alloc={}
  for i in range(n):
   alloc[str(i)]=sum(terms[str(m)]/m.bit_count() for m in range(1,2**n) if m&(1<<i))
  total=100*(y[-1]-base)/base
  assert np.allclose(sum(terms.values()),total,rtol=1e-10,atol=1e-10)
  assert np.allclose(sum(alloc.values()),total,rtol=1e-10,atol=1e-10)
  # Separate check: average marginal contribution over all permutations.
  perm_alloc=np.zeros((n,10))
  for order in itertools.permutations(range(n)):
   m=0
   for i in order:
    new=m|(1<<i);perm_alloc[i]+=100*(y[new]-y[m])/base/math.factorial(n);m=new
  assert np.allclose(np.array(list(alloc.values())),perm_alloc,rtol=1e-10,atol=1e-10)
  effects={label:stats(100*(y[i]-base)/base) for i,label in enumerate(labels)}
  off={str(i):stats(100*(y[(2**n-1)^(1<<i)]-y[-1])/y[-1]) for i in range(n)}
  out[key]={'config_effects':effects,'factorial_terms':{k:stats(v) for k,v in terms.items()},
   'shapley':{k:stats(v) for k,v in alloc.items()},'total':stats(total),'individual_off_vs_full':off,
   'selected_initial0_percent':{label:float(100*(y[i,0]-base[0])/base[0]) for i,label in enumerate(labels)}}
 return out

route=factorial(1,3);sed=factorial(2,2)
selected_route=factorial(1,3,'selected_window');selected_sed=factorial(2,2,'selected_window')
halves={}
for mode,n in [(1,3),(2,2)]:
 halves[str(mode)]={}
 for label,sl in [('early',slice(0,10)),('late',slice(10,20))]:
  for rows in all_data[str(mode)].values():
   for row in rows:
    row[label]={k:float(np.mean([r[k] for r in row['blocks'][sl]])) for k in KEYS}
  halves[str(mode)][label]=factorial(mode,n,label)

summary={
 'route':{k:{'total':route[k]['total'],'shapley':route[k]['shapley'],
            'individual_off_vs_full':route[k]['individual_off_vs_full']} for k in KEYS},
 'sediment':{k:{'total':sed[k]['total'],'shapley':sed[k]['shapley'],
               'individual_off_vs_full':sed[k]['individual_off_vs_full']} for k in KEYS},
 'route_eta_band_interactions':route['eta_band']['factorial_terms'],
 'sediment_eta_band_interactions':sed['eta_band']['factorial_terms'],
 'selected_window_route_eta_point':selected_route['eta_point'],
 'selected_window_sediment_eta_point':selected_sed['eta_point'],
 'source_validation':validation,
 'mean_full_Bcal':[all_data['2']['S3'][s]['mean']['Bcal_potential_mean'] for s in range(10)],
 'balanced_constant_Bcal':0.0009,
 'interpretation':[
  'Route contributions allocate the c24-on/off spectral-power contrast with c16 and c17 dynamic, not the complete 10VCC/seven-variable difference.',
  'Sediment contributions allocate state-dependent feedback versus balanced constant removal, not the removal of the mean sediment sink.',
  'Shapley values distribute nonlinear interaction terms by a defined convention; they are not unique physical energy fractions.',
  'Intervals are exploratory, pointwise, paired initial-condition bootstrap; adjacent windows are not independent samples.']}
result={'configuration':cfg,'completion':completion,'validation':validation,'data':all_data,'spectra':spectra,
 'route':route,'sediment':sed,'selected_route':selected_route,'selected_sediment':selected_sed,'early_late':halves}
(B/'isolation_results.json').write_text(json.dumps(result,indent=2))
(B/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({g:{k:{'total':summary[g][k]['total']['mean'],
 'contributions':{i:v['mean'] for i,v in summary[g][k]['shapley'].items()}} for k in KEYS} for g in ['route','sediment']},indent=2),flush=True)

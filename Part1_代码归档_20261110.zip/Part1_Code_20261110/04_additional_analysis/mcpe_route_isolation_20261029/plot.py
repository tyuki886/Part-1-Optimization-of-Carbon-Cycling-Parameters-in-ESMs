from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
B=Path(__file__).resolve().parent
r=json.loads((B/'isolation_results.json').read_text())
font_manager.fontManager.addfont(str(B/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9.5,
 'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,
 'legend.fontsize':8,'axes.linewidth':.75,'path.simplify':False})
blue='#24578D';red='#C6324B';gray='#777777';gold='#B77A22'
manifest={'font':'Times New Roman; STIX math','dpi':600,'files':[],
 'input':'isolation_results.json','intervals':'Pointwise 95% paired initial-condition bootstrap, 19999 resamples; 10 ICs each averaging 20 windows',
 'route_labels':{'A':'TL -> atmosphere: c11,c14,c13','O':'TL -> w: ocean-side c15','C':'TL -> Catm: c20,c21'},
 'sediment_labels':{'N':'State-dependent Bcal in Cocn equation','K':'State-dependent 2 Bcal in ALK equation'},
 'allocation':'Factorial interaction allocation with Shapley convention, not a unique physical-energy partition',
 'no_manuscripts_modified':True}
def clean(ax):
 ax.axhline(0,c='#333333',lw=.75,zorder=1)
 ax.grid(axis='y',color='#eeeeee',lw=.55,zorder=0)
 ax.set_axisbelow(True)
def horizontal(ax,rows,labels,colors=None):
 y=np.arange(len(rows));v=np.array([z['mean'] for z in rows]);ci=np.array([z['ci95'] for z in rows])
 ax.barh(y,v,color=colors if colors is not None else red,height=.62,zorder=2)
 ax.errorbar(v,y,xerr=[v-ci[:,0],ci[:,1]-v],fmt='none',c='#222222',capsize=2,lw=.8,zorder=3)
 ax.set_yticks(y,labels);ax.invert_yaxis();ax.axvline(0,c='#333333',lw=.75)
 ax.grid(axis='x',color='#eeeeee',lw=.55);ax.set_axisbelow(True)
 ax.set_xlabel('Power change / reference power (%)')
 lo,hi=ax.get_xlim();pad=(hi-lo)*.15;ax.set_xlim(lo-pad*.4,hi+pad)
 for yy,xx in zip(y,v):
  # Exact estimates are readable independent of color and marker position.
  ax.text(hi+pad*.85,yy,f'{xx:+.2f}',ha='right',va='center',fontsize=7.5)
def allocated(ax,part,names):
 x=np.arange(len(names)+1)
 for shift,key,c,marker,label in [(-.12,'w_band',blue,'o',r'$w$: 0.05–0.15 year$^{-1}$'),(.12,'eta_band',red,'s',r'$\eta$: 0.5–1.5 decade$^{-1}$')]:
  rows=[part[key]['shapley'][str(i)] for i in range(len(names))]+[part[key]['total']]
  v=np.array([z['mean'] for z in rows]);ci=np.array([z['ci95'] for z in rows])
  ax.errorbar(x+shift,v,yerr=[v-ci[:,0],ci[:,1]-v],fmt=marker,c=c,ms=4,capsize=3,lw=.9,label=label,zorder=3)
 ax.set_xticks(x,names+['Total']);ax.set_ylabel('Allocated change / reference power (%)')
 clean(ax);ax.legend(frameon=False,loc='best',fontsize=7.5)
 lo,hi=ax.get_ylim();ax.set_ylim(lo-(hi-lo)*.05,hi+(hi-lo)*.28)
def save(fig,name,panels):
 fig.savefig(B/(name+'.png'),dpi=600,bbox_inches='tight',pad_inches=.07)
 fig.savefig(B/(name+'_preview.png'),dpi=160,bbox_inches='tight',pad_inches=.07)
 manifest['files'].append({'name':name+'.png','sha256':hashlib.sha256((B/(name+'.png')).read_bytes()).hexdigest(),'panels':panels})
 plt.close(fig)

fig,axs=plt.subplots(2,2,figsize=(8.8,6.8));axs=axs.ravel()
route=r['route']
labels=['None','A','O','A + O','C','A + C','O + C','A + O + C']
horizontal(axs[0],[route['eta_band']['config_effects'][f'R{i}'] for i in range(8)],labels)
axs[0].set_title(r'(a) $\eta$ band: active $T_L$ paths',pad=6)
allocated(axs[1],route,['Atmos. (A)','Ocean (O)','Carbon (C)'])
axs[1].set_title('(b) Allocation of the band-power contrast',pad=6)
terms=route['eta_band']['factorial_terms']
order=[1,2,4,3,5,6,7]
horizontal(axs[2],[terms[str(i)] for i in order],['A','O','C','A × O','A × C','O × C','A × O × C'],
 [blue,blue,blue,gray,gray,gray,gray])
axs[2].set_title(r'(c) $\eta$ band: main and interaction terms',pad=6)
x=np.arange(4)
sel=r['selected_route']['eta_point'];long=route['eta_point']
v=[sel['shapley'][str(i)]['by_initial_condition'][0] for i in range(3)]+[sel['total']['by_initial_condition'][0]]
axs[3].plot(x-.1,v,'s',c=gray,ms=4,label='Selected window, initial condition 0')
rows=[long['shapley'][str(i)] for i in range(3)]+[long['total']]
means=np.array([z['mean'] for z in rows]);ci=np.array([z['ci95'] for z in rows])
axs[3].errorbar(x+.1,means,yerr=[means-ci[:,0],ci[:,1]-means],fmt='o',c=red,ms=4,capsize=3,lw=.9,label='Long record, 10 initial conditions')
axs[3].set_xticks(x,['Atmos. (A)','Ocean (O)','Carbon (C)','Total'])
axs[3].set_ylabel('Allocated point-power change (%)')
axs[3].set_title(r'(d) $\eta$ at 17.86 years',pad=6)
clean(axs[3]);axs[3].legend(frameon=False,fontsize=7,loc='best')
lo,hi=axs[3].get_ylim();axs[3].set_ylim(lo,hi+(hi-lo)*.27)
fig.suptitle('Isolating the land-feedback paths to ocean variability',fontsize=12.5,y=.98)
fig.subplots_adjust(left=.12,right=.985,bottom=.08,top=.88,wspace=.43,hspace=.46)
save(fig,'TL_route_isolation',{
 'a':'Eta band power in all eight TL recipient-edge combinations. A=atmosphere, O=ocean exchange, C=carbon return. Reference is c24 off with c16/c17 dynamic; all disabled inputs use its simultaneous RK4-stage TL.',
 'b':'Shapley allocation of the full c24 on/off band-power contrast to the three recipient paths. Total equals the sum of allocated effects within each initial condition.',
 'c':'Mobius factorial main and interaction terms for eta band power; their sum is the total c24 contrast. Each term has the same reference-power denominator.',
 'd':'Same allocation at the fixed 17.86-year eta spectral ordinate, contrasting the selected 10000–20000 TU window, initial condition 0, with the long-record mean and pointwise bootstrap intervals.'})

fig,axs=plt.subplots(2,2,figsize=(8.8,6.8));axs=axs.ravel()
sed=r['sediment']
horizontal(axs[0],[sed['eta_band']['config_effects'][f'S{i}'] for i in range(4)],['Balanced constant','Cocn only (N)','ALK only (K)','Both (N + K)'])
axs[0].set_title(r'(a) $\eta$ band: dynamic sediment feedbacks',pad=6)
allocated(axs[1],sed,['Cocn (N)','ALK (K)'])
axs[1].set_title('(b) Allocation of the band-power contrast',pad=6)
for label,desc,c,ls in [('S0','Balanced constant removal',gray,'--'),('S3','Full state-dependent removal',red,'-')]:
 sp=r['spectra']['2'][label];f=np.array(sp['f'])*100;p=np.array(sp['eta']);keep=(f>=.5)&(f<=1.5)
 axs[2].plot(f[keep],p[keep],c=c,ls=ls,lw=1.1,label=desc)
axs[2].axvline(.56,c='#999999',ls=':',lw=.8)
axs[2].set_xlabel('Frequency (Decade$^{-1}$)');axs[2].set_ylabel('Spectral power')
axs[2].set_xlim(.5,1.5);axs[2].set_ylim(bottom=0);axs[2].grid(color='#eeeeee',lw=.55)
axs[2].set_title(r'(c) Long-record $\eta$ spectra',pad=6);axs[2].legend(frameon=False,fontsize=7,loc='best')
rows=[sed['eta_band']['factorial_terms'][k] for k in ['1','2','3']]+[sed['eta_band']['total']]
horizontal(axs[3],rows,['Cocn main (N)','ALK main (K)','Interaction (N × K)','Total'],[blue,blue,gray,red])
axs[3].set_title(r'(d) $\eta$ band: main and interaction terms',pad=6)
fig.suptitle('Isolating state-dependent sediment removal feedbacks',fontsize=12.5,y=.98)
fig.subplots_adjust(left=.19,right=.985,bottom=.08,top=.88,wspace=.57,hspace=.46)
save(fig,'Sediment_isolation',{
 'a':'Eta band power for constant-balanced or state-dependent removal at the Cocn and ALK recipient equations. Blocked flux is c25/2=0.0009, not zero; all branches share the same full-model spinup checkpoint.',
 'b':'Shapley allocation of dynamic-minus-balanced-constant band power to Cocn and ALK removal feedbacks; not an attribution of the mean sediment sink.',
 'c':'Mean of seedwise mean window eta spectra, with full state dependence or balanced constant removal in both equations. The vertical guide is the fixed 17.86-year ordinate, 0.56 decade^-1.',
 'd':'Factorial main Cocn, main ALK, and interaction contributions to eta band power, normalized by each initial condition constant-removal reference power.'})
(B/'figure_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('FIGURES_COMPLETE',flush=True)

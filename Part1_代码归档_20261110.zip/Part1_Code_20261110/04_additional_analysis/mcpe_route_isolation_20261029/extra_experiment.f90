program finer_atmospheric_routes
 use extra_module
 use,intrinsic::ieee_arithmetic
 implicit none
 integer,parameter::masks(8)=[1,2,5,6,9,10,13,14]
 integer(kind=8)::i,spin=1000000_8,total=20000000_8
 integer::seed,j,units(9)
 real(dp)::x(18,8),ref(18),stages(18,4),row(9),a(18),b(18),full_error
 character(len=64)::arg,name
 call get_command_argument(1,arg);read(arg,*)seed
 ! Zero-intervention identity for the finer implementation.
 a=0.0_dp;a(2)=1.0_dp;b=a;stages=0.0_dp;full_error=0.0_dp
 do i=1,300000_8
  call adv_true_state(a,i,10)
  call advance_route4(b,i,stages,15)
  full_error=max(full_error,maxval(abs(a-b)))
 enddo
 if(full_error>1.0e-12_dp)error stop 'finer source identity failed'
 x=0.0_dp;x(2,:)=1.0_dp+.001_dp*seed;ref=x(:,1)
 do i=1,spin
  call step(i)
 enddo
 do j=1,8
  write(name,'(A,I0,A)')'T',masks(j),'.bin'
  open(newunit=units(j),file=trim(name),access='stream',form='unformatted',status='new')
 enddo
 open(newunit=units(9),file='reference.bin',access='stream',form='unformatted',status='new')
 call samples()
 do i=1,total
  call step(i)
  if(mod(i,100_8)==0)call samples()
 enddo
 do j=1,9
  close(units(j))
 enddo
 open(unit=77,file='validation.txt',status='new');write(77,*)full_error;close(77)
 print *,'EXTRA_DONE',seed,full_error
contains
 subroutine step(it)
  integer(kind=8),intent(in)::it
  integer::m
  call advance_off(ref,it,stages)
  do m=1,8
   call advance_route4(x(:,m),it,stages,masks(m))
  enddo
 end subroutine
 subroutine samples()
  integer::m
  real(dp)::s(18)
  do m=1,9
   if(m<=8)then;s=x(:,m);else;s=ref;endif
   if(.not.all(ieee_is_finite(s)))error stop 'nonfinite finer trajectory'
   if(maxval(abs(s(1:7)))>1000.0_dp.or.maxval(abs(s(8:10)))>10000.0_dp)error stop 'finer state bound'
   row=[s(1),s(2),s(4),s(5),s(7),s(8),s(9),s(10),c26*rrain*s(9)*max(s(10)-c27*s(9)+c28,0.0_dp)]
   write(units(m))row
  enddo
 end subroutine
end program

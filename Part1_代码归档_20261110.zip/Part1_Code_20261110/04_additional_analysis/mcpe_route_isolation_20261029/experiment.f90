program isolate_paths
 use path_module
 use,intrinsic::ieee_arithmetic
 implicit none
 integer(kind=8)::i,spin=1000000_8,total=20000000_8
 integer::mode,seed,j,ncase,units(9),mask,k
 integer,parameter::nonland(10)=[1,2,3,4,5,6,8,9,10,15]
 real(dp)::xs(18,9),ref(18),stages(18,4),row(9),collapse=0.0_dp,basealk
 character(len=64)::arg,name
 call get_command_argument(1,arg);read(arg,*)seed
 call get_command_argument(2,arg);read(arg,*)mode
 if(command_argument_count()>=3)then
  call get_command_argument(3,arg);read(arg,*)total
 endif
 xs=0.0_dp;xs(2,:)=1.0_dp+0.001_dp*seed
 if(mode==1)then
  ncase=9;ref=xs(:,1)
  do i=1,spin
   call step_route(i)
  enddo
  do j=1,ncase
   if(j==1)then;name='reference.bin'
   else;write(name,'(A,I1,A)')'R',j-2,'.bin';endif
   open(newunit=units(j),file=trim(name),access='stream',form='unformatted',status='new')
  enddo
 else
  ncase=4
  do i=1,spin
   call adv_true_state(xs(:,4),i,10)
  enddo
  do j=1,3
   xs(:,j)=xs(:,4)
  enddo
  basealk=xs(10,4)
  do j=1,ncase
   write(name,'(A,I1,A)')'S',j-1,'.bin'
   open(newunit=units(j),file=trim(name),access='stream',form='unformatted',status='new')
  enddo
 endif
 call write_samples()
 do i=1,total
  if(mode==1)then
   call step_route(i)
  else
   do j=1,3
    call advance_sediment(xs(:,j),i,j-1)
   enddo
   call adv_true_state(xs(:,4),i,10)
   if(xs(10,1)/=basealk.or.xs(10,2)/=basealk) error stop 'balanced ALK identity failed'
  endif
  if(mod(i,100_8)==0)call write_samples()
 enddo
 do j=1,ncase
  close(units(j))
 enddo
 open(newunit=k,file='validation.txt',status='new')
 write(k,*)collapse
 close(k)
 print *,'DONE',seed,mode,total,collapse
contains
 subroutine step_route(it)
  integer(kind=8),intent(in)::it
  integer::m
  call advance_off(ref,it,stages)
  xs(:,1)=ref
  do m=0,6
   call advance_route(xs(:,m+2),it,stages,m)
  enddo
  call adv_true_state(xs(:,9),it,10)
  collapse=max(collapse,maxval(abs(xs(nonland,2)-ref(nonland))))
  if(collapse>1.0e-12_dp)error stop 'all blocked routes fail c24-off identity'
 end subroutine
 subroutine write_samples()
  integer::m
  do m=1,ncase
   if(.not.all(ieee_is_finite(xs(:,m))))error stop 'nonfinite state'
   if(maxval(abs(xs(1:7,m)))>1000.0_dp.or.maxval(abs(xs(8:10,m)))>10000.0_dp)error stop 'state exceeds diagnostic bound'
   row=[xs(1,m),xs(2,m),xs(4,m),xs(5,m),xs(7,m),xs(8,m),xs(9,m),xs(10,m), &
    c26*rrain*xs(9,m)*max(xs(10,m)-c27*xs(9,m)+c28,0.0_dp)]
   write(units(m))row
  enddo
 end subroutine
end program

module path_module
 use RKmethod
 implicit none
contains
 function off_rhs(s,it) result(ds)
  real(dp),intent(in)::s(18)
  integer(kind=8),intent(in)::it
  real(dp)::ds(10),pi
  pi=3.141592653589793_dp
  ds=derivs(s,it,10)
  ds(7)=(c12*s(2)-old*s(7)-c15*s(1)*(s(7)-s(4)))
  ds(7)=(ds(7)+slm+sls*cos(2.0*pi*it*0.01/spd))/olm
 end function

 function route_rhs(s,it,ref,mask) result(ds)
  real(dp),intent(in)::s(18),ref(18)
  integer(kind=8),intent(in)::it
  integer,intent(in)::mask
  real(dp)::ds(10),land,pi,pco
  pi=3.141592653589793_dp
  ds=derivs(s,it,10)
  ! bit 0: TL -> x1 and x2; retain all other inputs from this branch.
  if(.not.btest(mask,0))then
   land=ref(7)
   ds(1)=a1*(s(2)-s(1))-(lambda+c11*land)+c14*(land-s(4))
   ds(2)=-s(1)*s(3)+(1.0+c1*s(4))*a2*s(1)-s(2)+c13*a2*land*s(1)
   ds(2)=ds(2)+c16*s(8)
  endif
  ! bit 1: TL -> w, the ocean-side c15 exchange term only.
  if(.not.btest(mask,1))then
   land=ref(7)
   ds(4)=(c2*s(2)+c3*s(5)+c4*s(4)*s(5)-od*s(4)-c7*s(15)+c15*s(1)*(land-s(4)))
   ds(4)=(ds(4)+sm*(1.0+c17*s(8))+ss*cos(2.0*pi*it*0.01/spd))/om
  endif
  ! bit 2: TL -> Catm through the land sink and convection terms.
  if(.not.btest(mask,2))then
   land=ref(7);pco=max(c29*s(9)-c30*s(10),0.0_dp)
   ds(8)=E_rate-c18*(1.0-c19*s(4))*(s(8)-pco)-c20*s(8)*land-c21*s(1)*(land-s(4))
  endif
 end function

 function sediment_rhs(s,it,mask) result(ds)
  real(dp),intent(in)::s(18)
  integer(kind=8),intent(in)::it
  integer,intent(in)::mask
  real(dp)::ds(10),pco,balanced_sink
  ds=derivs(s,it,10)
  pco=max(c29*s(9)-c30*s(10),0.0_dp)
  balanced_sink=c25/2.0_dp
  ! Keep the mean balancing sink; switch only the state-dependent part.
  if(.not.btest(mask,0)) ds(9)=c18*(1.0-c19*s(4))*(s(8)-pco)-c22*(1.0-c23*s(4))*s(5)-balanced_sink
  if(.not.btest(mask,1)) ds(10)=c25-2.0_dp*balanced_sink
 end function

 subroutine ice_update(x)
  real(dp),intent(inout)::x(18)
  real(dp)::h_val
  h_val=c8*x(2)**2+c9*x(4)**2+c10*x(15)**2
  if(h_val>50.0_dp)then
   x(6)=0.0_dp
  elseif(h_val<10.0_dp)then
   x(6)=1.0_dp
  else
   x(6)=0.5_dp*(exp(-(h_val-10.0_dp)/80.0_dp)+exp(-1.0_dp/max(50.0_dp-h_val,1.0e-10_dp)))
  endif
  x(15)=x(6)
 end subroutine

 subroutine advance_off(x,it,stages)
  real(dp),intent(inout)::x(18)
  integer(kind=8),intent(in)::it
  real(dp),intent(out)::stages(18,4)
  real(dp)::dt=0.01_dp,k1(10),k2(10),k3(10),k4(10),tmp(18)
  stages(:,1)=x;k1=off_rhs(x,it)
  tmp=x;tmp(1:10)=x(1:10)+0.5*dt*k1;stages(:,2)=tmp;k2=off_rhs(tmp,it)
  tmp=x;tmp(1:10)=x(1:10)+0.5*dt*k2;stages(:,3)=tmp;k3=off_rhs(tmp,it)
  tmp=x;tmp(1:10)=x(1:10)+dt*k3;stages(:,4)=tmp;k4=off_rhs(tmp,it)
  x(1:10)=x(1:10)+(dt/6.0_dp)*(k1+2.0_dp*k2+2.0_dp*k3+k4)
  call ice_update(x)
 end subroutine

 subroutine advance_route(x,it,stages,mask)
  real(dp),intent(inout)::x(18)
  real(dp),intent(in)::stages(18,4)
  integer(kind=8),intent(in)::it
  integer,intent(in)::mask
  real(dp)::dt=0.01_dp,k1(10),k2(10),k3(10),k4(10),tmp(18)
  k1=route_rhs(x,it,stages(:,1),mask)
  tmp=x;tmp(1:10)=x(1:10)+0.5*dt*k1;k2=route_rhs(tmp,it,stages(:,2),mask)
  tmp=x;tmp(1:10)=x(1:10)+0.5*dt*k2;k3=route_rhs(tmp,it,stages(:,3),mask)
  tmp=x;tmp(1:10)=x(1:10)+dt*k3;k4=route_rhs(tmp,it,stages(:,4),mask)
  x(1:10)=x(1:10)+(dt/6.0_dp)*(k1+2.0_dp*k2+2.0_dp*k3+k4)
  call ice_update(x)
 end subroutine

 subroutine advance_sediment(x,it,mask)
  real(dp),intent(inout)::x(18)
  integer(kind=8),intent(in)::it
  integer,intent(in)::mask
  real(dp)::dt=0.01_dp,k1(10),k2(10),k3(10),k4(10),tmp(18)
  k1=sediment_rhs(x,it,mask)
  tmp=x;tmp(1:10)=x(1:10)+0.5*dt*k1;k2=sediment_rhs(tmp,it,mask)
  tmp=x;tmp(1:10)=x(1:10)+0.5*dt*k2;k3=sediment_rhs(tmp,it,mask)
  tmp=x;tmp(1:10)=x(1:10)+dt*k3;k4=sediment_rhs(tmp,it,mask)
  x(1:10)=x(1:10)+(dt/6.0_dp)*(k1+2.0_dp*k2+2.0_dp*k3+k4)
  call ice_update(x)
 end subroutine
end module

from pathlib import Path
import json,math
import numpy as np
from scipy import signal
B=Path(__file__).resolve().parent;P=B.parent
base=json.loads((P/'isolation_results.json').read_text())
done=json.loads((B/'completion.json').read_text());assert len(done['groups'])==10
keys=['w_band','eta_band','w_point','eta_point']
welch=base['configuration']['welch']
rng=np.random.default_rng(20261029);boot=rng.integers(0,10,size=(19999,10))
def stats(v):
 v=np.array(v,float)
 return {'mean':float(v.mean()),'ci95':np.percentile(v[boot].mean(axis=1),[2.5,97.5]).tolist(),
  'positive_count':int((v>0).sum()),'negative_count':int((v<0).sum()),'by_initial_condition':v.tolist()}
def metric(a):
 r={}
 for name,col in [('w',2),('eta',3)]:
  f,p=signal.welch(a[:,col]-np.mean(a[:,col]),**welch)
  k=int(np.argmin(abs(f-.0056)));band=(f*100>=.5)&(f*100<=1.5)
  r[name+'_point']=float(p[k]);r[name+'_band']=float(p[band].sum()/1.5)
 return r
data={}
for m in range(8):
 new=(3 if m&1 else 0)+(4 if m&2 else 0)+(8 if m&4 else 0)
 data[str(new)]=base['data']['1'][f'R{m}']
for m in [1,2,5,6,9,10,13,14]:
 rows=[]
 for seed in range(10):
  a=np.memmap(B/'data'/f'seed{seed}'/f'T{m}.bin',dtype='<f8',mode='r',shape=(200001,9))
  blocks=[metric(a[j*10000+1:(j+1)*10000+1]) for j in range(20)]
  rows.append({'blocks':blocks,'mean':{k:float(np.mean([b[k] for b in blocks])) for k in keys},
   'early':{k:float(np.mean([b[k] for b in blocks[:10]])) for k in keys},
   'late':{k:float(np.mean([b[k] for b in blocks[10:]])) for k in keys},'selected_window':metric(a[10000:20001])})
 data[str(m)]=rows
assert len(data)==16
result={}
for period in ['mean','selected_window','early','late']:
 result[period]={}
 for key in keys:
  y=np.array([[data[str(m)][s][period][key] for s in range(10)] for m in range(16)])
  denom=y[0];alloc=[]
  # Preserve the original atmospheric coalition; split its allocated contribution
  # equally over the two internal orderings, for each macro-coalition ordering.
  for i,other in [(0,1),(1,0)]:
   v=np.zeros(10)
   for background in [0,4,8,12]:
    count=background.bit_count();weight=math.factorial(count)*math.factorial(2-count)/6
    v+=weight*.5*((y[background|(1<<i)]-y[background])+(y[background|3]-y[background|(1<<other)]))
   alloc.append(100*v/denom)
  macro=base['route'] if period=='mean' else base['selected_route'] if period=='selected_window' else base['early_late']['1'][period]
  atm=np.array(macro[key]['shapley']['0']['by_initial_condition'])
  assert np.allclose(alloc[0]+alloc[1],atm,rtol=1e-10,atol=1e-10)
  # Independent check via explicit enumeration of 3! macro orders and 2! internal orders.
  import itertools
  independent=np.zeros((2,10))
  for order in itertools.permutations([3,4,8]):
   for suborder in [(1,2),(2,1)]:
    mask=0
    for group in order:
     if group==3:
      for edge in suborder:
       after=mask|edge;independent[0 if edge==1 else 1]+=100*(y[after]-y[mask])/denom/12;mask=after
     else:mask|=group
  assert np.allclose(np.array(alloc),independent,rtol=1e-10,atol=1e-10)
  result[period][key]={'x1_entry':stats(alloc[0]),'x2_entry':stats(alloc[1]),
   'atmosphere_total':macro[key]['shapley']['0'],
   'ocean_entry':macro[key]['shapley']['1'],'carbon_entry':macro[key]['shapley']['2'],'total':macro[key]['total']}
summary={'definition':'Hierarchical Owen allocation preserving the three original macro coalitions A/O/C. A splits into TL->x1 through c14-c11 and TL->x2 through c13*kappa*x1; interactions are shared over macro and internal orderings.',
 'units':'Percentage of each initial-condition c24-off reference spectral power, then averaged across ten initial conditions.',
 'results':result,'completion':done}
(B/'atmosphere_split.json').write_text(json.dumps({'summary':summary,'data':data},indent=2))
(B/'atmosphere_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:{p:{'mean':v['mean'],'ci95':v['ci95']} for p,v in z.items()} for k,z in result['mean'].items()},indent=2),flush=True)

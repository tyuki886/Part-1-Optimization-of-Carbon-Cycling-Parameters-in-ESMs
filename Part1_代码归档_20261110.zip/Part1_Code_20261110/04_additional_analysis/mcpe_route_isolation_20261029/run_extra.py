from pathlib import Path
import subprocess,concurrent.futures,time,hashlib,json
import numpy as np
B=Path(__file__).resolve().parent
P=B.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(B/'build').mkdir();(B/'data').mkdir()
subprocess.run(['gfortran','-O3','-ffree-line-length-none',str(P/'RKmethod_reference.f90'),str(P/'path_module.f90'),str(B/'extra_module.f90'),str(B/'extra_experiment.f90'),'-o','experiment'],cwd=B/'build',check=True)
def run(seed):
 d=B/'data'/f'seed{seed}';d.mkdir();t=time.time()
 with (d/'run.log').open('w') as f:subprocess.run([str(B/'build/experiment'),str(seed)],cwd=d,check=True,stdout=f,stderr=subprocess.STDOUT)
 assert float((d/'validation.txt').read_text())<1e-12
 receipts={}
 for p in d.glob('*.bin'):
  assert p.stat().st_size==200001*9*8
  a=np.memmap(p,dtype='<f8',mode='r',shape=(200001,9));assert np.isfinite(a).all()
  receipts[p.name]={'sha256':sha(p),'size':p.stat().st_size}
 assert len(receipts)==9
 a=np.memmap(d/'reference.bin',dtype='<f8',mode='r',shape=(200001,9))
 r=np.memmap(P/'data'/f'mode1_seed{seed}'/'reference.bin',dtype='<f8',mode='r',shape=(200001,9))
 assert np.array_equal(a,r)
 row={'seed':seed,'files':receipts,'seconds':time.time()-t,'reference_identity':True}
 (d/'receipt.json').write_text(json.dumps(row,indent=2));print('EXTRA_DONE',seed,round(row['seconds'],1),flush=True)
 return row
t=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,range(10)))
(B/'completion.json').write_text(json.dumps({'groups':rows,'new_gate_trajectories':80,'extra_reference_trajectories':10,'seconds':time.time()-t,
 'extra_module_sha256':sha(B/'extra_module.f90'),'extra_experiment_sha256':sha(B/'extra_experiment.f90')},indent=2))
print('EXTRA_COMPLETE',flush=True)

module extra_module
 use path_module
 implicit none
contains
 function route4_rhs(s,it,ref,mask) result(ds)
  real(dp),intent(in)::s(18),ref(18)
  integer(kind=8),intent(in)::it
  integer,intent(in)::mask
  real(dp)::ds(10),land
  integer::m3
  m3=1
  if(btest(mask,2))m3=m3+2
  if(btest(mask,3))m3=m3+4
  ds=route_rhs(s,it,ref,m3)
  land=ref(7)
  if(.not.btest(mask,0))ds(1)=a1*(s(2)-s(1))-(lambda+c11*land)+c14*(land-s(4))
  if(.not.btest(mask,1))then
   ds(2)=-s(1)*s(3)+(1.0+c1*s(4))*a2*s(1)-s(2)+c13*a2*land*s(1)
   ds(2)=ds(2)+c16*s(8)
  endif
 end function
 subroutine advance_route4(x,it,stages,mask)
  real(dp),intent(inout)::x(18)
  real(dp),intent(in)::stages(18,4)
  integer(kind=8),intent(in)::it
  integer,intent(in)::mask
  real(dp)::dt=0.01_dp,k1(10),k2(10),k3(10),k4(10),tmp(18)
  k1=route4_rhs(x,it,stages(:,1),mask)
  tmp=x;tmp(1:10)=x(1:10)+0.5*dt*k1;k2=route4_rhs(tmp,it,stages(:,2),mask)
  tmp=x;tmp(1:10)=x(1:10)+0.5*dt*k2;k3=route4_rhs(tmp,it,stages(:,3),mask)
  tmp=x;tmp(1:10)=x(1:10)+dt*k3;k4=route4_rhs(tmp,it,stages(:,4),mask)
  x(1:10)=x(1:10)+(dt/6.0_dp)*(k1+2.0_dp*k2+2.0_dp*k3+k4)
  call ice_update(x)
 end subroutine
end module

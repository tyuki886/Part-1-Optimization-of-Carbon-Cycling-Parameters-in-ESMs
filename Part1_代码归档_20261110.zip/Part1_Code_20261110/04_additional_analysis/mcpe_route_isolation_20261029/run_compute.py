from pathlib import Path
import concurrent.futures,subprocess,hashlib,json,time
import numpy as np
B=Path(__file__).resolve().parent
OLD=Path('/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/w_feedback_20261029')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(B/'RKmethod_reference.f90').read_text()
assert 'c28=1.0_dp' in source
(B/'build').mkdir();(B/'data').mkdir()
build=B/'build'
(build/'RKmethod.f90').write_text(source)
off=source.replace('slm*(1.0+c24*s(8))','slm').replace('module RKmethod','module Off_reference',1)
(build/'Off_reference.f90').write_text(off)
args=['gfortran','-O3','-ffree-line-length-none']
subprocess.run(args+['RKmethod.f90','Off_reference.f90',str(B/'path_module.f90'),str(B/'check.f90'),'-o','identity_check'],cwd=build,check=True)
subprocess.run([str(build/'identity_check')],cwd=build,check=True)
subprocess.run(args+['RKmethod.f90',str(B/'path_module.f90'),str(B/'experiment.f90'),'-o','experiment'],cwd=build,check=True)
audit=json.loads((build/'validation.json').read_text())
assert max(audit.values())<1e-12
print('VALIDATION_PASS',audit,flush=True)

def run(item):
 seed,mode=item;d=B/'data'/f'mode{mode}_seed{seed}';d.mkdir()
 start=time.time()
 with (d/'run.log').open('w') as f:
  subprocess.run([str(build/'experiment'),str(seed),str(mode)],cwd=d,check=True,stdout=f,stderr=subprocess.STDOUT)
 files={}
 expected=9 if mode==1 else 4
 for p in sorted(d.glob('*.bin')):
  assert p.stat().st_size==200001*9*8
  a=np.memmap(p,dtype='<f8',mode='r',shape=(200001,9));assert np.isfinite(a).all()
  files[p.name]={'sha256':sha(p),'size':p.stat().st_size,'min':np.min(a,axis=0).tolist(),'max':np.max(a,axis=0).tolist()}
 assert len(files)==expected
 assert float((d/'validation.txt').read_text())<1e-12
 # Verify full-model branch against completed same-source archive for all ten ICs.
 f=d/('R7.bin' if mode==1 else 'S3.bin')
 a=np.memmap(f,dtype='<f8',mode='r',shape=(200001,9))
 old=np.memmap(OLD/'data'/f'M7_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))
 reproduction=float(np.max(np.abs(a[:,:6]-old[:,:6])))
 assert reproduction<1e-12,('full baseline differs from archived same-source run',seed,mode,reproduction)
 if mode==1:
  oldref=np.memmap(OLD/'data'/f'M3_seed{seed}'/'states.bin',dtype='<f8',mode='r',shape=(200001,7))
  ref=np.memmap(d/'reference.bin',dtype='<f8',mode='r',shape=(200001,9))
  off_reproduction=float(np.max(np.abs(ref[:,:6]-oldref[:,:6])))
  assert off_reproduction<1e-12,('c24-off reference differs',seed,off_reproduction)
 else:off_reproduction=None
 row={'seed':seed,'mode':mode,'seconds':time.time()-start,'full_baseline_max_abs':reproduction,
      'off_baseline_max_abs':off_reproduction,'files':files}
 (d/'receipt.json').write_text(json.dumps(row,indent=2))
 print('RUN_DONE',seed,mode,round(row['seconds'],1),flush=True)
 return row

start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 receipts=list(pool.map(run,[(s,m) for s in range(10) for m in (1,2)]))
result={'validation':audit,'groups':receipts,'seconds':time.time()-start,'initial_conditions':10,'trajectory_count':130,
 'source_sha256':sha(B/'RKmethod_reference.f90'),'path_module_sha256':sha(B/'path_module.f90'),
 'experiment_sha256':sha(B/'experiment.f90'),'binary_sha256':sha(build/'experiment')}
(B/'completion.json').write_text(json.dumps(result,indent=2))
print('COMPUTE_COMPLETE',round(result['seconds'],1),flush=True)

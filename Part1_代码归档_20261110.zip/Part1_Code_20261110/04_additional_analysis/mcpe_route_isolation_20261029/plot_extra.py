from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager
B=Path(__file__).resolve().parent
r=json.loads((B/'atmosphere_summary.json').read_text())
font_manager.fontManager.addfont(str(B.parent/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':9.5,
 'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'axes.linewidth':.75,'path.simplify':False})
blue='#24578D';red='#C6324B'
fig,axs=plt.subplots(1,2,figsize=(8.8,3.8))
labels=[r'Atmos. $x_1$',r'Atmos. $x_2$','Ocean','Carbon','Total']
fields=['x1_entry','x2_entry','ocean_entry','carbon_entry','total'];x=np.arange(5)
for shift,key,c,marker,label in [(-.1,'w_band',blue,'o',r'$w$ band'),(.1,'eta_band',red,'s',r'$\eta$ band')]:
 rows=[r['results']['mean'][key][f] for f in fields]
 v=np.array([z['mean'] for z in rows]);ci=np.array([z['ci95'] for z in rows])
 axs[0].errorbar(x+shift,v,yerr=[v-ci[:,0],ci[:,1]-v],fmt=marker,c=c,capsize=3,lw=.9,ms=4,label=label)
axs[0].set_xticks(x,labels);axs[0].axhline(0,c='#333333',lw=.75);axs[0].grid(axis='y',color='#eeeeee',lw=.55)
axs[0].set_title('(a) Band-power allocation by recipient',pad=6)
axs[0].set_ylabel('Allocated change / reference power (%)');axs[0].legend(frameon=False,loc='best')
fields2=['x1_entry','x2_entry','atmosphere_total'];labels2=[r'$T_L\to x_1$',r'$T_L\to x_2$','Atmosphere total']
for shift,period,c,marker,label in [(-.1,'early',blue,'o','First ten windows'),(.1,'late',red,'s','Last ten windows')]:
 rows=[r['results'][period]['eta_band'][f] for f in fields2]
 v=np.array([z['mean'] for z in rows]);ci=np.array([z['ci95'] for z in rows])
 axs[1].errorbar(np.arange(3)+shift,v,yerr=[v-ci[:,0],ci[:,1]-v],fmt=marker,c=c,capsize=3,lw=.9,ms=4,label=label)
axs[1].set_xticks(np.arange(3),labels2);axs[1].axhline(0,c='#333333',lw=.75);axs[1].grid(axis='y',color='#eeeeee',lw=.55)
axs[1].set_title(r'(b) $\eta$ band: temporal sensitivity',pad=6)
axs[1].set_ylabel('Allocated change / reference power (%)');axs[1].legend(frameon=False,loc='best')
for ax in axs:
 lo,hi=ax.get_ylim();ax.set_ylim(lo-(hi-lo)*.05,hi+(hi-lo)*.22);ax.set_axisbelow(True)
fig.suptitle('Separating the two atmospheric entries of land feedback',fontsize=12.5,y=.98)
fig.subplots_adjust(left=.09,right=.985,bottom=.15,top=.79,wspace=.32)
for suffix,dpi in [('',600),('_preview',160)]:fig.savefig(B/('Atmosphere_route_split'+suffix+'.png'),dpi=dpi,bbox_inches='tight',pad_inches=.07)
manifest={'filename':'Atmosphere_route_split.png','sha256':hashlib.sha256((B/'Atmosphere_route_split.png').read_bytes()).hexdigest(),
 'font':'Times New Roman; STIX math','dpi':600,'allocation':'Hierarchical Owen values; the sum of atmospheric x1 and x2 entries equals the original atmospheric macro-coalition Shapley value within each initial condition.',
 'intervals':'Exploratory pointwise 95% paired initial-condition bootstrap, 10 ICs; early/late each use ten consecutive windows within each IC.',
 'x1_entry':'TL enters x1 via (c14-c11) TL','x2_entry':'TL enters x2 via c13*kappa*TL*x1',
 'band':'w: 0.05–0.15 year^-1; eta: 0.5–1.5 decade^-1; same physical band'}
(B/'extra_figure_manifest.json').write_text(json.dumps(manifest,indent=2))
print('EXTRA_FIGURE_COMPLETE',flush=True)

program check_paths
 use path_module
 use Off_reference, only: off_original=>adv_true_state
 implicit none
 integer(kind=8)::i
 real(dp)::a(18),b(18),c(18),d(18),e(18),stages(18,4),err(5),s(18),r(18),f(10),g(10),bal,pco
 integer,parameter::nonland(10)=[1,2,3,4,5,6,8,9,10,15]
 a=0.0_dp;a(2)=1.0_dp;b=a;c=a;d=a;e=a;err=0.0_dp
 do i=1,300000_8
  call advance_off(c,i,stages)
  call off_original(d,i,10)
  call advance_route(b,i,stages,7)
  call advance_sediment(e,i,3)
  call adv_true_state(a,i,10)
  err(1)=max(err(1),maxval(abs(a-b)))
  err(2)=max(err(2),maxval(abs(c-d)))
  err(3)=max(err(3),maxval(abs(a-e)))
 enddo
 a=0.0_dp;a(2)=1.0_dp;b=a
 do i=1,300000_8
  call advance_off(a,i,stages)
  call advance_route(b,i,stages,0)
  err(4)=max(err(4),maxval(abs(a(nonland)-b(nonland))))
 enddo
 ! Compare recipient changes against an independently written delta at one state.
 s=[1.2_dp,2.0_dp,3.0_dp,0.8_dp,0.9_dp,0.3_dp,2.0_dp,5.0_dp,10.0_dp,5.0_dp, &
    0.0_dp,0.0_dp,0.0_dp,0.0_dp,0.4_dp,0.0_dp,0.0_dp,0.0_dp]
 r=s;r(7)=1.7_dp
 f=route_rhs(s,100_8,r,0);g=derivs(s,100_8,10)
 g(1)=g(1)+(c14-c11)*(r(7)-s(7))
 g(2)=g(2)+c13*a2*s(1)*(r(7)-s(7))
 g(4)=g(4)+c15*s(1)*(r(7)-s(7))/om
 g(8)=g(8)-(c20*s(8)+c21*s(1))*(r(7)-s(7))
 err(5)=maxval(abs(f-g))
 if(maxval(err)>1.0e-12_dp)error stop 'source identity failed'
 open(unit=77,file='validation.json',status='new')
 write(77,'(A,ES24.16,A,ES24.16,A,ES24.16,A,ES24.16,A,ES24.16,A)') &
  '{"full_route_max":',err(1),',"off_reference_max":',err(2),',"full_sediment_max":',err(3), &
  ',"blocked_nonland_max":',err(4),',"recipient_delta_max":',err(5),'}'
 close(77)
 print *,'IDENTITIES',err
end program

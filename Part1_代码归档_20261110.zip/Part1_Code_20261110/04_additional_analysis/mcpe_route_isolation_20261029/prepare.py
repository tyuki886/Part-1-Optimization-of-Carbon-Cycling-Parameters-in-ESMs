from pathlib import Path
import shutil,hashlib,json
B=Path(__file__).resolve().parent
P=Path(r'D:\ClaudeFiles\mcpe_w_feedback_20261029')
sources=[]
for name in ['RKmethod_reference.f90','times.ttf']:
 shutil.copy2(P/name,B/name)
 sources.append({'source':str(P/name),'local_copy':name,'sha256':hashlib.sha256((B/name).read_bytes()).hexdigest()})
source=(B/'RKmethod_reference.f90').read_text(encoding='utf-8')
assert 'c28=1.0_dp' in source
cfg={
 'c28':1,'baseline_source':'Exact archived RKmethod_reference.f90 used in w_feedback_20261029',
 'dt_TU':0.01,'sampling_TU':1,'spinup_TU':10000,'postspinup_TU':200000,
 'initial_conditions':[{'seed':s,'initial_x2':1+0.001*s,'other_initial_states':0} for s in range(10)],
 'route_experiment':{
  'reference':'c24 off; c16,c17 remain dynamic; independent reference integrated at every RK4 stage',
  'source':'c24 on for every intervention; all parameters and incoming core terms retained',
  'gate_bit0_A':'TL -> atmospheric x1 (c11,c14) and x2 (c13)',
  'gate_bit1_O':'TL -> w in ocean-side c15 x1(TL-w)',
  'gate_bit2_C':'TL -> Catm in c20 Catm TL and c21 x1(TL-w)',
  'blocked_input':'Replace TL at this recipient with simultaneous c24-off reference TL, at each RK4 stage; do not delete physical terms',
  'masks':list(range(8)),
  'timing':'Each edge setting applies during its own spinup and the full analysis integration',
  'interpretation':'Controlled network edge interventions, not separately energy-conserving alternative models; exact factorial decomposition of the c24-related power contrast'},
 'sediment_experiment':{
  'reference':'Full coupled 10VCC spinup checkpoint; all four branches start identically',
  'gate_bit0_N':'State-dependent Bcal delivered to Cocn equation',
  'gate_bit1_K':'State-dependent 2Bcal delivered to ALK equation',
  'blocked_flux':'Bcal replaced by c25/2 = 0.0009; preserves balanced alkalinity supply and removal instead of deleting sink',
  'masks':list(range(4)),
  'timing':'Branches start after common full-model spinup; settings then continue for 200000 TU',
  'interpretation':'Effect of dynamic sediment removal feedback relative to balanced constant removal; does not measure the effect of eliminating sediment or its mean sink'},
 'storage_columns':['x1','x2','w','eta','TL','Catm','Cocn','ALK','Bcal'],
 'welch':{'fs':1,'window':'hann','nperseg':2500,'noverlap':1250,'detrend':'constant','scaling':'spectrum'},
 'w_band_year_inverse':[0.05,0.15],'eta_band_decade_inverse':[0.5,1.5],
 'target_frequency_TU_inverse':0.0056,
 'selected_archived_window_postspinup_TU_inclusive':[10000,20000],
 'windows':'Twenty nonoverlapping (j*10000,(j+1)*10000] TU windows per initial condition; clock restarts after spinup as in archived driver',
 'uncertainty':'Pointwise paired bootstrap across ten specified initial-condition units, not across 200 consecutive windows; exploratory conditional sensitivity intervals',
 'decomposition':'Möbius factorial main/interaction terms and Shapley interaction allocation; all effects normalized by the same per-initial-condition reference power; no claim of unique physical energy fractions',
 'paper_edit':'No manuscript changes requested in this task'}
(B/'configuration.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
(B/'source_manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
print('已准备独立实验源码与预先固定的比较口径。')

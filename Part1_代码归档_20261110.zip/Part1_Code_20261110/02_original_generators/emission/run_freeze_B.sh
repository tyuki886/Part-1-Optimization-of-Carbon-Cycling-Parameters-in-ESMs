#!/bin/bash
# 冻结模式 批 B（2026-08-11）：实验 1（E=0.8×10）+ 实验 2（E=0.4×10, E=1.2×10）
# 每条：IC 出发 10000 TU 调整 + 5000 TU 分析（每 1 TU 输出）
# 映射：TID 0-9 -> E=0.8 IC01-10（实验1，=实验2 CONTROL 组）
#       TID 10-19 -> E=0.4 IC01-10；TID 20-29 -> E=1.2 IC01-10
# 输出 exp2/E080|E040|E120/s{IC}.txt
#SBATCH --job-name=FRZB
#SBATCH --account=ab0246
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=08:00:00
#SBATCH --array=0-29
set -euo pipefail
BASE=/work/ab0246/wuyuhang/SRDP/output/MCPE21.0
FZ=$BASE/results_C66/freeze
TID=$SLURM_ARRAY_TASK_ID
if [ $TID -lt 10 ]; then
  E=0.8; GRP=E080; IC=$((TID+1))
elif [ $TID -lt 20 ]; then
  E=0.4; GRP=E040; IC=$((TID-9))
else
  E=1.2; GRP=E120; IC=$((TID-19))
fi
mkdir -p "$FZ/exp2/$GRP"; cd "$FZ/exp2/$GRP"
"$BASE/freeze_src/freeze" exp12 "$FZ/ic/ic$(printf '%02d' $IC).txt" "$E" "s$(printf '%02d' $IC).txt"
echo "FRZB_${GRP}_IC${IC}_DONE"

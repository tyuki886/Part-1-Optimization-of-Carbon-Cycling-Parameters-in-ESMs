#!/bin/bash
# 冻结模式 批 A（2026-08-11）：IC 生成（实验1前置）+ 独立实验 4/6/9
# TID 0: icgen  E=0.8 15000 TU → ic/ic01..ic10 + ic/ctrl_seq.txt
# TID 1: budget E=0.8 5000 TU 通量日志 → exp4/budget_flux.txt
# TID 2: longseq E=0.8 20000 TU → exp6/longseq.txt
# TID 3: hyst 五阶段 50000 TU → exp9/hyst_seq.txt + exp9/hyst_stage_means.txt
#SBATCH --job-name=FRZA
#SBATCH --account=ab0246
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=08:00:00
#SBATCH --array=0-3
set -euo pipefail
BASE=/work/ab0246/wuyuhang/SRDP/output/MCPE21.0
FZ=$BASE/results_C66/freeze
TID=$SLURM_ARRAY_TASK_ID
if [ $TID -eq 0 ]; then
  mkdir -p "$FZ/ic"; cd "$FZ/ic"
  "$BASE/freeze_src/freeze" icgen
elif [ $TID -eq 1 ]; then
  mkdir -p "$FZ/exp4"; cd "$FZ/exp4"
  "$BASE/freeze_src/freeze" budget budget_flux.txt
elif [ $TID -eq 2 ]; then
  mkdir -p "$FZ/exp6"; cd "$FZ/exp6"
  "$BASE/freeze_src/freeze" longseq longseq.txt
else
  mkdir -p "$FZ/exp9"; cd "$FZ/exp9"
  "$BASE/freeze_src/freeze" hyst hyst_seq.txt hyst_stage_means.txt
fi
echo "FRZA_T${TID}_DONE"

! freeze.f90 — 十变量冻结模式验证（实验 1-9 执行指南，2026-08-11；跳 5/7）
! c28=1.0 定稿基准；所有实验不修改方程/参数/周期，仅允许 E 路径与初值变化
! 统一：dt=0.01 TU/步；100 步 = 1 TU；adv_true_state(x, it, 10) 全耦合
!
! 模式（第一个命令行参数）：
!   icgen                     E=0.8 积分 15000 TU；10000-15000 每 500 TU 抽 IC01..IC10
!                             同时输出 ctrl_seq.txt（10000-15000 每 1 TU）
!   exp12 <icfile> <E> <out>  从 IC 出发 10000 TU 调整 + 5000 TU 分析（每 1 TU 输出）
!   step  <icfile> <E> <out>  从 IC 出发直接积分 5000 TU（阶跃瞬态，每 1 TU 输出）
!   pulse <icfile> <out>      从 IC 出发：0-100 TU E=1.2，之后 E=0.8，共 5100 TU
!   budget <out>              E=0.8 积分 5000 TU；每步累加通量积分与状态增量，每 1 TU 输出
!   longseq <out>             E=0.8 积分 20000 TU（10000 调整 + 10000 分析，每 1 TU 输出）
!   hyst <out_seq> <out_stg>  五阶段连续 0.4→0.8→1.2→0.8→0.4 各 10000 TU；
!                             每阶段后 5000 TU 统计均值；全程每 10 TU 输出序列
! IC 文件：一行 10 列（x1..x10），ice 由诊断关系重算
program freeze
    use RKmethod
    implicit none
    character(256) :: mode, a1, a2, a3

    call get_command_argument(1, mode)
    select case (trim(mode))
    case ('icgen');   call mode_icgen()
    case ('exp12');   call get_command_argument(2, a1); call get_command_argument(3, a2)
                      call get_command_argument(4, a3); call mode_exp12(a1, a2, a3)
    case ('step');    call get_command_argument(2, a1); call get_command_argument(3, a2)
                      call get_command_argument(4, a3); call mode_step(a1, a2, a3)
    case ('pulse');   call get_command_argument(2, a1); call get_command_argument(3, a2)
                      call mode_pulse(a1, a2)
    case ('budget');  call get_command_argument(2, a1); call mode_budget(a1)
    case ('longseq'); call get_command_argument(2, a1); call mode_longseq(a1)
    case ('hyst');    call get_command_argument(2, a1); call get_command_argument(3, a2)
                      call mode_hyst(a1, a2)
    case default
        error stop 'unknown mode'
    end select
contains

    subroutine read_ic(fname, x)
        character(*), intent(in) :: fname
        real(kind=dp), intent(out) :: x(10)
        integer :: u
        open(newunit=u, file=trim(fname), status='old')
        read(u, *) x
        close(u)
        call update_sea_ice(x)
    end subroutine

    ! ---- 实验 1 前置：E=0.8 控制轨迹 + IC01..IC10 + 10000-15000 序列 ----
    subroutine mode_icgen()
        real(kind=dp) :: x(10)
        integer(kind=8) :: i, icstep
        integer :: u1, u2, k
        call reset_to_standard()
        x = 0.0_dp; x(2) = 1.0_dp; call update_sea_ice(x)
        open(newunit=u1, file='ctrl_seq.txt', status='replace')
        do i = 1, 1500000_8
            call adv_true_state(x, i, 10)
            if (i >= 1000000_8 .and. mod(i, 50000_8) == 0_8) then
                k = int((i - 1000000_8)/50000_8) + 1   ! 10000->1, 10500->2, ..., 14500->10
                open(newunit=u2, file=write_ic(k), status='replace')
                write(u2, '(10ES17.7)') x
                close(u2)
            end if
            if (i >= 1000000_8 .and. mod(i, 100_8) == 0_8) then
                write(u1, '(F10.2,1X,10ES15.7)') dble(i)/100.0_dp, x
            end if
        end do
        close(u1)
        write(*, '(A)') 'ICGEN_DONE'
    end subroutine

    character(16) function write_ic(k)
        integer, intent(in) :: k
        write(write_ic, '(A,I2.2,A)') 'ic', k, '.txt'
    end function

    ! ---- 实验 1/2：从 IC 出发 10000 TU 调整 + 5000 TU 分析（每 1 TU 输出）----
    subroutine mode_exp12(icf, earg, outf)
        character(*), intent(in) :: icf, earg, outf
        real(kind=dp) :: x(10), E
        integer(kind=8) :: i
        integer :: u
        read(earg, *) E
        call reset_to_standard(); E_rate = E
        call read_ic(icf, x)
        open(newunit=u, file=trim(outf), status='replace')
        do i = 1, 1500000_8
            call adv_true_state(x, i, 10)
            if (i >= 1000000_8 .and. mod(i, 100_8) == 0_8) then
                write(u, '(F10.2,1X,10ES15.7)') dble(i)/100.0_dp, x
            end if
        end do
        close(u)
        write(*, '(A)') 'EXP12_DONE '//trim(outf)
    end subroutine

    ! ---- 实验 3：阶跃瞬态（从 IC 直接 5000 TU，每 1 TU 输出）----
    subroutine mode_step(icf, earg, outf)
        character(*), intent(in) :: icf, earg, outf
        real(kind=dp) :: x(10), E
        integer(kind=8) :: i
        integer :: u
        read(earg, *) E
        call reset_to_standard(); E_rate = E
        call read_ic(icf, x)
        open(newunit=u, file=trim(outf), status='replace')
        do i = 1, 500000_8
            call adv_true_state(x, i, 10)
            if (mod(i, 100_8) == 0_8) then
                write(u, '(F10.2,1X,10ES15.7)') dble(i)/100.0_dp, x
            end if
        end do
        close(u)
        write(*, '(A)') 'STEP_DONE '//trim(outf)
    end subroutine

    ! ---- 实验 8：排放脉冲（0-100 TU E=1.2，之后 0.8，共 5100 TU，每 1 TU 输出）----
    subroutine mode_pulse(icf, outf)
        character(*), intent(in) :: icf, outf
        real(kind=dp) :: x(10)
        integer(kind=8) :: i
        integer :: u
        call reset_to_standard(); E_rate = 1.2_dp
        call read_ic(icf, x)
        open(newunit=u, file=trim(outf), status='replace')
        do i = 1, 510000_8
            if (i == 10001_8) E_rate = 0.8_dp    ! 100 TU 结束，恢复基准
            call adv_true_state(x, i, 10)
            if (mod(i, 100_8) == 0_8) then
                write(u, '(F10.2,1X,10ES15.7)') dble(i)/100.0_dp, x
            end if
        end do
        close(u)
        write(*, '(A)') 'PULSE_DONE '//trim(outf)
    end subroutine

    ! ---- 实验 4：碳预算闭合（E=0.8，5000 TU，每步累加通量积分与状态增量）----
    subroutine mode_budget(outf)
        character(*), intent(in) :: outf
        real(kind=dp) :: x(10), pCO2_oc, Bcal, Fao, Fland, Fcp, Fbio
        real(kind=dp) :: cFao, cFland, cFcp, cFbio, cBcal, cE, cdx8, cdx9, cdx10
        real(kind=dp) :: xold(10), x8_0, x9_0, x10_0
        integer(kind=8) :: i
        integer :: u
        call reset_to_standard(); E_rate = 0.8_dp
        x = 0.0_dp; x(2) = 1.0_dp; call update_sea_ice(x)
        cFao = 0.0_dp; cFland = 0.0_dp; cFcp = 0.0_dp; cFbio = 0.0_dp
        cBcal = 0.0_dp; cE = 0.0_dp; cdx8 = 0.0_dp; cdx9 = 0.0_dp; cdx10 = 0.0_dp
        x8_0 = x(8); x9_0 = x(9); x10_0 = x(10)
        open(newunit=u, file=trim(outf), status='replace')
        do i = 1, 500000_8
            xold = x
            call adv_true_state(x, i, 10)
            pCO2_oc = max(c29*x(9) - c30*x(10), 0.0_dp)
            Bcal = c26*x(9)*max(x(10) - c27*x(9) + c28, 0.0_dp)
            Fao   = c18*(1.0_dp - c19*x(4))*(x(8) - pCO2_oc)
            Fland = c20*x(8)*x(7)
            Fcp   = c21*x(1)*(x(7) - x(4))
            Fbio  = c22*(1.0_dp - c23*x(4))*x(5)
            cFao = cFao + Fao*0.01_dp; cFland = cFland + Fland*0.01_dp
            cFcp = cFcp + Fcp*0.01_dp; cFbio = cFbio + Fbio*0.01_dp
            cBcal = cBcal + Bcal*0.01_dp; cE = cE + E_rate*0.01_dp
            cdx8 = cdx8 + (x(8)-xold(8)); cdx9 = cdx9 + (x(9)-xold(9))
            cdx10 = cdx10 + (x(10)-xold(10))
            if (mod(i, 100_8) == 0_8) then
                write(u, '(F10.2,1X,3ES15.7,1X,6ES15.7,1X,3ES15.7)') dble(i)/100.0_dp, &
                    x(8), x(9), x(10), cE, cFao, cFland, cFcp, cFbio, cBcal, cdx8, cdx9, cdx10
            end if
        end do
        close(u)
        write(*, '(A,3ES13.5)') 'BUDGET_DONE dC=', x(8)-x8_0, x(9)-x9_0, x(10)-x10_0
    end subroutine

    ! ---- 实验 6：E=0.8 连续 20000 TU（10000 调整 + 10000 分析，每 1 TU 输出）----
    subroutine mode_longseq(outf)
        character(*), intent(in) :: outf
        real(kind=dp) :: x(10)
        integer(kind=8) :: i
        integer :: u
        call reset_to_standard(); E_rate = 0.8_dp
        x = 0.0_dp; x(2) = 1.0_dp; call update_sea_ice(x)
        open(newunit=u, file=trim(outf), status='replace')
        do i = 1, 2000000_8
            call adv_true_state(x, i, 10)
            if (i >= 1000000_8 .and. mod(i, 100_8) == 0_8) then
                write(u, '(F10.2,1X,10ES15.7)') dble(i)/100.0_dp, x
            end if
        end do
        close(u)
        write(*, '(A)') 'LONGSEQ_DONE '//trim(outf)
    end subroutine

    ! ---- 实验 9：五阶段迟滞路径（各 10000 TU；阶段后 5000 TU 均值；全程每 10 TU 序列）----
    subroutine mode_hyst(outseq, outstg)
        character(*), intent(in) :: outseq, outstg
        real(kind=dp) :: x(10), E5(5), sumx(10), sumx2(10)
        integer(kind=8) :: i, w0, w1, n
        integer :: u1, u2, st
        E5 = [0.4_dp, 0.8_dp, 1.2_dp, 0.8_dp, 0.4_dp]
        call reset_to_standard(); E_rate = E5(1)
        x = 0.0_dp; x(2) = 1.0_dp; call update_sea_ice(x)
        open(newunit=u1, file=trim(outseq), status='replace')
        open(newunit=u2, file=trim(outstg), status='replace')
        do st = 1, 5
            E_rate = E5(st)
            w0 = (st-1)*1000000_8 + 500000_8    ! 阶段后 5000 TU 起
            w1 = st*1000000_8
            sumx = 0.0_dp; sumx2 = 0.0_dp; n = 0_8
            do i = w0, w1
                call adv_true_state(x, i, 10)
                sumx = sumx + x; sumx2 = sumx2 + x*x; n = n + 1_8
            end do
            write(u2, '(I1,1X,F4.2,1X,10ES15.7,1X,10ES15.7)') st, E5(st), &
                sumx/real(n,dp), sqrt(max(sumx2/real(n,dp) - (sumx/real(n,dp))**2, 0.0_dp))
        end do
        close(u2)
        ! 全程每 10 TU 序列（50000 TU 总长）
        E_rate = E5(1)
        do i = 1, 5000000_8
            if (i <= 1000000_8) then
                E_rate = E5(1)
            elseif (i <= 2000000_8) then
                E_rate = E5(2)
            elseif (i <= 3000000_8) then
                E_rate = E5(3)
            elseif (i <= 4000000_8) then
                E_rate = E5(4)
            else
                E_rate = E5(5)
            end if
            call adv_true_state(x, i, 10)
            if (mod(i, 1000_8) == 0_8) then
                write(u1, '(F10.2,1X,10ES15.7)') dble(i)/100.0_dp, x
            end if
        end do
        close(u1)
        write(*, '(A)') 'HYST_DONE'
    end subroutine
end program

# -*- coding: utf-8 -*-
"""十变量冻结模式验证：7 张图 + 统计表（超算运行，只产 png/pdf + 打印数字）
数据：results_C66/freeze/
  ic/ic01..ic10（实验1前置）exp2/E080|E040|E120/s{IC}.txt（实验1+2）
  exp3/{high,low,control}/IC{01..10}.txt（实验3，control 实验8 复用）
  exp4/budget_flux.txt（实验4）exp6/longseq.txt（实验6）
  exp8/pulse_IC{01..10}.txt（实验8）exp9/hyst_seq.txt hyst_stage_means.txt（实验9）
输出：results_C66/freeze/figures/V1..V7.png（dpi=150）
"""
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

FZ = Path('/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/results_C66/freeze')
OUT = FZ / 'figures'; OUT.mkdir(exist_ok=True)
ST = ['x1', 'x2', 'x3', 'w', 'eta', 'ice', 'TL', 'Catm', 'Cocean', 'Alk']
MAIN = ['Catm', 'Cocean', 'Alk', 'TL', 'w', 'eta']
MAIN_I = [7, 8, 9, 6, 3, 4]
rng = np.random.default_rng(42)

def load(p):
    return np.loadtxt(p)

def mean_last(p, nlast=5000):
    d = load(p)
    return d[-nlast:, 1:].mean(0)          # 后 nlast TU 长期均值（10 变量）

def bootstrap_ci(x, nboot=10000, ci=0.95):
    if x.size == 0: return (np.nan, np.nan)
    m = rng.choice(x, size=(nboot, x.size), replace=True).mean(1)
    lo = np.quantile(m, (1-ci)/2); hi = np.quantile(m, (1+ci)/2)
    return lo, hi

def lag_ci(a, b, tau, block=100, nboot=500, ci=0.95):
    """移动块 bootstrap：相同块索引重采样 a/b，在固定 tau 处算 R，返回 95% CI"""
    n = len(a); nb = int(np.ceil(n/block))
    m = np.empty(nboot)
    for k in range(nboot):
        idx = []
        for _ in range(nb):
            s = rng.integers(0, max(n-block, 1))
            idx.extend(range(s, min(s+block, n)))
        ii = np.array(idx[:n])
        m[k] = corr_lag(a[ii], b[ii], tau)
    return np.quantile(m, (1-ci)/2), np.quantile(m, (1+ci)/2)

IC = [f'IC{i:02d}' for i in range(1, 11)]

# ============ V1 实验1：10 初值长期气候稳健性 ============
M = np.array([mean_last(FZ / f'exp2/E080/s{i:02d}.txt') for i in range(1, 11)])
print('==== V1 实验1 跨 seed 统计（10 变量，5000 TU 均值） ====')
print(f'{"var":>6s} {"mean":>10s} {"median":>10s} {"SD":>10s} {"IQR":>10s} {"min":>10s} {"max":>10s}')
V1 = []
for j, v in enumerate(ST):
    row = [M[:, j].mean(), np.median(M[:, j]), M[:, j].std(),
           np.percentile(M[:, j], 75)-np.percentile(M[:, j], 25),
           M[:, j].min(), M[:, j].max()]
    V1.append(row)
    print(f'{v:>6s} ' + ' '.join(f'{x:10.4g}' for x in row))
fig, ax = plt.subplots(figsize=(13, 6))
bp = ax.boxplot([M[:, j] for j in range(10)], showfliers=True, patch_artist=True,
                medianprops=dict(color='k'))
for j, patch in enumerate(bp['boxes']):
    patch.set_facecolor('#5B8FF9' if j not in MAIN_I else '#C44E52')
for j in range(10):
    ax.scatter(np.full(10, j+1) + rng.uniform(-0.12, 0.12, 10), M[:, j],
               s=28, color='k', alpha=0.65, zorder=3)
ax.set_xticks(range(1, 11)); ax.set_xticklabels(ST, fontsize=10)
ax.set_ylabel('5000 TU long-term mean (10 seeds)')
ax.set_title('V1: multi-IC climate robustness (E=0.8, 10 initial states)')
ax.grid(alpha=0.3)
plt.tight_layout(); fig.savefig(OUT/'V1_multiclim.png', dpi=150); plt.close()
print('Saved V1')

# ============ V2 实验2：配对异常量 + bootstrap CI ============
M8  = np.array([mean_last(FZ / f'exp2/E080/s{i:02d}.txt') for i in range(1, 11)])
M4  = np.array([mean_last(FZ / f'exp2/E040/s{i:02d}.txt') for i in range(1, 11)])
M12 = np.array([mean_last(FZ / f'exp2/E120/s{i:02d}.txt') for i in range(1, 11)])
dH = M12 - M8; dL = M4 - M8
print()
print('==== V2 实验2 配对异常量（10 对差值；bootstrap 95% CI） ====')
print(f'{"var":>6s} {"dH_mean":>9s} {"dH_med":>9s} {"dH_CI":>16s} {"posH":>5s} {"dL_mean":>9s} {"dL_med":>9s} {"dL_CI":>16s} {"posL":>5s}')
V2 = []
for v, j in zip(MAIN, MAIN_I):
    cih = bootstrap_ci(dH[:, j]); cil = bootstrap_ci(dL[:, j])
    V2.append((v, j))
    print(f'{v:>6s} {dH[:,j].mean():9.4g} {np.median(dH[:,j]):9.4g} '
          f'[{cih[0]:8.4g},{cih[1]:8.4g}] {(dH[:,j]>0).sum():5d} '
          f'{dL[:,j].mean():9.4g} {np.median(dL[:,j]):9.4g} '
          f'[{cil[0]:8.4g},{cil[1]:8.4g}] {(dL[:,j]>0).sum():5d}')
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
for ax, (D, tag) in zip(axes, ((dH, 'E=1.2 minus E=0.8'), (dL, 'E=0.4 minus E=0.8'))):
    means = [D[:, j].mean() for j in MAIN_I]
    meds = [np.median(D[:, j]) for j in MAIN_I]
    x = np.arange(6)
    ax.bar(x-0.16, means, 0.32, color='#4A78D1', label='mean')
    ax.bar(x+0.16, meds, 0.32, color='#E6A23C', label='median')
    ax.axhline(0, color='k', lw=1)
    ax.set_xticks(x); ax.set_xticklabels(MAIN)
    ax.set_title(tag); ax.legend(fontsize=9); ax.grid(alpha=0.3)
fig.suptitle('Long-term mean anomalies under high- and low-emission forcing', fontweight='bold')
plt.tight_layout(); fig.savefig(OUT/'V2_paired_anomalies.png', dpi=150); plt.close()
print('Saved V2')

# ============ V3 实验3：阶跃响应（10 seed 配对 → ensemble mean） ============
def seq(name_pat):
    return np.array([load(FZ / f'exp3/{name_pat.format(i=i)}') for i in range(1, 11)])

H = seq('high/IC{i:02d}.txt'); L = seq('low/IC{i:02d}.txt'); C = seq('control/IC{i:02d}.txt')
dH3 = H[:, :, 1:] - C[:, :, 1:]     # (10, 5000, 10) 配对差
dL3 = L[:, :, 1:] - C[:, :, 1:]
t = H[0, :, 0]
print()
print('==== V3 实验3 阶跃响应（ensemble mean，最后 100 TU 均值为稳态参考） ====')
print(f'{"var":>6s} {"HIGH t10":>9s} {"t50":>9s} {"t90":>9s} {"peak":>10s} {"t_peak":>8s} | {"LOW t10":>9s} {"t50":>9s} {"t90":>9s} {"peak":>10s} {"t_peak":>8s}')
def resp_metrics(d, dt=1.0):
    """d: (10, 5000)；返回 t10/t50/t90（未达到 NaN）、峰值、峰值时间"""
    em = d.mean(0)
    ref = em[-100:].mean()
    pk_i = int(np.argmax(np.abs(em)))
    out = {}
    if abs(ref) < 1e-12: return (np.nan,)*5
    for pct, key in ((0.10, 't10'), (0.50, 't50'), (0.90, 't90')):
        reach = None
        for k in range(len(em)):
            if abs(em[k]) >= pct*abs(ref):
                reach = k*dt; break
        out[key] = reach
    return out['t10'], out['t50'], out['t90'], em[pk_i], pk_i*dt
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
for si, v in enumerate(MAIN):
    j = MAIN_I[si]; ax = axes[si//3, si%3]
    for D, col, tag in ((dH3, '#C44E52', 'HIGH'), (dL3, '#4C72B0', 'LOW')):
        em = D[:, :, j].mean(0)
        k = 100                       # 100 TU 分块均值（慢响应）
        nb = len(em)//k
        tb = t[::k][:nb]; eb = em[:nb*k].reshape(nb, k).mean(1)
        ax.plot(tb, eb, color=col, lw=2.4, label=tag)
        m = resp_metrics(D[:, :, j])
        print(f'{v:>6s} {m[0] if m[0] is not None else float("nan"):9.1f} {m[1] if m[1] is not None else float("nan"):9.1f} '
              f'{m[2] if m[2] is not None else float("nan"):9.1f} {m[3]:10.4g} {m[4]:8.1f} | ', end='')
    print()
    ax.axhline(0, color='k', lw=0.8)
    ax.set_title(v); ax.set_xlabel('t (TU)'); ax.legend(fontsize=8); ax.grid(alpha=0.3)
fig.suptitle('Transient responses to abrupt changes in emission forcing', fontweight='bold')
plt.tight_layout(); fig.savefig(OUT/'V3_step_response.png', dpi=150); plt.close()
print('Saved V3')

# ============ V4 实验4：碳预算闭合 ============
b = load(FZ / 'exp4/budget_flux.txt')
t4, x8, x9, x10, cE, cFao, cFland, cFcp, cFbio, cBcal, dx8, dx9, dx10 = b.T
c25 = 0.0018
R_atm  = dx8 - (cE - cFao - cFland - cFcp)
R_oce  = dx9 - (cFao - cFbio - cBcal)
R_alk  = dx10 - (c25*t4 - 2.0*cBcal)
R_tot  = (dx8+dx9) - (cE - cFland - cFcp - cFbio - cBcal)
def normR(R, *flux):
    return np.abs(R[-1]) / (np.abs(flux[-1]).sum() + 1e-30)
print()
print('==== V4 实验4 预算闭合（5000 TU 末，归一化残差 |R|/∫Σ|flux|） ====')
for name, R, fl in (('R_atm', R_atm, (cE, cFao, cFland, cFcp)),
                    ('R_ocean', R_oce, (cFao, cFbio, cBcal)),
                    ('R_Alk', R_alk, (c25*t4, 2*cBcal)),
                    ('R_total', R_tot, (cE, cFland, cFcp, cFbio, cBcal))):
    print(f'{name:>8s}  最终残差={R[-1]:12.6e}  归一化={normR(R, *fl):12.6e}')
fig, axes = plt.subplots(2, 2, figsize=(14, 9))
for ax, (name, R) in zip(axes.flatten(), (('R_atm', R_atm), ('R_ocean', R_oce), ('R_Alk', R_alk), ('R_total', R_tot))):
    ax.plot(t4, R, lw=1.5, color='#C44E52')
    ax.axhline(0, color='k', lw=0.8); ax.set_title(name); ax.set_xlabel('t (TU)'); ax.grid(alpha=0.3)
fig.suptitle('V4: carbon budget closure residuals (cumulative)', fontweight='bold')
plt.tight_layout(); fig.savefig(OUT/'V4_budget_closure.png', dpi=150); plt.close()
print('Saved V4')

# ============ V5 实验6：滞后相关（raw + deseason + block bootstrap） ============
lg = load(FZ / 'exp6/longseq.txt')
tg, X = lg[:, 0], lg[:, 1:]
n = len(tg)
PAIRS = [('Catm', 'TL'), ('Catm', 'w'), ('w', 'eta'), ('Catm', 'Cocean'),
         ('Cocean', 'Alk'), ('x2', 'w'), ('x2', 'TL')]
def corr_lag(a, b, tau):
    """R_XY(tau) = Corr[X(t), Y(t+tau)]；tau>0 表示 X 领先 Y"""
    if tau >= 0:
        return np.corrcoef(a[:n-tau], b[tau:])[0, 1]
    return np.corrcoef(a[-tau:], b[:n+tau])[0, 1]
def deseason(x, phase=10):
    x = np.asarray(x); out = x.copy()
    for ph in range(phase):
        idx = np.arange(ph, len(x), phase)
        out[idx] = x[idx] - x[idx].mean()
    return out
TAU = np.arange(-2000, 2001)           # ±2000 TU
print()
print('==== V5 实验6 滞后相关（τ>0: X 领先 Y；raw 与 deseason(10 TU)） ====')
print(f'{"pair":>14s} {"raw τ_max":>9s} {"R":>8s} {"CI":>14s} {"dsea τ_max":>9s} {"R":>8s}')
fig, axes = plt.subplots(2, 4, figsize=(22, 9))
axes = axes.flatten()
for si, (xa, yb) in enumerate(PAIRS):
    a = X[:, ST.index(xa)]; b = X[:, ST.index(yb)]
    ad, bd = deseason(a), deseason(b)
    ax = axes[si]
    rinfo = {}
    for tag, aa, bb, col in (('raw', a, b, '#4A78D1'), ('deseason', ad, bd, '#C44E52')):
        R = np.array([corr_lag(aa, bb, t) for t in TAU])
        k = int(np.argmax(np.abs(R)))
        ci = lag_ci(aa, bb, TAU[k], block=100, nboot=500)
        rinfo[tag] = (TAU[k], R[k], ci)
        ax.plot(TAU, R, color=col, lw=1.2, label=tag)
        ax.axvline(TAU[k], color=col, ls=':', lw=1)
    r, d = rinfo['raw'], rinfo['deseason']
    print(f'{xa+"->"+yb:>14s} {r[0]:9d} {r[1]:8.3f} [{r[2][0]:6.3f},{r[2][1]:6.3f}] | {d[0]:9d} {d[1]:8.3f} [{d[2][0]:6.3f},{d[2][1]:6.3f}]')
    ax.axhline(0, color='k', lw=0.7)
    ax.set_title(f'{xa} -> {yb}'); ax.set_xlabel('τ (TU)'); ax.legend(fontsize=8); ax.grid(alpha=0.3)
axes[7].axis('off')
fig.suptitle('V5: lagged cross-correlation (10000-20000 TU, E=0.8; τ>0 = X leads Y)', fontweight='bold')
plt.tight_layout(); fig.savefig(OUT/'V5_lagcorr.png', dpi=150); plt.close()
print('Saved V5')

# ============ V6 实验8：脉冲恢复 ============
P = np.array([load(FZ / f'exp8/pulse_IC{i:02d}.txt') for i in range(1, 11)])
ncut = min(P.shape[1], C.shape[1])
tp = P[0, :ncut, 0]
dP = P[:, :ncut, 1:] - C[:, :ncut, 1:]
print()
print('==== V6 实验8 脉冲恢复（峰值、峰值时间、t_50,rec；未恢复标记 nan） ====')
print(f'{"var":>6s} {"A_peak":>11s} {"t_peak":>8s} {"t50_rec":>9s} {"@100TU%":>8s} {"@500TU%":>8s} {"@5000TU%":>9s}')
V6 = {}
for v, j in zip(MAIN, MAIN_I):
    em = dP[:, :, j].mean(0)
    pk = int(np.argmax(np.abs(em)))
    A_peak = em[pk]
    base = max(abs(em[pk]), 1e-30)
    em_post = em[100:]                       # 脉冲结束后
    half = None
    for k in range(len(em_post)):
        if abs(em_post[k]) <= 0.5*abs(A_peak):
            half = 100 + k; break
    def pct_at(tu):
        k = min(int(tu), len(em)-1)
        return em[k]/base if A_peak != 0 else np.nan
    print(f'{v:>6s} {A_peak:11.4g} {tp[pk]:8.1f} {half if half else float("nan"):9.1f} '
          f'{pct_at(100):8.1%} {pct_at(500):8.1%} {pct_at(5000):9.1%}')
    V6[v] = (em, tp)
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
for si, v in enumerate(MAIN):
    ax = axes[si//3, si%3]
    em, tp = V6[v]
    ax.plot(tp, dP[:, :, ST.index(v)].T, color='#7F7F7F', lw=0.6, alpha=0.4)
    ax.plot(tp, em, color='#C44E52', lw=2.4)
    ax.axvline(100, color='k', ls=':', lw=1.2)
    ax.axhline(0, color='k', lw=0.8)
    ax.set_title(v); ax.set_xlabel('t (TU)'); ax.grid(alpha=0.3)
fig.suptitle('V6: emission pulse (E=1.2 for 100 TU) recovery; dashed = pulse end', fontweight='bold')
plt.tight_layout(); fig.savefig(OUT/'V6_pulse_recovery.png', dpi=150); plt.close()
print('Saved V6')

# ============ V7 实验9：迟滞回线 ============
stg = np.loadtxt(FZ / 'exp9/hyst_stage_means.txt')     # 5 × (1 stage, E, mean10, std10)
E5 = [0.4, 0.8, 1.2, 0.8, 0.4]
print()
print('==== V9 实验9 迟滞 H（stage 5 行：stage E mean10） ====')
print(f'{"var":>6s} {"H(0.8)":>11s} {"H(0.4)":>11s}')
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
for si, v in enumerate(MAIN):
    j = ST.index(v)
    up = [stg[0, 2+j], stg[1, 2+j], stg[2, 2+j]]      # 0.4->0.8->1.2
    dn = [stg[4, 2+j], stg[3, 2+j]]                    # 0.4(回) 0.8(降)
    H8 = stg[3, 2+j] - stg[1, 2+j]                     # 降-升 at 0.8
    H4 = stg[4, 2+j] - stg[0, 2+j]                     # 回-初 at 0.4
    print(f'{v:>6s} {H8:11.4g} {H4:11.4g}')
    ax = axes[si//3, si%3]
    ax.plot([0.4, 0.8, 1.2], up, 'o-', color='#C44E52', lw=2.2, label='up (0.4->1.2)')
    ax.plot([0.4, 0.8], dn[::-1], 's--', color='#4A78D1', lw=2.2, label='down (1.2->0.4)')
    ax.set_title(v); ax.set_xlabel('E'); ax.legend(fontsize=8); ax.grid(alpha=0.3)
fig.suptitle('V7: hysteresis loop (5-stage path, stage-mean of last 5000 TU)', fontweight='bold')
plt.tight_layout(); fig.savefig(OUT/'V7_hysteresis.png', dpi=150); plt.close()
print('Saved V7')
print()
print('ALL_7_FIGURES_DONE ->', OUT)

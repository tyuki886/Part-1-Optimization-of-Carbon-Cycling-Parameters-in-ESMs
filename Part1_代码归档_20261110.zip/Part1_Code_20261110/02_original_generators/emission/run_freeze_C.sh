#!/bin/bash
# 冻结模式 批 C（2026-08-11）：实验 3（阶跃 ×10 IC）+ 实验 8（脉冲 ×10 IC）
# step：IC 出发直接积分 5000 TU（无 spin-up，阶跃瞬态）
# pulse：IC 出发 0-100 TU E=1.2 后 0.8，共 5100 TU
# 映射：TID 0-9 -> step E=1.2（HIGH）IC01-10
#       TID 10-19 -> step E=0.4（LOW）IC01-10
#       TID 20-29 -> step E=0.8（CONTROL，实验8复用）IC01-10
#       TID 30-39 -> pulse IC01-10
# 输出 exp3/{high,low,control}/IC{01..10}.txt；exp8/pulse_IC{01..10}.txt
#SBATCH --job-name=FRZC
#SBATCH --account=ab0246
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=08:00:00
#SBATCH --array=0-39
set -euo pipefail
BASE=/work/ab0246/wuyuhang/SRDP/output/MCPE21.0
FZ=$BASE/results_C66/freeze
TID=$SLURM_ARRAY_TASK_ID
if [ $TID -lt 10 ]; then
  E=1.2; GRP=high; IC=$((TID+1))
  mkdir -p "$FZ/exp3/$GRP"; cd "$FZ/exp3/$GRP"
  "$BASE/freeze_src/freeze" step "$FZ/ic/ic$(printf '%02d' $IC).txt" "$E" "IC$(printf '%02d' $IC).txt"
elif [ $TID -lt 20 ]; then
  E=0.4; GRP=low; IC=$((TID-9))
  mkdir -p "$FZ/exp3/$GRP"; cd "$FZ/exp3/$GRP"
  "$BASE/freeze_src/freeze" step "$FZ/ic/ic$(printf '%02d' $IC).txt" "$E" "IC$(printf '%02d' $IC).txt"
elif [ $TID -lt 30 ]; then
  E=0.8; GRP=control; IC=$((TID-19))
  mkdir -p "$FZ/exp3/$GRP"; cd "$FZ/exp3/$GRP"
  "$BASE/freeze_src/freeze" step "$FZ/ic/ic$(printf '%02d' $IC).txt" "$E" "IC$(printf '%02d' $IC).txt"
else
  IC=$((TID-29))
  mkdir -p "$FZ/exp8"; cd "$FZ/exp8"
  "$BASE/freeze_src/freeze" pulse "$FZ/ic/ic$(printf '%02d' $IC).txt" "pulse_IC$(printf '%02d' $IC).txt"
fi
echo "FRZC_T${TID}_DONE"

"""Two identical-marker figures and nearest-divisor-of-2000 time tables."""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image
import fit_display_windows as old

BASE=Path(__file__).resolve().parent
OUT=BASE/'final_pair_divisors2000'
SRC=BASE/'plateau_axes_restored'/'results.json'
DIVISORS=[d for d in range(1,2001) if 2000%d==0]

def nearest(t):
    # Ties choose smaller, recorded for completeness; no actual input is tied.
    return min(DIVISORS,key=lambda d:(abs(d-t),d))

def main():
    OUT.mkdir(exist_ok=True)
    source_hash=hashlib.sha256(SRC.read_bytes()).hexdigest()
    rows=json.loads(SRC.read_text(encoding='utf-8'))['results']
    previous_axes=json.loads((BASE/'plateau_axes_restored'/'validation.json').read_text(encoding='utf-8'))['axes']
    assert DIVISORS==sorted({2**a*5**b for a in range(5) for b in range(4)})
    assert len(rows)==60
    data={};mapped=[]
    for r in rows:
        name=r['parameter'];v=r['variable'];t0=r['marker_TU'];d=nearest(t0)
        idx=int(np.argmin(abs(np.asarray(DIVISORS)-t0)))
        assert d==DIVISORS[idx] and 2000%d==0
        mapped.append({'parameter':name,'variable':v,'measured_TU':t0,'adopted_TU':d,
                       'difference_TU':d-t0,'marker_y':r['marker_y'],
                       'measurement_basis':r['marker_basis'],'fit_caveats':r['fit_caveats']})
        col={'x2':2,'w':4,'TL':5,'Catm':6,'Cocean':7,'ALK':8}[v]
        t,y,h=old.load_window((old.WATER+old.CARBON).index(name)+1,name,col,r['window_TU'])
        data[(name,v)]=(t,y)
    tables(mapped)
    (OUT/'formal_times.json').write_text(json.dumps({'divisors':DIVISORS,
        'rounding':'nearest by absolute TU difference, not ceiling; ties choose smaller',
        'source_sha256':source_hash,'graph_markers_not_rounded':True,'results':mapped},ensure_ascii=False,indent=2),encoding='utf-8')
    render(rows,data,previous_axes)
    assert source_hash==hashlib.sha256(SRC.read_bytes()).hexdigest()
    print((OUT/'MCPE正式饱和时间分档表.md').read_text(encoding='utf-8'),flush=True)

def tables(rows):
    intro=['# MCPE正式饱和时间分档表（2000 TU最近约数）','',
        '按用户指定：以实际取点时间与2000的正整数约数之差的绝对值最小为准，不向上取整、不先四舍五入测量值。同距时取较小值；本批没有同距情形。','',
        '候选约数：'+', '.join(map(str,DIVISORS))+'。','',
        '这是按参数–响应变量列出的正式饱和时间分档，不把2000 TU解释为参数入场间隔，不自动变更任何运行脚本的更新周期或生成新的MCPE编号。','',
        '图中仍为原测量时间和原点位；整数分档只用于本表。原拟合分辨率/触边等注意项以及慢ALK的窗口依赖性不会因整数分档消失。','']
    raw=['# 饱和取点与正式分档对照','',
         '每格：原取点时间 → 最近2000约数，单位TU；使用未舍入的原值分档。原始完整精度、差值、取点依据和拟合注意项保存在formal_times.json。','',
         '57点沿用拟合渐近平台95%；c20/c29/c28对应ALK沿用当前窗口拟合峰值90%。图中百分比文字已去掉，但测量定义没有改变。†表示原拟合注意项。','']
    for params,vars_,title in [(old.WATER,old.VARS[:3],'水循环参数'),(old.CARBON,old.VARS[3:],'碳循环参数')]:
        header=[f'## {title}','','| 参数 | '+' | '.join(vars_)+' |','|---|---:|---:|---:|']
        intro+=header;raw+=header
        for p in params:
            rr=[next(r for r in rows if r['parameter']==p and r['variable']==v) for v in vars_]
            intro.append('| '+p+' | '+' | '.join(str(r['adopted_TU']) for r in rr)+' |')
            raw.append('| '+p+' | '+' | '.join(f"{r['measured_TU']:.1f} → {r['adopted_TU']}"+('†' if r['fit_caveats'] else '') for r in rr)+' |')
        intro.append('');raw.append('')
    raw+=['无拟合版只隐藏拟合线，标记仍位于原拟合取点的(x,y)，不移到原始波动线上。两张图坐标和像素位置一致。',
           '右下角按用户指定保留0–0.10显示范围，部分原始波动在边界裁切，原数据不变。','']
    (OUT/'MCPE正式饱和时间分档表.md').write_text('\n'.join(intro),encoding='utf-8')
    (OUT/'原始取点与正式分档对照.md').write_text('\n'.join(raw),encoding='utf-8')

def render(rows,data,previous_axes):
    font_manager.fontManager.addfont(str(BASE/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':14,
                         'path.simplify':False,'agg.path.chunksize':10000,'mathtext.fontset':'stix'})
    fig,axes=plt.subplots(3,6,figsize=(26,13),layout='constrained')
    fit_lines=[];markers=[];audit=[]
    for side,params in enumerate([old.WATER,old.CARBON]):
        for group,subset in enumerate([params[:3],params[3:6],params[6:]]):
            col=side*3+group
            for row in range(3):
                v=old.VARS[side*3+row];ax=axes[row,col]
                for k,name in enumerate(subset):
                    r=next(x for x in rows if x['parameter']==name and x['variable']==v)
                    t,y=data[(name,v)];f=r['fit'];T=r['window_TU'];color=old.COLORS[k]
                    label=f"{name}: {r['marker_TU']:.1f}"+('*' if r['fit_caveats'] else '')
                    raw,=ax.plot(np.r_[0,t],np.r_[0,y],color=color,lw=.8,alpha=.6,label=label)
                    np.testing.assert_array_equal(raw.get_ydata()[1:],y)
                    tf=np.linspace(0,T,max(1000,len(t)))
                    fit,=ax.plot(tf,old.evaluate(tf,f),color=color,lw=1.8,ls='--');fit_lines.append(fit)
                    special=v=='ALK' and name in {'c20','c29','c28'}
                    marker,=ax.plot(r['marker_TU'],r['marker_y'],marker='D' if special else 'o',ms=5,color=color,
                        markerfacecolor='white' if r['fit_caveats'] else color,markeredgecolor='black',markeredgewidth=.5)
                    markers.append(marker)
                    np.testing.assert_array_equal([marker.get_xdata()[0],marker.get_ydata()[0]],[r['marker_TU'],r['marker_y']])
                    audit.append({'parameter':name,'variable':v,'x':r['marker_TU'],'y':r['marker_y']})
                prev=next(a for a in previous_axes if a['row']==row+1 and a['column']==col+1)
                assert prev['ylabel']==v
                ax.set(xlim=prev['xlim'],ylim=prev['ylim'],xlabel='Time (TU)',ylabel=v)
                if row==2 and col==5:ax.set_yticks(np.arange(0,.1001,.02))
                if row==0:ax.set_title(old.VARS[col],fontsize=14)
                ax.grid(alpha=.25,ls=':');ax.legend(fontsize=9,loc='best',framealpha=.85)
    fig.suptitle('Parameter sensitivity responses and saturation times',fontsize=18)
    fig.supxlabel('Response: ensemble standard deviation. Solid: raw 0.1-TU samples; dashed (when shown): fitted response.\nSymbols: fixed saturation-time markers from the fitted curves. * = fit caveat; see the accompanying time table.',fontsize=12)
    assert not any('%' in text.get_text() for text in fig.findobj(matplotlib.text.Text))
    fig.canvas.draw()
    # Freeze layout once so hiding fits cannot move axes, legends or markers.
    fig.set_layout_engine('none')
    pixels_before=[m.axes.transData.transform([m.get_xdata()[0],m.get_ydata()[0]]).tolist() for m in markers]
    for stem,visible in [('saturation_with_fit',True),('saturation_without_fit',False)]:
        for line in fit_lines:line.set_visible(visible)
        fig.canvas.draw()
        pixels=[m.axes.transData.transform([m.get_xdata()[0],m.get_ydata()[0]]).tolist() for m in markers]
        np.testing.assert_array_equal(pixels,pixels_before)
        path=OUT/f'{stem}.png';fig.savefig(path,dpi=300,facecolor='white')
        with Image.open(path) as im:
            assert im.size==(7800,3900)
            im.thumbnail((1800,1000));im.convert('RGB').save(OUT/f'{stem}_preview.jpg',quality=80)
    plt.close(fig)
    (OUT/'validation.json').write_text(json.dumps({'markers':audit,'both_versions_exact_same_xy_and_display_positions':True,
        'all_original_60_marker_coordinates_unchanged':True,'previous_axis_limits_preserved':True,
        'no_percentage_text_in_figures':True,'fits_only_hidden_not_refit':True,'points_in_each_figure':60,
        'divisor_independent_crosscheck':True,'divisors':DIVISORS},ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':main()

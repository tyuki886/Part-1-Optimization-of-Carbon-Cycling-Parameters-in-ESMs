"""Fit only the six user-selected display windows and locate max positive slope.

Operational saturation time = within-window inflection of the fitted growth
trend. It is not statistical stationarity or a derivative discontinuity.
All archived 0.1-TU observations inside each window enter ordinary least squares.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
from scipy.optimize import least_squares, minimize_scalar
from scipy.special import expit
import scipy

BASE=Path(__file__).resolve().parent
OUT=BASE/'display_window_fit'
WATER=['kappa','c1','b','sigma','c13','c2','lambda','c4','c12','c11']
CARBON=['c24','c16','c20','c29','c18','c30','c28','c19','c22','c23']
VARS=['x2','w','TL','Catm','Cocean','ALK']
COLS=[2,4,5,6,7,8]
LIMITS=[20,50,50,100,100,2000]
COLORS=['#1f77b4','#ff7f0e','#2ca02c','#d62728']
DT=.1


def shape(x,logk,tau,model):
    """Unit-asymptote sigmoid anchored at f(0)=0, x=t/window_TU.

    g(x)=[h(x)-h(0)]/[1-h(0)], so the inflection remains tau.
    Stable equivalent expressions also cover a pre-window inflection.
    """
    k=np.exp(logk)
    decay=-np.expm1(-k*x)
    if model=='Logistic':
        return decay*expit(k*(x-tau))
    z0=np.exp(np.clip(k*tau,-50,50))
    z=np.exp(np.clip(k*(tau-x),-50,50))
    return np.exp(-z)*(-np.expm1(-z0*decay))/(-np.expm1(-z0))


def evaluate(t,fit):
    return fit['A']*shape(np.asarray(t)/fit['window_TU'],
                           np.log(fit['k_per_TU']*fit['window_TU']),
                           fit['inflection_TU']/fit['window_TU'],fit['model'])


def derivative(t,fit):
    x=np.asarray(t)/fit['window_TU'];kn=fit['k_per_TU']*fit['window_TU']
    tau=fit['inflection_TU']/fit['window_TU']
    if fit['model']=='Logistic':
        u=kn*(x-tau);h=expit(u)
        ds=kn*(np.exp(-kn*x)*h+(-np.expm1(-kn*x))*h*expit(-u))
    else:
        z0=np.exp(np.clip(kn*tau,-50,50));z=np.exp(np.clip(kn*(tau-x),-50,50))
        ds=kn*z*np.exp(-z)/(-np.expm1(-z0))
    return fit['A']/fit['window_TU']*ds


def fit_one(t,y,model):
    T=float(t[-1]);x=t/T;scale=float(np.max(y));yn=y/scale
    tail=np.median(yn[-max(5,len(y)//4):])
    target=tail*(.5 if model=='Logistic' else 1/np.e)
    crossed=np.flatnonzero(yn>=target)
    guess=float(x[crossed[0]]) if len(crossed) else .3
    # No positive-time restriction: a curve already decelerating may have no
    # interior inflection. Such fits are recorded but no positive point invented.
    lower=np.array([.01,np.log(.01),-2.])
    upper=np.array([10.,np.log(1e4),2.])
    starts=[(max(.2,tail),np.log(k),tau) for k in [4.,20.,100.]
            for tau in sorted(set([-.15,guess,.35,.7]))]
    best=None;solutions=[]
    def residual(q):return q[0]*shape(x,q[1],q[2],model)-yn
    for start in starts:
        sol=least_squares(residual,start,bounds=(lower,upper),method='trf',
                          loss='linear',x_scale='jac',max_nfev=800,
                          ftol=1e-10,xtol=1e-10,gtol=1e-10)
        sse=float(sol.fun@sol.fun)
        solutions.append({'sse_normalized':sse,'tau_TU':float(sol.x[2]*T),'success':bool(sol.success)})
        if best is None or sse<best[0]:best=(sse,sol)
    sse_norm,sol=best;q=sol.x
    fitted=q[0]*shape(x,q[1],q[2],model)*scale
    sse=float(np.sum((fitted-y)**2));sst=float(np.sum((y-y.mean())**2))
    tau=float(q[2]*T)
    peak_inside=bool(0<tau<T)
    result={'model':model,'A':float(q[0]*scale),'k_per_TU':float(np.exp(q[1])/T),
            'inflection_TU':tau,'window_TU':T,'sample_points':len(y),
            'success':bool(sol.success),'SSE':sse,'RMSE':float(np.sqrt(sse/len(y))),
            'R_squared':float(1-sse/sst),'inflection_inside':peak_inside,
            'initial_value_anchored_zero':True,'parameter_bounds_hit':bool(np.any(abs(q-lower)<1e-5) or np.any(abs(q-upper)<1e-5)),
            'jacobian_condition':float(np.linalg.cond(sol.jac)),
            'optimizer_starts':solutions}
    result['window_max_slope_time_TU']=float(np.clip(tau,0,T))
    result['max_positive_slope_in_window']=float(derivative(np.clip(tau,0,T),result))
    if peak_inside:
        search=minimize_scalar(lambda z:-float(derivative(z,result)),bounds=(0,T),method='bounded',options={'xatol':1e-10})
        result['numerical_peak_check_TU']=float(search.x)
        # Very narrow fitted peaks may defeat a whole-window scalar search;
        # independently evaluate a dense LOCAL bracket around analytic tau.
        width=min(T/4,max(DT,4/result['k_per_TU']))
        local=np.linspace(max(0,tau-width),min(T,tau+width),20001)
        numerical=float(local[np.argmax(derivative(local,result))])
        result['dense_derivative_peak_check_TU']=numerical
        assert abs(numerical-tau)<=max(.01,(local[-1]-local[0])/10000)
    np.testing.assert_allclose(evaluate(np.array([0.]),result),[0.],atol=1e-12)
    np.testing.assert_allclose(evaluate(t,result),fitted,rtol=1e-10,atol=1e-10*scale)
    return result


def load_window(slot,name,col,T):
    folder=BASE/'results'/str(slot);src=folder/f'saturation_{name}.bin'
    raw=src.read_bytes();digest=hashlib.sha256(raw).hexdigest()
    audit=json.loads((folder/'audit.json').read_text(encoding='utf-8'))
    assert digest==audit['binary_sha256']
    # Only the authorized display-window samples are extracted for any fitting.
    n=int(round(T/DT))
    d=np.frombuffer(raw,dtype='<f8').reshape(-1,9)[:n]
    assert np.isfinite(d).all()
    np.testing.assert_allclose(d[:,0],np.arange(1,n+1)*DT,atol=1e-10,rtol=0)
    return d[:,0].copy(),d[:,col].copy(),digest


def run_fit():
    results=[];hashes={}
    for slot,name in enumerate(WATER+CARBON,1):
        indices=range(3) if name in WATER else range(3,6)
        for j in indices:
            t,y,digest=load_window(slot,name,COLS[j],LIMITS[j]);hashes[name]=digest
            fits=[fit_one(t,y,m) for m in ['Logistic','Gompertz']]
            selected=min(fits,key=lambda x:x['SSE'])
            other=next(f for f in fits if f is not selected)
            flags=[]
            if not selected['success']:flags.append('solver_not_converged')
            if not selected['inflection_inside']:flags.append('no_interior_inflection')
            if selected['parameter_bounds_hit']:flags.append('parameter_bound_hit')
            if selected['jacobian_condition']>1e8:flags.append('poor_identifiability')
            if selected['inflection_inside'] and min(selected['inflection_TU'],LIMITS[j]-selected['inflection_TU'])<2*DT:
                flags.append('near_window_boundary')
            if 1/selected['k_per_TU']<DT:flags.append('transition_under_sample_resolution')
            if selected['inflection_inside'] and other['inflection_inside']:
                difference=abs(selected['inflection_TU']-other['inflection_TU'])
                if difference>max(2*DT,.25*abs(selected['inflection_TU'])):flags.append('model_sensitive_time')
            elif selected['inflection_inside']!=other['inflection_inside']:
                flags.append('models_disagree_on_interior_inflection')
            ts=selected['inflection_TU'] if selected['inflection_inside'] and selected['success'] else None
            r={'parameter':name,'variable':VARS[j],'window_TU':LIMITS[j],
               'selected_model':selected['model'],'saturation_time_TU':ts,
               'flags':flags,'models':fits,
               'selection':'minimum in-window SSE; same number of parameters; descriptive comparison, not an iid significance test',
               'SSE_gain_over_other_percent':100*(other['SSE']-selected['SSE'])/max(other['SSE'],1e-30)}
            results.append(r)
            print(name,VARS[j],selected['model'],'tau',None if ts is None else round(ts,4),'flags',flags,flush=True)
            payload={'definition':'saturation = maximum positive slope / inflection of fitted window growth trend',
                     'sample_interval_TU':DT,'windows_TU':dict(zip(VARS,LIMITS)),
                     'source_sha256':hashes,'scipy_version':scipy.__version__,
                     'fit_all_20000_TU':False,'pre_smoothing':False,'decimation':False,
                     'results':results}
            (OUT/'fit_results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    assert len(results)==60


def self_test():
    tests=[]
    for model in ['Logistic','Gompertz']:
        t=np.arange(1,1001)*.1
        known={'model':model,'A':2.,'k_per_TU':.15,'window_TU':100.,'inflection_TU':20.}
        y=evaluate(t,known);fit=fit_one(t,y,model)
        assert abs(fit['inflection_TU']-20)<1e-3
        assert abs(fit['A']-2)<1e-5
        u=np.linspace(1,99,300);h=1e-4
        fd=(evaluate(u+h,fit)-evaluate(u-h,fit))/(2*h)
        np.testing.assert_allclose(fd,derivative(u,fit),rtol=1e-5,atol=1e-9)
        tests.append({'model':model,'known_peak_TU':20,'recovered_peak_TU':fit['inflection_TU'],'analytic_derivative_matches_finite_difference':True})
    (OUT/'synthetic_validation.json').write_text(json.dumps(tests,indent=2),encoding='utf-8')
    print('synthetic tests passed',flush=True)


def selected_fit(r):return next(x for x in r['models'] if x['model']==r['selected_model'])


def render():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from PIL import Image
    font_manager.fontManager.addfont(str(BASE/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':13,
                         'path.simplify':False,'agg.path.chunksize':10000,'mathtext.fontset':'stix'})
    payload=json.loads((OUT/'fit_results.json').read_text(encoding='utf-8'));rows=payload['results']
    assert len(rows)==60
    data={};checks=[]
    for r in rows:
        slot=(WATER+CARBON).index(r['parameter'])+1;j=VARS.index(r['variable'])
        t,y,h=load_window(slot,r['parameter'],COLS[j],r['window_TU'])
        assert h==payload['source_sha256'][r['parameter']]
        data[(r['parameter'],r['variable'])]=(t,y)
    fig,axes=plt.subplots(3,6,figsize=(26,13),layout='constrained')
    for side,params in enumerate([WATER,CARBON]):
        for row,subset in enumerate([params[:3],params[3:6],params[6:]]):
            for j in range(3):
                col=side*3+j;v=VARS[col];T=LIMITS[col];ax=axes[row,col]
                for k,name in enumerate(subset):
                    r=next(q for q in rows if q['parameter']==name and q['variable']==v)
                    fit=selected_fit(r);t,y=data[(name,v)];ts=r['saturation_time_TU']
                    raw,=ax.plot(np.r_[0.,t],np.r_[0.,y],color=COLORS[k],lw=.8,alpha=.6)
                    np.testing.assert_array_equal(raw.get_ydata()[1:],y)
                    suffix='NA' if ts is None else f'{ts:.1f}'+('*' if r['flags'] else '')
                    tf=np.linspace(0,T,max(1000,len(t)))
                    ax.plot(tf,evaluate(tf,fit),color=COLORS[k],lw=1.8,ls='--',label=f'{name}: {suffix}')
                    if ts is not None:
                        ax.plot(ts,evaluate(ts,fit),marker='o',markersize=5,color=COLORS[k],
                                markerfacecolor='white' if r['flags'] else COLORS[k],markeredgecolor='black',markeredgewidth=.5)
                    checks.append({'parameter':name,'variable':v,'points':len(t),'window_TU':T,'raw_exact':True})
                ax.set(xlim=(0,T),ylim=(0,None),xlabel='Time (TU)',ylabel=v,title=v)
                ax.grid(alpha=.25,ls=':');ax.legend(fontsize=9,loc='best',framealpha=.85)
    fig.suptitle('Parameter response fits and saturation points',fontsize=18)
    fig.supxlabel('Thin solid: raw 0.1-TU samples; dashed: selected growth fit; circles: maximum-slope points. * = fit caveat; NA = no interior point.',fontsize=12)
    main=OUT/'window_fits_saturation_18panels.png';fig.savefig(main,dpi=300,facecolor='white');plt.close(fig)
    with Image.open(main) as im:
        size=im.size;im.thumbnail((1800,1000));im.convert('RGB').save(OUT/'main_preview.jpg',quality=80)
    # One variable-parameter per cell for honest visual comparison of both fits.
    for label,params,variables in [('water_1',WATER[:5],VARS[:3]),('water_2',WATER[5:],VARS[:3]),
                                  ('carbon_1',CARBON[:5],VARS[3:]),('carbon_2',CARBON[5:],VARS[3:])]:
        fig,axes=plt.subplots(5,3,figsize=(19,16),layout='constrained')
        for i,name in enumerate(params):
            for j,v in enumerate(variables):
                ax=axes[i,j];r=next(q for q in rows if q['parameter']==name and q['variable']==v)
                t,y=data[(name,v)];T=r['window_TU']
                ax.plot(np.r_[0.,t],np.r_[0.,y],color='#777777',alpha=.75,lw=.8,label='Raw')
                tf=np.linspace(0,T,max(1000,len(t)))
                for f,color,style in zip(r['models'],['#0072B2','#D55E00'],['--','-.']):
                    ax.plot(tf,evaluate(tf,f),color=color,ls=style,lw=1.8,label=f['model'])
                    if f['inflection_inside']:
                        tau=f['inflection_TU'];ax.plot(tau,evaluate(tau,f),'o',color=color,ms=4)
                ts=r['saturation_time_TU'];subtitle='NA' if ts is None else f'{ts:.2f} TU'
                ax.set(xlim=(0,T),ylim=(0,None),xlabel='Time (TU)',ylabel=v,
                       title=f'{name} - {v}: {r["selected_model"]}, {subtitle}')
                ax.grid(alpha=.2);ax.legend(fontsize=9,loc='best')
        fig.suptitle('Window-only fits: original data, Logistic and Gompertz',fontsize=17)
        fig.savefig(OUT/f'{label}_fits.png',dpi=160);plt.close(fig)
        with Image.open(OUT/f'{label}_fits.png') as im:
            im.thumbnail((1800,1600));im.convert('RGB').save(OUT/f'{label}_preview.jpg',quality=75)
    (OUT/'plot_validation.json').write_text(json.dumps({'curves':checks,'main_pixels':size,
                 'original_sample_interval_TU':DT,'pre_smoothing':False,'extra_decimation':False,'main_dpi':300},indent=2),encoding='utf-8')
    print('rendered',main,flush=True)


def report():
    payload=json.loads((OUT/'fit_results.json').read_text(encoding='utf-8'));rows=payload['results']
    lines=['# 显示窗口内拟合：最大正斜率点作为饱和点','',
           '本轮用户定义：只拟合原图窗口，以拟合增长趋势从加速转为减速的拐点（最大正斜率时间）作为操作性饱和点。此处不是导数数学不连续，也不是证明后续长期统计稳定。','',
           '窗口：x2 0–20 TU；w、TL 0–50 TU；Catm、Cocean 0–100 TU；ALK 0–2000 TU。时间从参数扰动开始算，不是模型总积分时间。',
           '所有原始0.1 TU点等权参与最小二乘，无预先平滑、无抽稀、无窗口外数据拟合。原始零时刻成员相同，拟合约束S(0)=0。',
           '比较Logistic与Gompertz，两者均3个自由参数（幅度、速率、拐点时间），按窗口内残差平方和较小者选取；不将SSE差异当作独立样本显著性检验。','',
           '## 饱和时间（TU）','',
           'L=Logistic，G=Gompertz；†为拟合/模型依赖等注意项，详见后表；未定表示所选函数没有窗口内拐点。保留连续估计，不再沿用之前视觉约数分档。','']
    for params,variables,title in [(WATER,VARS[:3],'水循环参数'),(CARBON,VARS[3:],'碳循环参数')]:
        lines += [f'### {title}','','| 参数 | '+' | '.join(variables)+' |','|---|---:|---:|---:|']
        for name in params:
            cells=[]
            for v in variables:
                r=next(q for q in rows if q['parameter']==name and q['variable']==v)
                ts=r['saturation_time_TU'];cells.append('未定' if ts is None else f'{ts:.1f} ({r["selected_model"][0]})'+('†' if r['flags'] else ''))
            lines.append('| '+name+' | '+' | '.join(cells)+' |')
        lines.append('')
    lines += ['## 两种拟合及注意项','','| 参数–变量 | Logistic拐点 | Gompertz拐点 | 选用 | R² | 注意项 |','|---|---:|---:|---|---:|---|']
    labels={'no_interior_inflection':'所选拐点不在窗口内','solver_not_converged':'求解未收敛',
            'parameter_bound_hit':'参数触边','poor_identifiability':'参数可辨识性弱',
            'near_window_boundary':'接近窗口边界','transition_under_sample_resolution':'变化短于采样分辨率',
            'model_sensitive_time':'两函数取点差异较大','models_disagree_on_interior_inflection':'两函数对内部拐点存在性不一致'}
    for r in rows:
        f=selected_fit(r);a,c=r['models']
        lines.append(f'| {r["parameter"]}–{r["variable"]} | {a["inflection_TU"]:.2f} | {c["inflection_TU"]:.2f} | {f["model"]} | {f["R_squared"]:.3f} | '+('；'.join(labels[x] for x in r['flags']) or '—')+' |')
    lines += ['','## 可复算定义','',
              'Logistic基础形状h(t)=1/[1+exp(-k(t-ts))]；Gompertz基础形状h(t)=exp[-exp(-k(t-ts))]。',
              '实际拟合S(t)=A[h(t)-h(0)]/[1-h(0)]，保证S(0)=0。此线性平移缩放不改变内部拐点ts。',
              'A>0、k>0；时间按窗口长度归一化优化。每个模型12组起始值；ts允许落在窗口外以检出无内部拐点情形。',
              '两函数取点差异超过max(0.2 TU,所选时间的25%)记为模型依赖提示；这个阈值是诊断约定，不是置信水平。',
              'R²是原始振荡响应相对单调拟合趋势的描述性拟合度，不能单独证明取点可靠。未计算假定0.1 TU样点独立的置信区间。',
              '没有重新提交Fortran积分，没有修改MCPE参数入场或更新周期。旧B/C和视觉约数结果保留，不作为本轮取点依据。','']
    (OUT/'窗口拟合饱和点结果.md').write_text('\n'.join(lines),encoding='utf-8')
    from collections import Counter
    print(json.dumps({'fits':len(rows),'interior_points':sum(r['saturation_time_TU'] is not None for r in rows),
                      'selected_models':dict(Counter(r['selected_model'] for r in rows)),
                      'flags':dict(Counter(q for r in rows for q in r['flags']))},ensure_ascii=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['fit','render','report','test']);args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    if args.action=='fit':self_test();run_fit();report()
    elif args.action=='render':render()
    elif args.action=='report':report()
    else:self_test()

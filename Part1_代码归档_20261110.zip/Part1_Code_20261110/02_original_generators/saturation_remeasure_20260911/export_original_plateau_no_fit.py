"""按用户指定的早期平台图导出无拟合版；不改数据、拟合、取点或生产配置。"""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image
import fit_display_windows as old

BASE=Path(__file__).resolve().parent
OUT=BASE/'original_plateau_no_fit_20260913'
SRC=BASE/'plateau_from_existing_fit'/'plateau_results.json'
REFERENCE=BASE/'plateau_from_existing_fit'/'fitted_plateau_entry_18panels.png'

def main():
    OUT.mkdir(exist_ok=True)
    source_hash=hashlib.sha256(SRC.read_bytes()).hexdigest()
    reference_hash=hashlib.sha256(REFERENCE.read_bytes()).hexdigest()
    payload=json.loads(SRC.read_text(encoding='utf-8'))
    rows=payload['results']
    fit_payload=json.loads((BASE/'display_window_fit'/'fit_results.json').read_text(encoding='utf-8'))
    font_manager.fontManager.addfont(str(BASE/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':13,
                         'path.simplify':False,'agg.path.chunksize':10000,'mathtext.fontset':'stix'})
    fig,axes=plt.subplots(3,6,figsize=(26,13),layout='constrained')
    fits=[]; markers=[]; raw_lines=[]; audit=[]
    for side,params in enumerate([old.WATER,old.CARBON]):
        for row,subset in enumerate([params[:3],params[3:6],params[6:]]):
            for j in range(3):
                col=side*3+j;v=old.VARS[col];T=old.LIMITS[col];ax=axes[row,col]
                for k,name in enumerate(subset):
                    r=next(x for x in rows if x['parameter']==name and x['variable']==v)
                    t,y,h=old.load_window((old.WATER+old.CARBON).index(name)+1,name,old.COLS[col],T)
                    assert h==fit_payload['source_sha256'][name]
                    f=r['fit'];ts=r['plateau_95_TU'];color=old.COLORS[k]
                    raw,=ax.plot(np.r_[0.,t],np.r_[0.,y],color=color,lw=.8,alpha=.6)
                    raw_lines.append(raw)
                    np.testing.assert_array_equal(raw.get_ydata()[1:],y)
                    suffix='NR' if ts is None else f'{ts:.1f}'+('*' if r['fit_caveats'] else '')
                    tf=np.linspace(0,T,max(1000,len(t)))
                    line,=ax.plot(tf,old.evaluate(tf,f),color=color,lw=1.8,ls='--',label=f'{name}: {suffix}')
                    fits.append(line)
                    if ts is not None:
                        marker,=ax.plot(ts,.95*f['A'],marker='o',ms=5,color=color,
                            markerfacecolor='white' if r['fit_caveats'] else color,
                            markeredgecolor='black',markeredgewidth=.5)
                        markers.append(marker)
                    audit.append({'row':row+1,'column':col+1,'parameter':name,'variable':v,
                                  'x':ts,'y':None if ts is None else .95*f['A'],'raw_sha256':h})
                ax.set(xlim=(0,T),ylim=(0,None),xlabel='Time (TU)',ylabel=v,title=v)
                ax.grid(alpha=.25,ls=':');ax.legend(fontsize=9,loc='best',framealpha=.85)
    fig.suptitle('Parameter response fits and plateau-entry times',fontsize=18)
    footer=fig.supxlabel('Thin solid: raw 0.1-TU samples; dashed: unchanged fit; circles: 95% of fitted asymptote. * = fit caveat; NR = not reached in window.',fontsize=12)
    # 先按原代码导出复现基准，随后只隐藏拟合线，冻结坐标和图例布局。
    fig.savefig(OUT/'reference_reproduced.png',dpi=300,facecolor='white')
    fig.set_dpi(300);fig.canvas.draw();fig.set_layout_engine('none')
    renderer=fig.canvas.get_renderer()
    for ax in axes.flat:
        leg=ax.get_legend();bb=leg.get_window_extent(renderer).transformed(ax.transAxes.inverted())
        leg.set_loc('lower left');leg.set_bbox_to_anchor((bb.x0,bb.y0),transform=ax.transAxes)
        leg.borderaxespad=0
    before=[m.axes.transData.transform((m.get_xdata()[0],m.get_ydata()[0])).tolist() for m in markers]
    limits=[{'xlim':list(ax.get_xlim()),'ylim':list(ax.get_ylim()),'position':list(ax.get_position().bounds)} for ax in axes.flat]
    for line in fits:line.set_visible(False)
    for line in raw_lines:
        line.set_alpha(1.0);line.set_linewidth(1.0)
    for ax in axes.flat:
        for line in ax.get_legend().get_lines():line.set_linestyle('-');line.set_linewidth(1.0);line.set_alpha(1.0)
        for text in ax.get_legend().get_texts():
            if text.get_text().endswith(': NR'):text.set_text(text.get_text()[:-4])
            text.set_text(text.get_text().replace('*',''))
    fig._suptitle.set_text('Parameter sensitivity responses and plateau-entry times')
    footer.set_text('')
    fig.canvas.draw()
    after=[m.axes.transData.transform((m.get_xdata()[0],m.get_ydata()[0])).tolist() for m in markers]
    np.testing.assert_array_equal(before,after)
    assert len(raw_lines)==60 and len(markers)==57 and all(not line.get_visible() for line in fits)
    assert sum(r['x'] is None for r in audit)==3
    assert all('%' not in txt.get_text() for txt in fig.findobj(matplotlib.text.Text))
    assert all('NR' not in txt.get_text() for txt in fig.findobj(matplotlib.text.Text))
    assert all('*' not in txt.get_text() for txt in fig.findobj(matplotlib.text.Text))
    assert footer.get_text()=='' and all(line.get_alpha()==1.0 for line in raw_lines)
    dest=OUT/'fitted_plateau_entry_18panels_without_fit.png'
    fig.savefig(dest,dpi=300,facecolor='white');plt.close(fig)
    with Image.open(dest) as im:
        assert im.size==(7800,3900)
        im.thumbnail((1600,800));im.convert('RGB').save(OUT/'preview.jpg',quality=75)
    with Image.open(REFERENCE) as im,Image.open(OUT/'reference_reproduced.png') as rep:
        same_pixels=np.array_equal(np.asarray(im),np.asarray(rep))
    assert source_hash==hashlib.sha256(SRC.read_bytes()).hexdigest()
    assert reference_hash==hashlib.sha256(REFERENCE.read_bytes()).hexdigest()
    result={'source':str(SRC),'source_sha256':source_hash,'reference':str(REFERENCE),'reference_sha256':reference_hash,
            'reference_reproduction_pixel_identical':same_pixels,'raw_curves':60,'markers':57,'NR':3,
            'marker_pixels_unchanged_when_hiding_fits':True,'fits_recomputed':False,'raw_smoothed':False,
            'axes':limits,'data':audit,'output':str(dest),'pixels':[7800,3900]}
    (OUT/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['data','axes']},ensure_ascii=False))

if __name__=='__main__':main()

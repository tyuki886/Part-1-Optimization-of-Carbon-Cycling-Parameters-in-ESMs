"""同一条新长序列复核敏感性并测量8通道准饱和时间；不直接裁定更新周期。"""
from pathlib import Path
import sys, json, hashlib
import numpy as np
import guide_v2 as guide

ROOT = Path(__file__).resolve().parent
WATER = ['kappa','c1','b','sigma','c13','c2','lambda','c4','c12','c11']
CARBON = ['c24','c16','c20','c29','c18','c30','c28','c19','c22','c23']

def main():
    slot = int(sys.argv[1])
    name = (WATER + CARBON)[slot-1]
    path = Path('saturation_'+name+'.bin')
    data = np.fromfile(path, dtype='<f8').reshape(-1,9)
    assert data.shape == (200000,9) and np.isfinite(data).all()
    np.testing.assert_allclose(data[:,0], np.arange(1,200001)*0.1, rtol=0, atol=1e-10)
    assert (data[:,1:]>=0).all()
    source_line = [l.split() for l in (ROOT/'reference_sensitivity.txt').read_text().splitlines() if l and not l.startswith('#')]
    source_line = next(l for l in source_line if l[1]==name)
    new_line = [l.split() for l in Path('sensitivity_W20_C500.txt').read_text().splitlines() if l and not l.startswith('#')][0]
    assert source_line == new_line, 'Native-step sensitivity changed: '+name
    def load_curve(nm, var):
        assert nm == name
        return data[:,0], data[:,guide.VARS.index(var)+1]
    guide.load_curve = load_curve
    rows = [guide.run_one(name,var) for var in guide.VARS]
    # 保留旧算法的原始裁决供审计；ceil(tau)只是候选间隔，绝非已验证最优周期。
    for r in rows:
        r['candidate_interval_TU'] = r.pop('cycle_tau')
        r['requires_review'] = r['status'] in ('conflict','weak')
    bound = max(2000.,max((r['t_final'] or 0)*1.6 for r in rows))
    np.savez_compressed('curves.npz',data=data[data[:,0]<=bound])
    report = {'parameter':name,'slot':slot,'water':WATER,'carbon':CARBON,'results':rows,
              'rows':len(data),'duration_TU':float(data[-1,0]),'sample_interval_TU':0.1,
              'native_sensitivity_exact_match':True,'native_summary':new_line,
              'binary_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
              'method':'existing guide v2; same engineering thresholds; not exact author-code reproduction',
              'source_files':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in
                              ('RKmethod.f90','SaturationRemeasure.f90','guide_v2.py')}}
    Path('audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    Path('READY').touch()
    print('VERIFIED',name,flush=True)

if __name__=='__main__':
    main()

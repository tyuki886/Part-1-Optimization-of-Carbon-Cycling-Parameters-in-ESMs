"""B: empirical joint stability; C: descriptive continuous broken-line check.

Only analyses stored 0.1-TU ensemble standard deviations. No model integration,
parameter update, production-scheme mutation or temporal smoothing for figures.
The operational thresholds are diagnostic choices, not a published estimator.
"""
from pathlib import Path
import hashlib
import json
import math
import argparse
import numpy as np

BASE = Path(__file__).resolve().parent
OUT = BASE / 'bc_stability'
WATER = ['kappa','c1','b','sigma','c13','c2','lambda','c4','c12','c11']
CARBON = ['c24','c16','c20','c29','c18','c30','c28','c19','c22','c23']
VARIABLES = ['x1','x2','x3','w','TL','Catm','Cocean','ALK']
DT = .1
NBOOT = 399


def integral_scale(y):
    """Initial-positive ACF sum after linear detrending, in TU.

    Detrending is exclusively for choosing a diagnostic block size. The
    stationarity test below always uses un-detrended original observations.
    Oscillatory/correlated tails are not claimed independent at every sample.
    """
    n = len(y)
    u = np.linspace(-1., 1., n)
    r = y - y.mean()
    r = r - u * (u @ r / (u @ u))
    f = np.fft.rfft(r, n=2*n)
    ac = np.fft.irfft(abs(f)**2, n=2*n)[:n//2]
    if ac[0] <= np.finfo(float).tiny:
        return {'iat_TU': DT, 'first_zero_TU': None, 'constant': True}
    ac /= ac[0]
    ix = np.flatnonzero(ac[1:] <= 0)
    z = int(ix[0]+1) if len(ix) else len(ac)-1
    return {'iat_TU': float(max(DT, DT*(1+2*ac[1:z].sum()))),
            'first_zero_TU': float(z*DT), 'constant': False}


def features(y, n):
    """Each row: mean S, log temporal SD(S), slope(S)*window_duration.

    Temporal SD of the ensemble-SD sequence measures oscillation amplitude;
    it is not the parameter ensemble spread or an uncertainty on saturation.
    """
    if n > len(y):
        return np.empty((0,3))
    z = y[:len(y)//n*n].reshape(-1,n)
    mean = z.mean(axis=1)
    sd = z.std(axis=1, ddof=1)
    u = np.arange(n, dtype=float)
    u -= u.mean()
    slope_times_W = z @ u / (u @ u) * n
    floor = max(float(np.max(sd))*1e-12, np.finfo(float).tiny)
    return np.column_stack((mean, np.log(np.maximum(sd, floor)), slope_times_W))


def boot_rows(f, count, rng, repeats=NBOOT, block=2):
    """Circular feature-window blocks; preserve within-block serial order."""
    starts = rng.integers(0, len(f), size=(repeats, math.ceil(count/block)))
    idx = (starts[:,:,None] + np.arange(block)) % len(f)
    return f[idx.reshape(repeats,-1)[:,:count]]


def reference_test(f, rng, block):
    """Joint ordering diagnostic: quarter offsets and overall trend.

    Bootstrap reorders circular blocks under a stationary-reference working
    assumption. A pass is absence of detected drift, not proof of stationarity.
    """
    scale = np.maximum(f.std(axis=0,ddof=1), 1e-12)
    z = (f-f.mean(axis=0))/scale
    n = len(z)
    groups = np.array_split(np.arange(n),4)
    u = np.linspace(-.5,.5,n)
    def score(a):
        center = a.mean(axis=-2)
        q = np.stack([a[...,g,:].mean(axis=-2)-center for g in groups],axis=-2)
        slope = np.einsum('...ij,i->...j',a,u)/(u@u)
        return np.maximum(np.max(np.abs(q),axis=(-2,-1)),np.max(np.abs(slope),axis=-1))
    observed = float(score(z))
    null = []
    for start in range(0,NBOOT,20):
        b = boot_rows(z,n,rng,repeats=min(20,NBOOT-start),block=block)
        null.extend(score(b).tolist())
    null = np.asarray(null)
    p = (1+np.count_nonzero(null>=observed))/(len(null)+1)
    return {'passed': bool(p>=.05), 'bootstrap_p_diagnostic': float(p),
            'joint_ordering_score': observed,
            'null_95': float(np.quantile(null,.95)), 'reference_windows': n}


def followup_test(f, reference, rng, block):
    """Check four subsequent long epochs for mean feature shifts.

    Tests sustained shifts at this coarse follow-up scale, not every excursion.
    Joint max over all 4 epochs and all 3 features is calibrated in one bootstrap.
    """
    groups = np.array_split(np.arange(len(f)),4)
    if min(map(len,groups)) < 10:
        return {'passed': False, 'reason': 'fewer_than_10_windows_per_followup_epoch'}
    center = reference.mean(axis=0)
    scale = np.maximum(reference.std(axis=0,ddof=1),1e-12)
    observed = float(np.max(np.abs(np.stack([f[g].mean(axis=0) for g in groups])-center)/scale))
    maxima = np.zeros(NBOOT)
    for g in groups:
        for start in range(0,NBOOT,20):
            stop = min(NBOOT,start+20)
            b = boot_rows(reference,len(g),rng,repeats=stop-start,block=block)
            maxima[start:stop] = np.maximum(maxima[start:stop],
                np.max(np.abs(b.mean(axis=1)-center)/scale,axis=1))
    p = (1+np.count_nonzero(maxima>=observed))/(NBOOT+1)
    return {'passed': bool(p>=.05), 'bootstrap_p_diagnostic': float(p),
            'joint_epoch_shift': observed, 'null_95': float(np.quantile(maxima,.95)),
            'epoch_lengths_windows': list(map(len,groups)),
            'scope': 'four long epochs; short transient departures may remain undetected'}


def b_estimate(y, window_n, seed, tail_fraction=.5):
    W = window_n*DT
    f = features(y,window_n)
    nref = min(len(f),int(len(y)*tail_fraction)//window_n)
    result = {'window_TU': W, 'tail_fraction': tail_fraction,
              'reference_windows': nref, 'candidate_interval_TU': None,
              'confirmed_by_three_windows_TU': None, 'accepted_interval_TU': None}
    if nref < 30:
        result['status'] = 'reference_too_short'
        return result
    reference = f[-nref:]
    result['reference_range_TU'] = [(len(f)-nref)*W,len(f)*W]
    rng = np.random.default_rng(seed)
    feature_iat = [integral_scale(reference[:,j])['iat_TU']/DT for j in range(3)]
    block = max(2,int(math.ceil(2*max(feature_iat))))
    result['resampling_block_windows'] = block
    result['reference_feature_IAT_windows'] = feature_iat
    if nref/block < 10:
        result['status'] = 'reference_effective_blocks_too_few'
        return result
    gate = reference_test(reference,rng,block)
    result['reference_check'] = gate
    if not gate['passed']:
        result['status'] = 'reference_drift_detected'
        return result
    center = np.median(reference,axis=0)
    scale = 1.4826*np.median(abs(reference-center),axis=0)
    scale = np.maximum(scale,np.maximum(reference.std(axis=0,ddof=1)*.01,1e-12))
    ref_score = np.max(abs(reference-center)/scale,axis=1)
    cutoff = float(np.quantile(ref_score,.95,method='higher'))
    score = np.max(abs(f-center)/scale,axis=1)
    ok = score<=cutoff
    runs = np.flatnonzero(ok[:-2]&ok[1:-1]&ok[2:])
    result['normal_reference'] = {'feature_names': ['mean_S','log_temporal_sd_S','slope_times_W'],
                                'median': center.tolist(), 'MAD_scale': scale.tolist(),
                                'joint_empirical_95_cutoff': cutoff,
                                'reference_pass_fraction':float(np.mean(ref_score<=cutoff))}
    if not len(runs):
        result['status'] = 'no_three_window_candidate'
        return result
    k = int(runs[0])
    result['candidate_interval_TU'] = [k*W,(k+1)*W]
    result['confirmed_by_three_windows_TU'] = (k+3)*W
    result['followup_check'] = followup_test(f[k:],reference,rng,block)
    if result['followup_check']['passed']:
        result['status'] = 'provisionally_stable'
        result['accepted_interval_TU'] = result['candidate_interval_TU']
    else:
        result['status'] = 'candidate_but_later_shift_or_insufficient_followup'
    return result


def segmented(y, duration_TU, min_tau_TU):
    """OLS broken line evaluated on ALL original 0.1-TU samples using sums.

    y=a+b1*min(t,tau)+b2*max(t-tau,0). No filtered series, no iid p-value.
    Search quantization >=0.1TU; fit uncertainty is not inferred from OLS.
    """
    n = min(len(y),int(round(duration_TU/DT)))
    yy = y[:n]
    t = np.arange(1,n+1)*DT
    sy = np.r_[0.,np.cumsum(yy)]
    sty = np.r_[0.,np.cumsum(t*yy)]
    st = np.r_[0.,np.cumsum(t)]
    stt = np.r_[0.,np.cumsum(t*t)]
    yy2 = float(yy@yy)
    left = max(3,int(math.ceil(min_tau_TU/DT)))
    right = n-left
    if right<=left:
        return {'status':'fit_window_too_short'}
    grid = np.unique(np.r_[np.geomspace(left,right,600).astype(int),
                           np.linspace(left,right,400).astype(int)])
    def solve(k):
        tau = k*DT
        count = n-k
        p1 = st[k]+count*tau
        p2 = st[n]-st[k]-count*tau
        p11 = stt[k]+count*tau*tau
        p22 = stt[n]-stt[k]-2*tau*(st[n]-st[k])+count*tau*tau
        p12 = tau*p2
        A = np.array([[n,p1,p2],[p1,p11,p12],[p2,p12,p22]],float)
        b = np.array([sy[n],sty[k]+tau*(sy[n]-sy[k]),
                      sty[n]-sty[k]-tau*(sy[n]-sy[k])])
        try:
            beta = np.linalg.solve(A,b)
        except np.linalg.LinAlgError:
            return float('inf'),None
        sse = max(0.,float(yy2-beta@b))
        return sse,beta
    values = [solve(int(k))[0] for k in grid]
    k0 = int(grid[int(np.argmin(values))])
    near = int(np.flatnonzero(grid==k0)[0])
    lo = int(grid[max(0,near-1)]); hi = int(grid[min(len(grid)-1,near+1)])
    fine = np.arange(lo,hi+1)
    values = [solve(int(k))[0] for k in fine]
    k = int(fine[int(np.argmin(values))])
    sse,beta = solve(k)
    sst = float(np.sum((yy-yy.mean())**2))
    return {'status':'descriptive_fit_only','tau_TU':k*DT,
            'fit_duration_TU':n*DT,'coefficients_a_b1_b2':beta.tolist(),
            'sse':sse,'r_squared':1-sse/sst if sst>0 else None,
            'boundary_solution':bool(k<=left+1 or k>=right-1),
            'fitted_original_samples':n}


def c_check(y, baseline, window_n):
    W = window_n*DT
    # C must be independent of B's window width: growth can be faster than W.
    # At least three original samples on each side; boundary fits are flagged.
    fits = [segmented(y,len(y)*DT*q,3*DT) for q in [.5,.75,1.]]
    final = fits[-1]
    out = {'fits':fits,'status':'not_validated','comparison':'unavailable'}
    if final['status']!='descriptive_fit_only':
        return out
    tau = final['tau_TU']
    slopes = final['coefficients_a_b1_b2'][1:]
    if final['boundary_solution'] or slopes[0]<=0:
        out['status']='growth_to_plateau_model_not_supported'
        return out
    ref = baseline.get('normal_reference')
    if ref is None:
        out['status']='no_stable_reference_to_validate_plateau_slope'
        return out
    slope_score = abs(slopes[1]*W-ref['median'][2])/ref['MAD_scale'][2]
    if slope_score>ref['joint_empirical_95_cutoff']:
        out['status']='post_break_trend_exceeds_reference_fluctuation'
        return out
    if slopes[1]>=slopes[0]:
        out['status']='no_reduction_in_growth_rate'
        return out
    eligible = [a for a in fits if a['status']=='descriptive_fit_only' and not a['boundary_solution']]
    if len(eligible)!=3:
        out['status']='fit_range_check_incomplete'
        return out
    times=[a['tau_TU'] for a in fits]
    out['fit_range_sensitivity_TU']=[min(times),max(times)]
    out['status']='descriptive_turning_point'
    interval = baseline.get('accepted_interval_TU')
    if interval is not None:
        distance=max(interval[0]-tau,0,tau-interval[1])
        out['distance_from_B_interval_TU']=distance
        out['comparison']='agrees_within_one_B_window' if distance<=W else 'disagrees_with_B'
    if max(times)-min(times)>2*W:
        out['status']='turning_point_depends_on_fit_duration'
    return out


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--c-only',action='store_true')
    args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    prior=json.loads((OUT/'results.json').read_text(encoding='utf-8')) if args.c_only else None
    results=[]; hashes={}
    for slot,name in enumerate(WATER+CARBON,1):
        folder=BASE/'results'/str(slot)
        path=folder/f'saturation_{name}.bin'
        raw=path.read_bytes()
        digest=hashlib.sha256(raw).hexdigest()
        audit=json.loads((folder/'audit.json').read_text(encoding='utf-8'))
        assert digest==audit['binary_sha256']
        data=np.frombuffer(raw,dtype='<f8').reshape(-1,9)
        assert data.shape==(200000,9) and np.isfinite(data).all()
        np.testing.assert_allclose(data[:,0],np.arange(1,200001)*DT,atol=1e-10,rtol=0)
        hashes[name]=digest
        for j,var in enumerate(VARIABLES,1):
            y=data[:,j]
            if args.c_only:
                r=next(x for x in prior['results'] if x['parameter']==name and x['variable']==var)
                assert digest==prior['source_sha256'][name]
                r['C']=c_check(y,r['B'],int(round(r['B']['window_TU']/DT)))
                results.append(r)
                continue
            scale=integral_scale(y[len(y)//2:])
            wn=max(20,int(math.ceil(5*scale['iat_TU']/DT)))
            base=b_estimate(y,wn,10000+slot*100+j)
            variants={}
            for label,n,tail in [('half_window',max(10,int(round(wn/2))),.5),
                                  ('double_window',wn*2,.5),('last_quarter_reference',wn,.25)]:
                variants[label]=b_estimate(y,n,20000+slot*100+j,tail)
            accepted=[x['accepted_interval_TU'] for x in [base,*variants.values()] if x['accepted_interval_TU'] is not None]
            robust=bool(len(accepted)==4)
            envelope=[min(a[0] for a in accepted),max(a[1] for a in accepted)] if accepted else None
            c=c_check(y,base,wn)
            results.append({'parameter':name,'variable':var,'slot':slot,'acf':scale,
                            'B':base,'B_checks':variants,'B_all_checks_passed':robust,
                            'B_window_reference_sensitivity_envelope_TU':envelope,'C':c})
        print(name,{v:next(r for r in results if r['parameter']==name and r['variable']==v)['B']['status'] for v in ['x2','Catm','ALK']},flush=True)
        payload={'method_version':'B-C exploratory 1.0','sample_interval_TU':DT,
                 'duration_TU':20000,'source_sha256':hashes,'results':results}
        (OUT/'results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    from collections import Counter
    mainrows=[r for r in results if (r['parameter'] in WATER and r['variable'] in ['x2','w','TL']) or (r['parameter'] in CARBON and r['variable'] in ['Catm','Cocean','ALK'])]
    summary={'all_160_B':dict(Counter(r['B']['status'] for r in results)),
             'main_60_B':dict(Counter(r['B']['status'] for r in mainrows)),
             'main_60_C':dict(Counter(r['C']['status'] for r in mainrows)),
             'main_60_all_B_checks':sum(r['B_all_checks_passed'] for r in mainrows)}
    (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False))


if __name__=='__main__':
    main()

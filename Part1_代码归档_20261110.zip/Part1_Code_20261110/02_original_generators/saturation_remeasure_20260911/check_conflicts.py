"""复核拟合冲突：保留两种候选点，不自动裁决。诊断图仅留工作区。"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
import guide_v2 as guide
from plot_and_schemes import WATER,CARBON,VARS,BASE

report=json.loads((BASE/'tau_new_top20.json').read_text(encoding='utf-8'))
conflicts=[r for r in report['results'] if r['status']=='conflict']
fig,axes=plt.subplots(len(conflicts),2,figsize=(16,15),layout='constrained')
checks=[]
for i,r in enumerate(conflicts):
    name,var=r['param'],r['var'];slot=(WATER+CARBON).index(name)+1
    d=np.load(BASE/'results'/str(slot)/'curves.npz')['data'];t=d[:,0];y=d[:,VARS.index(var)+1]
    coef=guide.cubic_fit(t,y,r['t_num'])
    a,b,c,e,tfit,r2,nrmse,resid,ok,why=coef
    assert ok and np.isclose(tfit,r['t_fit'])
    np.testing.assert_allclose(r2,r['fit_R2'],rtol=0,atol=1e-10)
    tf=np.linspace(r['fit_start'],r['fit_end'],300)
    display=(t<=max(20,r['fit_end']*1.7))
    axes[i,0].plot(t[display],y[display],color='#1f77b4',label='Raw ensemble standard deviation')
    axes[i,0].plot(tf,a*tf**3+b*tf**2+c*tf+e,color='#7B3294',ls='--',label='Local cubic fit')
    tg,g=guide.g_series(t,y,*guide.SMOOTH[var])
    axes[i,1].plot(tg[display],g[display],color='#1f77b4',label='Smoothed growth rate')
    axes[i,1].plot(tf,3*a*tf**2+2*b*tf+c,color='#7B3294',ls='--',label='Derivative of cubic fit')
    for ax in axes[i]:
        ax.axvline(r['t_num'],color='#E66101',ls=':',label=f"Numerical: {r['t_num']:.1f} TU")
        ax.axvline(tfit,color='#7B3294',ls='-.',label=f'Fitted: {tfit:.1f} TU')
        ax.set_title(name+' → '+var);ax.set_xlabel('Time (TU)');ax.grid(alpha=.25);ax.legend(fontsize=10)
    axes[i,0].set_ylabel('Ensemble standard deviation');axes[i,1].set_ylabel('Growth rate (TU$^{-1}$)')
    sensitivity={}
    for factor in [.5,1,2]:
        sm=[v*factor for v in guide.SMOOTH[var]]
        num=guide.numeric_peak(t,y,guide.WIN0[var],*sm)[0]
        sensitivity[str(factor)]=num
    checks.append({'parameter':name,'variable':var,'numerical_TU':r['t_num'],'fitted_TU':tfit,
                   'fit_R2_reproduced':r2,'smoothing_scale_check_TU':sensitivity,
                   'decision':'Unresolved; retain both estimates, no automatic assimilation update policy'})
fig.savefig(BASE/'figures'/'conflict_diagnostics.png',dpi=200,facecolor='white');plt.close(fig)
with Image.open(BASE/'figures'/'conflict_diagnostics.png') as im:
    im.thumbnail((1400,1600));im.convert('RGB').save(BASE/'figures'/'conflict_diagnostics_preview.jpg',quality=90)
(BASE/'conflict_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(checks,ensure_ascii=False))

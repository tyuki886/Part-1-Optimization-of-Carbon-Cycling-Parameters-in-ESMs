"""Record explicitly subjective visual ranges, then test their divisor bins.

Ranges below were manually entered after viewing all 60 early/medium raw curves
and the 20 full Cocean/ALK curves. They are not confidence intervals or outputs
of a statistical fit. No failed B reference is overridden by a visual choice.
"""
import json
import numpy as np
import divisor_review as d
import bc_stability as b

WATER_RANGES=[
 [(8,10),(12,20),(8,15)],[(8,10),(12,20),(8,15)],
 [(8,10),(12,25),(8,15)],[(8,10),(15,25),(5,10)],
 [(10,15),(15,25),(6,10)],[(10,15),(15,25),(10,20)],
 [(12,20),(15,25),(10,20)],[(12,20),(15,25),(10,20)],
 [(12,20),(20,40),(10,20)],[(10,20),(15,25),(15,25)],
]
CARBON_RANGES=[
 [(25,40),(35,50),(600,1000)],[(20,30),(30,50),(500,800)],
 [(25,40),(1000,3000),(2000,4000)],[(20,30),(2000,3500),(2500,5000)],
 [(25,40),(50,80),(2500,5000)],[(30,50),None,None],
 [(70,100),(70,100),(1500,2000)],[(25,40),(35,50),(1000,1250)],
 [(30,50),(35,50),(1500,2000)],[(25,40),(35,50),(600,1000)],
]


def exact_check(y,old,time,seed):
    if old.get('normal_reference') is None:
        return {'status':'reference_unavailable','original_reason':old['status']}
    n=int(round(old['window_TU']/.1));start=time*10
    f=b.features(y[start:],n);ref=old['normal_reference']
    if len(f)<3:return {'status':'insufficient_future'}
    scores=np.max(abs(f[:3]-np.array(ref['median']))/np.array(ref['MAD_scale']),axis=1)
    if not np.all(scores<=ref['joint_empirical_95_cutoff']):
        return {'status':'local_joint_features_failed','scores':scores.tolist()}
    reference=b.features(y,n)[-old['reference_windows']:]
    follow=b.followup_test(f,reference,np.random.default_rng(seed),old['resampling_block_windows'])
    return {'status':'B_diagnostic_pass' if follow['passed'] else 'later_followup_failed','followup':follow}


def main():
    p,oldrows=d.main_rows();data=d.load_data(p);results=[]
    for group,variables,ranges in [(b.WATER,['x2','w','TL'],WATER_RANGES),
                                  (b.CARBON,['Catm','Cocean','ALK'],CARBON_RANGES)]:
        for name,rr in zip(group,ranges):
            for v,visual_range in zip(variables,rr):
                r=next(x for x in oldrows if x['parameter']==name and x['variable']==v)
                proposed=next((x for x in d.DIVISORS if visual_range is not None and x>=visual_range[1]),None)
                row={'parameter':name,'variable':v,'subjective_visual_range_TU':visual_range,
                     'visual_divisor_proposal_TU':proposed,'confirmed_saturation_time_TU':None,
                     'C_descriptive_turn_TU':r['C']['fits'][-1].get('tau_TU')}
                if proposed is None:
                    row['assessment']='no_clear_single_bin_at_or_below_5000_TU'
                    row['B_checks']={}
                else:
                    assert 5000%proposed==0
                    y=data[name][:,1+b.VARIABLES.index(v)]
                    row['B_checks']={label:exact_check(y,old,proposed,90000+r['slot']*100+b.VARIABLES.index(v))
                                     for label,old in {'base':r['B'],**r['B_checks']}.items()}
                    row['assessment']='visual_proposal_with_B_diagnostic_support' if all(x['status']=='B_diagnostic_pass' for x in row['B_checks'].values()) else 'visual_only_or_partial_B_support'
                results.append(row)
                print(name,v,proposed,row['assessment'],flush=True)
    payload={'divisors_TU':d.DIVISORS,'source_sha256':p['source_sha256'],'sample_interval_TU':.1,
             'visual_review':'60 early/medium curves plus 10 full ALK and 10 full Cocean curves inspected',
             'policy':'round UP upper end of manually assessed initial-growth-ending range; never round failed B into confirmation',
             'status':'proposals for user review; not a production period matrix', 'results':results}
    (d.OUT/'visual_proposals.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# 5000 TU约数分档：原始曲线目检与B/C复核','',
           '时间从参数扰动开始计，单位TU；使用已有完整20000 TU响应重新测算，没有重新积分。','',
           '## 结论和边界','',
           '- 按5000 TU的正整数约数理解，全部档位：'+', '.join(map(str,d.DIVISORS))+'。',
           '- **以下是视觉辅助“准饱和建议档位”，不是全部通过B检验的最终饱和点。**所指的是初始增长及明显过冲基本结束、开始围绕近似水平波动；并不要求之后每个点不再波动。',
           '- 视觉估计先给大致范围，再将范围上限向上取最近约数。大致范围是人工目检判断，不是统计置信区间；分档不能增加原数据的信息量。',
           '- B仍独立检查均值、振幅、趋势与后续变化。符号†表示所选档位至少一种B设置未通过或无可靠参考，只能保留视觉候选；无†表示四种B设置在该档位通过诊断，也不是独立重复实验的验证。',
           '- 无法在≤5000 TU明确划定的项写“未定”，不压到5000。没有修改MCPE方案、参数更新周期、1000 TU入场间隔或敏感性前十名单。','']
    for group,variables,title in [(b.WATER,['x2','w','TL'],'水循环参数'),(b.CARBON,['Catm','Cocean','ALK'],'碳循环参数')]:
        lines += [f'## {title}','','| 参数 | '+' | '.join(variables)+' |','|---|---:|---:|---:|']
        for name in group:
            cells=[]
            for v in variables:
                r=next(x for x in results if x['parameter']==name and x['variable']==v)
                cells.append('未定' if r['visual_divisor_proposal_TU'] is None else str(r['visual_divisor_proposal_TU'])+('†' if r['assessment']=='visual_only_or_partial_B_support' else ''))
            lines.append('| '+name+' | '+' | '.join(cells)+' |')
        lines.append('')
    lines += ['## 为什么不能直接用自动检测出的最早约数','',
              '重新从每个约数向后取三个验证窗时，一些w或TL在2–8 TU就通过。目检显示这些点仍在增长，原因是较宽的前向窗口把增长段与后面的平台一起纳入统计，无法定位到窗口起点。反过来，旧版用固定不重叠窗的边界又会将候选推迟。因此两类自动起点都不直接当作物理饱和点；本次另列视觉建议并逐档复核，未修改B失败标记。','',
              '## 需要特别保留的差异','',
              '- c28–Catm的早期过冲在约50–70 TU明显，随后回落，100 TU比40–50 TU更保守。',
              '- c20和c29的Cocean不仅有几十TU内的快速响应，完整曲线前数千TU还存在水平抬升，因此视觉建议5000 TU，而不是只按第一次变缓选50 TU。它们仍缺足够B参考，5000不是已确认测量值。',
              '- c30–Cocean和c30–ALK在5000 TU之后仍有慢变化，当前不强行给≤5000 TU单一档位。',
              '- ALK其余档位只描述初始主要增长结束的大致尺度；原B参考长度不足的问题仍然存在，约数化没有解决这个限制。','',
              '## 逐项原始记录','','| 参数–变量 | 视觉大致范围 | 建议约数 | B基准 | 半窗 | 双窗 | 尾段25% | C描述性转折 |',
              '|---|---|---:|---|---|---|---|---:|']
    translate={'reference_unavailable':'参考不足/漂移','local_joint_features_failed':'局部不通过',
               'later_followup_failed':'后续不通过','B_diagnostic_pass':'通过','insufficient_future':'时长不足'}
    for r in results:
        interval=r['subjective_visual_range_TU'];checks=r['B_checks'];tau=r['C_descriptive_turn_TU']
        vals=[translate.get(checks.get(k,{}).get('status'),'—') for k in ['base','half_window','double_window','last_quarter_reference']]
        lines.append('| '+r['parameter']+'–'+r['variable']+' | '+('未定' if interval is None else f'{interval[0]}–{interval[1]}')+' | '+str(r['visual_divisor_proposal_TU'] or '未定')+' | '+' | '.join(vals)+' | '+('—' if tau is None else f'{tau:.1f}')+' |')
    lines+=['','核查图全部保留0.1 TU原始点，无时间平滑或额外抽稀。诊断图为工作用PNG，不是最终论文排版。','']
    (d.OUT/'5000约数分档建议与复核.md').write_text('\n'.join(lines),encoding='utf-8')
    print('ALL_SETTINGS_PASS_AT_PROPOSAL',sum(r['assessment']=='visual_proposal_with_B_diagnostic_support' for r in results))


if __name__=='__main__':main()

"""独立部署20个参数重测任务；凭据仅从交互输入读取。"""
from pathlib import Path
import sys, getpass, json, hashlib
import paramiko
BASE=Path(__file__).resolve().parent
REMOTE='/public/home/hou/wyh/MCPE26.0/saturation_remeasure_20260911'
FILES=['SaturationRemeasure.f90','RKmethod.f90','guide_v2.py','analyze_one.py','reference_sensitivity.txt','run.pbs']

def run(c, cmd):
    _,out,err=c.exec_command(cmd,timeout=120)
    txt=out.read().decode('utf-8','replace'); errors=err.read().decode('utf-8','replace')
    print(txt,flush=True)
    if errors: print(errors,flush=True)
    if out.channel.recv_exit_status(): raise RuntimeError('Remote command failed')
    return txt

def main():
    c=paramiko.SSHClient();c.load_system_host_keys();c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect('222.195.137.80',username='hou',password=getpass.getpass('New HPC password: '),timeout=30,look_for_keys=False,allow_agent=False)
    try:
        action=sys.argv[1]
        if action=='deploy':
            run(c,f'test ! -e {REMOTE}/SUBMITTED && mkdir -p {REMOTE}/logs {REMOTE}/smoke')
            with c.open_sftp() as s:
                for f in FILES: s.put(str(BASE/f),REMOTE+'/'+f)
            result=run(c,f'''set -eu
cd {REMOTE}
gfortran -O3 -ffree-line-length-none -c RKmethod.f90
gfortran -O3 -ffree-line-length-none SaturationRemeasure.f90 RKmethod.o -o saturation_remeasure
bash -n run.pbs
cd smoke
SAT_SLOT=1 SENS_SMOKE=1 ../saturation_remeasure
test "$(stat -c %s saturation_kappa.bin)" -eq 360000
cd ../logs
qsub -t 1-20 {REMOTE}/run.pbs > ../SUBMITTED
cat ../SUBMITTED
''')
            (BASE/'submission.json').write_text(json.dumps({'remote':REMOTE,'output':result,
                'files':{f:hashlib.sha256((BASE/f).read_bytes()).hexdigest() for f in FILES}},indent=2),encoding='utf-8')
        elif action=='status':
            run(c,f'''qstat -u hou || true
find {REMOTE}/results -maxdepth 2 -name READY -print 2>/dev/null || true
find {REMOTE}/results -maxdepth 2 -name FAILED -print 2>/dev/null || true
tail -n 3 {REMOTE}/logs/SatNew20.o* 2>/dev/null || true''')
        elif action=='collect_raw':
            names=['kappa','c1','b','sigma','c13','c2','lambda','c4','c12','c11',
                   'c24','c16','c20','c29','c18','c30','c28','c19','c22','c23']
            with c.open_sftp() as s:
                for slot,name in enumerate(names,1):
                    dest=BASE/'results'/str(slot)/('saturation_'+name+'.bin')
                    audit=json.loads((dest.parent/'audit.json').read_text(encoding='utf-8'))
                    if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()==audit['binary_sha256']:
                        print('Verified cached',name,flush=True);continue
                    s.get(REMOTE+'/results/'+str(slot)+'/'+dest.name,str(dest))
                    assert dest.stat().st_size==14400000
                    assert hashlib.sha256(dest.read_bytes()).hexdigest()==audit['binary_sha256']
                    print('Raw verified',name,flush=True)
        elif action=='collect':
            with c.open_sftp() as s:
                for slot in range(1,21):
                    remote=REMOTE+'/results/'+str(slot)
                    s.stat(remote+'/READY')
                    dest=BASE/'results'/str(slot);dest.mkdir(parents=True,exist_ok=True)
                    for f in ['audit.json','curves.npz','sensitivity_W20_C500.txt']:
                        s.get(remote+'/'+f,str(dest/f))
                    print('Downloaded',slot,flush=True)
        else: raise ValueError(action)
    finally: c.close()

if __name__=='__main__':main()

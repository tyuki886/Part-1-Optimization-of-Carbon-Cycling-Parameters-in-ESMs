"""只整理饱和点测量表和数值检查，不绘图、不修改MCPE方案。"""
import json
from collections import Counter
import numpy as np
import bc_stability as b

p=b.OUT/'results.json'
payload=json.loads(p.read_text(encoding='utf-8'))
rows=payload['results']
assert len(rows)==160
assert len({(r['parameter'],r['variable']) for r in rows})==160
main=[r for r in rows if (r['parameter'] in b.WATER and r['variable'] in ['x2','w','TL']) or
                         (r['parameter'] in b.CARBON and r['variable'] in ['Catm','Cocean','ALK'])]
assert len(main)==60

# Numerical validation on synthetic inputs; not experimental observations.
t=np.arange(1,10001)*.1
y=2+3*np.minimum(t,60)+.002*np.maximum(t-60,0)
fit=b.segmented(y,1000,.3)
assert abs(fit['tau_TU']-60)<.11
np.testing.assert_allclose(fit['coefficients_a_b1_b2'],[2,3,.002],rtol=1e-7,atol=1e-7)
f=b.features(y,20)
np.testing.assert_allclose(f[0,2],6,atol=1e-10)
assert b.b_estimate(np.ones(100),1000,1)['status']=='reference_too_short'
rng=np.random.default_rng(34)
z=rng.normal(size=20000)
tests={}
for label,data in [('stationary',10+z),('linear_drift',10+z+np.arange(20000)*.002),
                   ('increasing_amplitude',10+z*np.linspace(1,20,20000)),
                   ('oscillatory_stationary',10+z+2*np.sin(np.arange(20000)*2*np.pi/20))]:
    tests[label]=b.b_estimate(data,20,44)['status']
assert tests['stationary']=='provisionally_stable'
assert tests['linear_drift']=='reference_drift_detected'
assert tests['increasing_amplitude']=='reference_drift_detected'

status={'reference_too_short':'参考窗不足','reference_effective_blocks_too_few':'有效参考块不足',
        'reference_drift_detected':'尾段检出漂移','provisionally_stable':'B候选',
        'candidate_but_later_shift_or_insufficient_followup':'后续复核未通过',
        'no_three_window_candidate':'无连续三窗候选'}
def fmt_interval(a):
    return '—' if a is None else f'{a[0]:.1f}–{a[1]:.1f}'
def cell(r):
    a=r['B']['accepted_interval_TU']
    if a is None:
        return status[r['B']['status']]
    return fmt_interval(a)+(' *' if not r['B_all_checks_passed'] else '')

lines=['# 饱和点测量结果：B主判据，C辅助复核','',
       '本次只测量，不绘图、不改MCPE方案、不提交新作业。时间单位均为TU，以参数扰动开始为0 TU，不是模式总积分时间。','',
       '## 结果口径','',
       '- 使用20个参数各自的完整20000 TU、0.1 TU采样的原始集合标准差响应。40成员为单背景态的确定性对称参数扰动，不是10个独立seed。',
       '- 下表数字是B基准窗口识别的候选进入时间格，不是已经精确定位的饱和点，也不是95%置信区间。',
       '- “*”表示半窗、双窗或末四分之一参考检查至少一项未通过。不带星也不意味着不同窗口给出的时间完全一致；完整敏感性范围列在后表。',
       '- “尾段检出漂移”是当前统计诊断结果，不等于物理上一定存在很大的变化。参考窗不足也不等于模型永远不饱和。',
       '- C的增长转折可以早于B的统计稳定；C不能绕过B参考失败替代填入“饱和时间”。','']
for group,variables,title in [(b.WATER,['x2','w','TL'],'水循环参数'),(b.CARBON,['Catm','Cocean','ALK'],'碳循环参数')]:
    lines += [f'## {title}','','| 参数 | '+' | '.join(variables)+' |','|---|---|---|---|']
    for name in group:
        rr=[next(r for r in main if r['parameter']==name and r['variable']==v) for v in variables]
        lines.append('| '+name+' | '+' | '.join(cell(r) for r in rr)+' |')
    lines.append('')

lines+=['## 逐项复核明细','','“复核范围”是通过各设置得到的候选区间包络；它不是统计置信区间，也不包含未通过设置。',
        'C值即使有数字也只是描述性转折点。C落在B一个窗口以内仅说明该分辨率不足以区分，不能称为独立验证一致。','',
        '| 参数–变量 | B窗口宽度 | B候选 | 各设置复核范围 | 四设置均通过 | C全程拟合转折 | C复核说明 |',
        '|---|---:|---|---|---|---:|---|']
resolved=0
for r in main:
    accepted=[a['accepted_interval_TU'] for a in [r['B'],*r['B_checks'].values()]]
    intersect=None
    if all(x is not None for x in accepted):
        lo=max(x[0] for x in accepted);hi=min(x[1] for x in accepted)
        if lo<=hi+1e-10:
            intersect=[lo,hi];resolved+=1
    r['B_all_setting_time_intersection_TU']=intersect
    c=r['C'];tau=c['fits'][-1].get('tau_TU')
    if c['comparison']=='agrees_within_one_B_window':
        note='差异小于B窗宽；非精确一致'
    elif c['comparison']=='disagrees_with_B':
        note='与B相差超过一窗'
    elif c['status']=='no_stable_reference_to_validate_plateau_slope':
        note='缺稳定参考，不可确认为平台'
    elif c['status']=='turning_point_depends_on_fit_duration':
        note='随拟合时长变化'
    else:
        note='B未确认；仅描述性转折'
    lines.append('| '+r['parameter']+'–'+r['variable']+f" | {r['B']['window_TU']:.1f} | "+cell(r)+' | '+
                 fmt_interval(r['B_window_reference_sensitivity_envelope_TU'])+' | '+('是' if r['B_all_checks_passed'] else '否')+
                 ' | '+('—' if tau is None else f'{tau:.1f}')+' | '+note+' |')

counts=dict(Counter(r['B']['status'] for r in main))
lines+=['','## 本轮判断','',
        f"60个主组合中，{counts.get('provisionally_stable',0)}个通过B基准检查，{sum(r['B_all_checks_passed'] for r in main)}个在四种设置下都得到候选。",
        f'但只有{resolved}个组合的四种候选时间格存在共同交集，而且本轮这两项仅为边界相接，不能据此声称得到精确饱和点。多数时间定位明显依赖验证窗，不能把“各设置都有候选”写成“饱和时间稳定”。',
        '10个碳循环参数对应ALK全部参考窗不足。本轮没有得到可可靠确认的ALK饱和点。',
        '因此这是一张候选与未定项的测量表，不是一套可直接写入生产参数周期的最终饱和时间。','',
        '## 本次操作性判据（便于复算）','',
        '1. 从最后10000 TU估计线性去趋势后的初始正自相关积分尺度g；去趋势仅用于选窗，统计检验仍用未去趋势的原值。W=max(2 TU,5g)，向上取整到0.1 TU。相同公式用于所有变量–参数，不人为逐曲线挑窗口。',
        '2. 每个不重叠W窗计算原始S的均值、log(时间标准差)、线性趋势乘W。最后半程至少30窗；对这三个窗口统计量再估计残余相关，以最大尺度两倍设置循环块重采样长度，参考至少容纳10个重采样块。',
        '3. 用399次循环块重采样检验参考段四季度差异与全段趋势的联合最大统计量；诊断p<0.05则拒绝作稳定参考。这是探索性单组合诊断，不是160项多重检验校正后的显著性结论。',
        '4. 对三个特征按参考中位数和MAD标准化，取联合最大偏离的经验95%分位作为正常参考范围；首次连续三窗通过给候选起始时间格。',
        '5. 候选之后分四个长时段，对三个统计量的均值偏移做联合块重采样复核。该检查可识别持续偏移，但不保证检出所有短暂反弹。',
        '6. W/2、2W、最后25%参考重新判断；有局部候选但后续未通过的不保留为B基准候选。',
        '7. C对全部原始点拟合连续两段线性模型a+b1*min(t,tau)+b2*max(t-tau,0)，分别使用10000、15000、20000 TU拟合时长。C最短阶段为3个原始样点，独立于B的W。边界、非增长、尾段趋势不适合平台或随时长明显变化均标记。',
        '8. 上述窗口倍率、参考长度、95%范围、三窗和复核规则均为此次实现的操作性选择，不宣称来自Yang论文的原始算法；数据点密度不等于有效独立样本数。未对新背景态/独立seed重复，结果只覆盖现有记录。','',
        '统计依据参考：[NIST关于稳定过程](https://www.itl.nist.gov/div898/handbook/ppc/section4/ppc45.htm)、[PyMBAR关于相关时间和有效样本](https://pymbar.readthedocs.io/en/latest/timeseries.html)。本次B/C组合规则是自定诊断，不是上述文献提供的一整套算法。','']
(b.OUT/'饱和点测量表_B主_C复核.md').write_text('\n'.join(lines),encoding='utf-8')
audit={'source_files_verified':len(payload['source_sha256']),'parameter_variable_pairs':160,'main_pairs':60,
       'known_breakpoint_TU':fit['tau_TU'],'synthetic_checks':tests,'main_B_status':counts,
       'all_four_B_settings_pass':sum(r['B_all_checks_passed'] for r in main),
       'time_bins_intersect_across_all_settings':resolved,'no_figures_created':True,'no_new_model_runs':True}
(b.OUT/'measurement_validation.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(audit,ensure_ascii=False))
print(b.OUT/'饱和点测量表_B主_C复核.md')

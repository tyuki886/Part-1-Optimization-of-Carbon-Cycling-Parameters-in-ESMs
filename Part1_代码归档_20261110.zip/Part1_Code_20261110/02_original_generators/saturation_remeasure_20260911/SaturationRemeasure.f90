! 分窗口敏感性：19水循环参数20 TU，14碳循环参数500 TU，覆盖全部8观测变量。
! 2026-08-26 新基本盘：12 常数（c25/E/od/spd/ss/sm/slm/old/gamma/sls/om/olm）不测量。
! 参数顺序 = MCPE42.f90 45 参数行号去掉 12 常数后的 33 个可估计参数。
! 每个原生步(0.01 TU)累加集合标准差；0.1 TU保存一条诊断trace，不用于替代原生步均值。
program SaturationRemeasure
    use RKmethod
    implicit none

    integer, parameter :: nens=40, nparam=33, nout=8
    integer(kind=8), parameter :: spinup_steps=1000000_8       ! 10,000 TU
    integer(kind=8), parameter :: water_steps=2000_8, carbon_steps=50000_8
    integer(kind=8), parameter :: trace_stride=10_8
    integer(kind=8) :: long_steps=2000000_8
    integer, parameter :: selected(20)=[2,4,3,1,25,5,33,18,7,24,31,27,10,15,9,16,14,29,12,30]
    integer :: slot, first_slot, last_slot
    character(64) :: setting
    integer(kind=8) :: it, absolute_it, sens_steps
    integer :: ip, ie, iy, unit_id, trace_unit, nsample
    real(kind=dp) :: x_spin(10), x_ens(10,nens), values(nens,nout)
    real(kind=dp) :: mean_y(nout), std_y(nout), sum_std(nout), sens(nparam,nout)
    real(kind=dp) :: perturb(nens), amplitude
    real(kind=dp) :: previous(10)
    integer :: parameter_limit, env_status
    integer,parameter :: carbon_rows(14)=[9,10,11,12,14,15,16,17,35,36,37,38,39,40]
    character(8)::group_name,smoke
    character(len=96) :: filename
    ! MCPE42 行号（45 参数去掉 12 常数：13,18,19,20,21,22,23,24,41,43,44,45）
    integer, parameter :: prow(nparam) = [ &
        1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17, &
        25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,42]
    character(len=12), parameter :: pname(nparam) = [character(len=12) :: &
        'sigma','kappa','b','c1','c2','c6','c12','c15','c18','c20','c21','c22', &
        'c26','c28','c29','c30', &
        'c3','c4','c5','c7','c8','c9','c10','c11','c13','c14', &
        'c16','c17','c19','c23','c24','c27','lambda']

    parameter_limit=nparam
    call get_environment_variable('SENS_SMOKE',smoke,status=env_status)
    if(env_status==0.and.trim(smoke)=='1')parameter_limit=1
    call get_environment_variable('SAT_SLOT',setting,status=env_status)
    if(env_status/=0)error stop 'SAT_SLOT is required (1..20)'
    read(setting,*)first_slot
    if(first_slot<1.or.first_slot>20)error stop 'Invalid SAT_SLOT'
    last_slot=first_slot
    if(parameter_limit==1)long_steps=50000_8
    call reset_all_46()
    x_spin=0.0_dp; x_spin(2)=1.0_dp
    do it=1,spinup_steps
        call adv_true_state(x_spin,it,10)
    end do

    ! 对称 0.25%...5% 扰动（与 canonical20 相同分布，排名可比）
    do ie=1,nens
        amplitude=0.0025_dp*real((ie+1)/2,dp)
        if (mod(ie,2)==1) amplitude=-amplitude
        perturb(ie)=amplitude
    end do

    sens=0.0_dp
    open(newunit=unit_id,file='sensitivity_W20_C500.txt',status='replace',action='write')
    write(unit_id,'(A)') '# Mean ensemble std: WATER (0,20] TU; CARBON (0,500] TU; native dt=0.01 TU; ensemble=40; ddof=1'
    write(unit_id,'(A)') '# index name row group window_TU samples x1 x2 x3 w TL Catm Cocean ALK'

    do slot=first_slot,last_slot
        ip=selected(slot)
        sens_steps=water_steps
        group_name='WATER'
        if(any(carbon_rows==prow(ip)))then
            sens_steps=carbon_steps
            group_name='CARBON'
        endif
        do ie=1,nens
            x_ens(:,ie)=x_spin
        end do
        sum_std=0.0_dp
        nsample=0
        write(filename,'("saturation_",A,".bin")') trim(pname(ip))
        open(newunit=trace_unit,file=trim(filename),status='replace',access='stream',form='unformatted',action='write')

        do it=1,long_steps
            absolute_it=spinup_steps+it
            do ie=1,nens
                call reset_all_46()
                call set_one_parameter(ip, perturb(ie))
                previous=x_ens(:,ie)
                call adv_true_state(x_ens(:,ie),absolute_it,10)
                if(.not.all(abs(x_ens(:,ie))<=huge(1._dp)))error stop 'Nonfinite state'
                if(all(x_ens(1:5,ie)==previous(1:5)).and.all(x_ens(7:10,ie)==previous(7:10))) &
                    error stop 'Integrator rollback or exact stagnation'
            end do
            call extract_outputs(x_ens,values)
            do iy=1,nout
                mean_y(iy)=sum(values(:,iy))/real(nens,dp)
                std_y(iy)=sqrt(sum((values(:,iy)-mean_y(iy))**2)/real(nens-1,dp))
            end do
            if(it<=sens_steps)then
                sum_std=sum_std+std_y
                nsample=nsample+1
            endif
            if (mod(it,trace_stride)==0_8) then
                write(trace_unit) real(it,dp)*0.01_dp,std_y
            end if
        end do
        sens(ip,:)=sum_std/real(sens_steps,dp)
        if(nsample/=sens_steps)error stop 'Incorrect sample count'
        write(unit_id,'(I3,1X,A12,I3,1X,A8,F9.2,I9,8(1X,ES18.8))') &
            ip,trim(pname(ip)),prow(ip),trim(group_name),real(sens_steps,dp)*0.01_dp,nsample,sens(ip,:)
        close(trace_unit)
        write(*,'(A,I3,1X,A,1X,A,F9.2)') 'done',ip,trim(pname(ip)),trim(group_name),real(sens_steps,dp)*0.01_dp
        flush(6)
    end do
    close(unit_id)

contains

    subroutine extract_outputs(x,y)
        real(kind=dp), intent(in) :: x(10,nens)
        real(kind=dp), intent(out) :: y(nens,nout)
        y(:,1)=x(1,:); y(:,2)=x(2,:); y(:,3)=x(3,:); y(:,4)=x(4,:)
        y(:,5)=x(7,:); y(:,6)=x(8,:); y(:,7)=x(9,:); y(:,8)=x(10,:)
    end subroutine extract_outputs

    ! ip 按新 33 参数顺序（45 行号去 12 常数后的压缩索引）
    subroutine set_one_parameter(index, delta)
        integer,intent(in)::index
        real(kind=dp),intent(in)::delta
        select case(index)
        case(1);  sigma=sigma*(1.0_dp+delta)
        case(2);  kappa=kappa*(1.0_dp+delta)
        case(3);  b=b*(1.0_dp+delta)
        case(4);  c1=c1*(1.0_dp+delta)
        case(5);  c2=c2*(1.0_dp+delta)
        case(6);  c6=c6*(1.0_dp+delta)
        case(7);  c12=c12*(1.0_dp+delta)
        case(8);  c15=c15*(1.0_dp+delta)
        case(9);  c18=c18*(1.0_dp+delta)
        case(10); c20=c20*(1.0_dp+delta)
        case(11); c21=c21*(1.0_dp+delta)
        case(12); c22=c22*(1.0_dp+delta)
        case(13); c26=c26*(1.0_dp+delta)
        case(14); c28=c28*(1.0_dp+delta)
        case(15); c29=c29*(1.0_dp+delta)
        case(16); c30=c30*(1.0_dp+delta)
        case(17); c3=c3*(1.0_dp+delta)
        case(18); c4=c4*(1.0_dp+delta)
        case(19); c5=c5*(1.0_dp+delta)
        case(20); c7=c7*(1.0_dp+delta)
        case(21); c8=c8*(1.0_dp+delta)
        case(22); c9=c9*(1.0_dp+delta)
        case(23); c10=c10*(1.0_dp+delta)
        case(24); c11=c11*(1.0_dp+delta)
        case(25); c13=c13*(1.0_dp+delta)
        case(26); c14=c14*(1.0_dp+delta)
        case(27); c16=c16*(1.0_dp+delta)
        case(28); c17=c17*(1.0_dp+delta)
        case(29); c19=c19*(1.0_dp+delta)
        case(30); c23=c23*(1.0_dp+delta)
        case(31); c24=c24*(1.0_dp+delta)
        case(32); c27=c27*(1.0_dp+delta)
        case(33); lambda=lambda*(1.0_dp+delta)
        end select
    end subroutine set_one_parameter
end program SaturationRemeasure

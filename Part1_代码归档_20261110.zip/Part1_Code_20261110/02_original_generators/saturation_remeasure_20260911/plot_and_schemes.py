"""新重测结果的18面板图与MCPE6–20入场图；只交付PNG，不替换历史方案。"""
from pathlib import Path
import json, hashlib
from collections import Counter
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, Patch
from PIL import Image
from analyze_one import WATER, CARBON

BASE=Path(__file__).resolve().parent
OUT=BASE/'figures';OUT.mkdir(exist_ok=True)
VARS=['x1','x2','x3','w','TL','Catm','Cocean','ALK']
ROW=dict(zip(WATER+CARBON,[2,4,3,1,33,5,42,26,7,32,39,35,10,16,9,17,15,37,12,38]))
font_manager.fontManager.addfont(str(BASE/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':13,
                     'axes.titlesize':14,'xtick.labelsize':11,'ytick.labelsize':11,'mathtext.fontset':'stix'})

def main():
    records=[];curves={};sources={};trace_checks={}
    for slot,name in enumerate(WATER+CARBON,1):
        folder=BASE/'results'/str(slot)
        audit=json.loads((folder/'audit.json').read_text(encoding='utf-8'))
        assert audit['parameter']==name and audit['native_sensitivity_exact_match']
        assert audit['water']==WATER and audit['carbon']==CARBON
        assert audit['rows']==200000 and audit['duration_TU']==20000
        d=np.load(folder/'curves.npz')['data']
        assert np.isfinite(d).all() and d.shape[1]==9
        old=np.loadtxt(BASE.parent/'sensitivity_split_windows'/'results'/('sensitivity_trace_'+name+'.txt'))
        np.testing.assert_allclose(d[:len(old),0],old[:,0],rtol=0,atol=1e-10)
        np.testing.assert_allclose(d[:len(old),1:],old[:,1:],rtol=5.1e-9,atol=1e-14)
        trace_checks[name]={'points':len(old),'max_abs_difference':float(np.abs(d[:len(old),1:]-old[:,1:]).max()),
                            'comparison':'within reference text rounding (9 significant digits)'}
        curves[name]=d;records.extend(audit['results']);sources[name]=audit
    lookup={(r['param'],r['var']):r for r in records}
    assert len(lookup)==160
    colors=['#1f77b4','#ff7f0e','#2ca02c','#d62728']
    fig,axes=plt.subplots(3,6,figsize=(26,13),layout='constrained')
    panels=[]
    for side,params in enumerate([WATER,CARBON]):
        variables=['x2','w','TL'] if side==0 else ['Catm','Cocean','ALK']
        limits=[20,50,50] if side==0 else [100,100,2000]
        for row,subset in enumerate([params[:3],params[3:6],params[6:]]):
            for j,var in enumerate(variables):
                ax=axes[row,side*3+j];xmax=limits[j]
                for k,name in enumerate(subset):
                    d=curves[name];mask=d[:,0]<=xmax
                    t=np.r_[0.,d[mask,0]];y=np.r_[0.,d[mask,VARS.index(var)+1]]
                    r=lookup[name,var];tau=r['t_final']
                    suffix='*' if r['requires_review'] else ''
                    label=f'{name} ({tau:.1f} TU){suffix}' if tau is not None else f'{name} (NA)*'
                    line,=ax.plot(t,y,color=colors[k],lw=1.5,label=label)
                    np.testing.assert_array_equal(line.get_ydata()[1:],d[mask,VARS.index(var)+1])
                    if tau is not None and tau<=xmax:
                        ax.plot([tau],[np.interp(tau,t,y)],'o',ms=3.5,color=colors[k],label='_nolegend_')
                ax.set_xlim(0,xmax);ax.set_xlabel('Time (TU)');ax.set_ylabel(var+' standard deviation')
                ax.set_title(var);ax.grid(alpha=.4,ls='--');ax.legend(loc='upper left',fontsize=9,framealpha=.9)
                panels.append({'row':row,'col':side*3+j,'variable':var,'parameters':subset,'xmax_TU':xmax})
    fig.suptitle('Parameter sensitivity response and quasi-saturation time',fontsize=18)
    fig.supxlabel('Markers denote estimated quasi-saturation times; * indicates a result requiring review.',fontsize=12)
    assert len(fig.axes)==18
    fig.savefig(OUT/'saturation_new_top20_18panels.png',dpi=300,facecolor='white')
    plt.close(fig)

    schemes=[]
    for ns in range(6,21):
        names=WATER[:(ns+1)//2]+CARBON[:ns//2]
        schemes.append({'scheme':f'MCPE{ns}','n_water':(ns+1)//2,'n_carbon':ns//2,
                        'parameters':[{'parameter':p,'row45':ROW[p],'group':'water' if p in WATER else 'carbon',
                                       'entry_TU':20000+k*1000} for k,p in enumerate(names)]})
    for s in schemes:
        assert len(s['parameters'])==s['n_water']+s['n_carbon']
        assert len({p['row45'] for p in s['parameters']})==len(s['parameters'])
        np.testing.assert_array_equal(np.diff([p['entry_TU'] for p in s['parameters']]),1000)
    fig=plt.figure(figsize=(19,11),layout='constrained')
    gs=fig.add_gridspec(2,1,height_ratios=[12,1.5],hspace=.12)
    ax=fig.add_subplot(gs[0]);palette={'water':'#DC6E4B','carbon':'#4C7EDB'}
    for row,s in enumerate(schemes):
        y=14-row
        for p in s['parameters']:
            x=p['entry_TU']/1000
            ax.add_patch(Rectangle((x,y-.34),1,.68,facecolor=palette[p['group']],edgecolor='white',linewidth=1))
            ax.text(x+.5,y,p['parameter'],ha='center',va='center',color='white',fontsize=9,fontweight='bold')
    ax.set_xlim(20,40);ax.set_ylim(-.75,15.0)
    ax.set_yticks(range(15),[f'MCPE{n}' for n in range(20,5,-1)])
    ax.set_xticks(range(20,41,2),[str(n*1000) for n in range(20,41,2)])
    ax.set_xlabel('Time (TU)');ax.set_ylabel('Scheme');ax.set_title('MCPE entry timeline',fontsize=18,pad=12)
    ax.set_axisbelow(True);ax.grid(axis='x',color='#e6e6e6')
    ax.legend(handles=[Patch(facecolor=palette[g],label=g.capitalize()+' cycle parameters') for g in palette],loc='upper right',fontsize=10)
    phase=fig.add_subplot(gs[1]);phase.set_xlim(0,200);phase.set_ylim(0,1.1)
    phases=[(0,10,'#A7A7A7','Spin-up'),(10,10,'#5E8FD2','Pure CDA'),
            (20,20,'#DC6E4B','Parameter entry'),(40,160,'#D9A90D','Evaluation; state assimilation and parameter estimation continue')]
    for start,width,color,label in phases:
        phase.add_patch(Rectangle((start,.18),width,.42,facecolor=color,edgecolor='white'))
        phase.text(start+width/2,.7,label,ha='center',va='bottom',fontsize=8 if width<=20 else 11,rotation=0)
    phase.set_xticks([0,10,20,40,100,200],['0','10000','20000','40000','100000','200000'])
    phase.tick_params(axis='x',labelsize=9,length=0)
    phase.set_yticks([]);phase.set_xlabel('Time (TU)')
    for spine in phase.spines.values():spine.set_visible(False)
    fig.savefig(OUT/'MCPE6-20_new_top20_entry_timeline.png',dpi=300,facecolor='white')
    plt.close(fig)

    # 周期草案保留既有通道掩码，但绝不把入场间隔当作更新周期。
    candidates=[]
    for name in WATER+CARBON:
        active=VARS[:5] if name in WATER else VARS[5:]
        candidates.append({'parameter':name,'row45':ROW[name],
            'candidate_update_intervals_TU':{var:lookup[name,var]['candidate_interval_TU'] if var in active else 0 for var in VARS},
            'requires_review_variables':[var for var in active if lookup[name,var]['requires_review']],
            'status':'DRAFT_NOT_AUTHORIZED_FOR_ASSIMILATION'})
    config={'version':'new_top20_saturation_20260911','water':WATER,'carbon':CARBON,'schemes':schemes,
            'entry_interval_TU':1000,'parameter_update_policy':'pending review of measured tau; not uniform 1000 TU',
            'candidate_cycle_rule':'ceil(tau) TU; candidate only, not a verified optimum',
            'observation_intervals_TU':dict(zip(VARS,[.04,.04,.04,.2,.2,1,4,20])),
            'scheme_scope':'7obs/8obs use full scheme list; 5obs estimates water subset only',
            'update_candidates':candidates,'assimilation_submitted':False}
    (BASE/'MCPE_schemes_new_top20.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    (BASE/'tau_new_top20.json').write_text(json.dumps({'water':WATER,'carbon':CARBON,'results':records,
        'status_counts':dict(Counter(r['status'] for r in records))},ensure_ascii=False,indent=2),encoding='utf-8')
    text=['# 新前十参数的准饱和时间与MCPE方案','',
          '1000 TU仅为入场间隔。此次只重测响应和更新方案配置；同化实验未提交。',
          '水循环排名依据x2的(0,20] TU平均集合标准差；碳循环依据Catm的(0,500] TU。',
          '40成员确定性对称±0.25%至±5%，不是5%标准差的高斯扰动。',
          '20参数长轨迹均为扰动后20000 TU，dt=0.01 TU；图线保存间隔0.1 TU。',
          '指南法v2沿用既有工程阈值，并非作者原始代码的逐行复现；S的尾段归一化量不能称为参数—观测协方差信噪比。','',
          '## 入场方案','', '| 方案 | 水循环参数 | 碳循环参数 | 最后入场TU |','|---|---|---|---:|']
    for s in schemes:
        text.append('| '+s['scheme']+' | '+', '.join(WATER[:s['n_water']])+' | '+', '.join(CARBON[:s['n_carbon']])+' | '+str(s['parameters'][-1]['entry_TU'])+' |')
    text+=['','## 准饱和时间（TU）','',
           '下表星号为冲突或弱响应，不能静默作为可靠周期。数值回退与三次拟合状态均保留在JSON。',
           '| 参数 | x1 | x2 | x3 | w | TL | Catm | Cocean | ALK |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for name in WATER+CARBON:
        vals=[]
        for var in VARS:
            r=lookup[name,var];v='NA' if r['t_final'] is None else f"{r['t_final']:.2f}"
            vals.append(v+('*' if r['requires_review'] else ''))
        text.append('| '+name+' | '+' | '.join(vals)+' |')
    text+=['','## 更新周期尚待确定','',
           '候选表提供ceil(tau)，保留原先水参数用x1/x2/x3/w/TL、碳参数用Catm/Cocean/ALK的通道规则。',
           '该通道掩码不是原论文的跨分量完整周期矩阵；若要改变，应单独明确实验版本。',
           '本次不自动裁定冲突、不提交参数估计作业、不声称新方案已优于旧方案。']
    (BASE/'新MCPE方案与饱和时间.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    manifest=[]
    for path in [OUT/'saturation_new_top20_18panels.png',OUT/'MCPE6-20_new_top20_entry_timeline.png']:
        with Image.open(path) as im:
            assert min(im.size)>3000
            assert all(abs(d-300)<1 for d in im.info.get('dpi',[]))
            preview=im.copy();preview.thumbnail((1800,1800));preview.convert('RGB').save(OUT/(path.stem+'_preview.jpg'),quality=90)
            manifest.append({'name':path.name,'size':im.size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (BASE/'validation.json').write_text(json.dumps({'parameters':20,'response_pairs':160,'main_panels':panels,
         'native_sensitivity_all_exact':True,'trace_reproduction':trace_checks,
         'rendered_curves_checked':60,'schemes':15,'entry_interval_checked':True,
         'figures':manifest,'status_counts':dict(Counter(r['status'] for r in records))},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(OUT),'status_counts':dict(Counter(r['status'] for r in records)),
         'active_conflicts':{c['parameter']:c['requires_review_variables'] for c in candidates if c['requires_review_variables']}},ensure_ascii=False))

if __name__=='__main__':main()

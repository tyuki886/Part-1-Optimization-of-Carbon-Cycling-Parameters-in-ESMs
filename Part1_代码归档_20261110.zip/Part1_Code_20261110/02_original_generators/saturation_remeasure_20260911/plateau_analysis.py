"""持续平台进入与全程整定分开测量；不再用增长率峰值代替饱和。

操作性判据而非原论文算法：后25%均值作参照；不重叠窗口平均；
连续5窗进入±epsilon记为局部平台进入，全程保持另测。所有阈值留痕。
"""
from pathlib import Path
from collections import Counter
import json, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image

BASE=Path(__file__).resolve().parent
OUT=BASE/'plateau_method';OUT.mkdir(exist_ok=True)
WATER=['kappa','c1','b','sigma','c13','c2','lambda','c4','c12','c11']
CARBON=['c24','c16','c20','c29','c18','c30','c28','c19','c22','c23']
VARS=['x1','x2','x3','w','TL','Catm','Cocean','ALK']
WIDTH=dict(zip(VARS,[2,2,2,10,10,20,100,200]))
COLORS=['#1f77b4','#ff7f0e','#2ca02c','#d62728']
font_manager.fontManager.addfont(str(BASE/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':12,
                     'axes.titlesize':14,'xtick.labelsize':10,'ytick.labelsize':10,'mathtext.fontset':'stix'})

def measure(y, dt, width, epsilon=.1, tail_fraction=.25, hold=5):
    n=len(y);T=n*dt;k=int(round(width/dt));assert k>=1
    last=y[int((1-tail_fraction)*n):]
    plateau=float(last.mean())
    if not plateau>0:raise ValueError('Nonpositive reference level')
    drift=float(abs(last[:len(last)//2].mean()-last[len(last)//2:].mean())/plateau)
    quarters=np.array([a.mean() for a in np.array_split(last,4)])
    quarter_deviation=float(np.max(abs(quarters/plateau-1)))
    tail_ok=bool(drift<=epsilon and quarter_deviation<=epsilon)
    count=n//k;bm=y[:count*k].reshape(count,k).mean(1)
    starts=np.arange(count)*width;ends=starts+width
    inside=abs(bm/plateau-1)<=epsilon
    hits=np.flatnonzero(np.convolve(inside.astype(int),np.ones(hold,dtype=int),'valid')==hold)
    candidate=int(hits[0]) if len(hits) else None
    onset=float(starts[candidate]) if candidate is not None and tail_ok else None
    confirm=float(ends[candidate+hold-1]) if onset is not None else None
    outside=np.flatnonzero(~inside)
    global_idx=int(outside[-1]+1) if len(outside) else 0
    enough=global_idx<count and T-starts[global_idx]>=max(hold*width,.1*T)
    global_onset=float(starts[global_idx]) if enough and tail_ok else None
    if not tail_ok:status='reference_not_stable'
    elif onset is None:status='no_sustained_plateau'
    elif global_onset==onset:status='sustained_and_global'
    else:status='local_only_later_departures'
    r={'window_TU':width,'tolerance':epsilon,'tail_fraction':tail_fraction,'hold_windows':hold,
       'reference_mean':plateau,'tail_half_drift_fraction':drift,'tail_quarter_max_deviation':quarter_deviation,
       'tail_reference_stable':tail_ok,'local_plateau_TU':onset,'local_confirmation_TU':confirm,
       'global_settling_TU':global_onset,'global_min_followup_TU':max(hold*width,.1*T),
       'status':status,'block_resolution_TU':width,
       'later_outside_fraction':float((~inside[candidate+hold:]).mean()) if candidate is not None and candidate+hold<len(inside) else None}
    if onset is not None:
        assert np.all(inside[candidate:candidate+hold])
        if candidate>0:assert not any(np.all(inside[j:j+hold]) for j in range(candidate))
    if global_onset is not None:assert np.all(inside[global_idx:])
    return r,starts+width/2,bm

def tests():
    dt=.1;t=np.arange(1,20001)*dt
    y=1-np.exp(-t/10)
    r,_,_=measure(y,dt,1)
    assert 21<=r['local_plateau_TU']<=24 and r['status']=='sustained_and_global'
    linear=t/t[-1];r,_,_=measure(linear,dt,1)
    assert r['status']=='reference_not_stable' and r['local_plateau_TU'] is None
    rebound=y.copy();rebound[(t>500)&(t<600)]=.6
    r,_,_=measure(rebound,dt,1)
    assert r['status']=='local_only_later_departures' and r['global_settling_TU']>=600
    # 单窗误入/短暂交叉不得视为持续平台。
    short=np.full_like(t,.5);short[(t>100)&(t<=101)]=1.;short[t>1500]=1.
    r,_,_=measure(short,dt,1)
    assert r['local_plateau_TU']>=1500
    return ['exponential plateau','persistent drift','later rebound','short false crossing']

def main():
    unit_tests=tests()
    old=json.loads((BASE/'tau_new_top20.json').read_text(encoding='utf-8'))
    old={(r['param'],r['var']):r for r in old['results']}
    rows=[];cache={};sources={}
    for slot,name in enumerate(WATER+CARBON,1):
        folder=BASE/'results'/str(slot);path=folder/('saturation_'+name+'.bin')
        audit=json.loads((folder/'audit.json').read_text(encoding='utf-8'))
        assert hashlib.sha256(path.read_bytes()).hexdigest()==audit['binary_sha256']
        d=np.fromfile(path,dtype='<f8').reshape(-1,9)
        assert d.shape==(200000,9) and np.isfinite(d).all()
        np.testing.assert_allclose(d[:,0],np.arange(1,200001)*.1,rtol=0,atol=1e-10)
        cache[name]=d;sources[name]=audit['binary_sha256']
        for j,var in enumerate(VARS):
            y=d[:,j+1];r,bt,bm=measure(y,.1,WIDTH[var])
            r.update(parameter=name,variable=var,old_growth_peak_TU=old[name,var]['t_final'],
                     old_point_fraction_of_reference=float(np.interp(old[name,var]['t_final'],d[:,0],y)/r['reference_mean']))
            variants=[]
            for eps in [.05,.1,.15]:
                for factor in [.5,1,2]:
                    v,_,_=measure(y,.1,WIDTH[var]*factor,eps)
                    variants.append({k:v[k] for k in ['window_TU','tolerance','local_plateau_TU','global_settling_TU','status']})
            r['sensitivity_checks']=variants
            r['reference_window_checks']=[]
            for fraction in [.2,.5]:
                v,_,_=measure(y,.1,WIDTH[var],.1,fraction)
                r['reference_window_checks'].append({k:v[k] for k in ['tail_fraction','reference_mean','local_plateau_TU','status']})
            rows.append(r)
        print('Analyzed',name,flush=True)
    lookup={(r['parameter'],r['variable']):r for r in rows}
    meta={'method':'sustained plateau entry, with separate full-record settling check',
          'definition':'first run of five nonoverlapping block means inside reference mean +/-10%; reference stability required',
          'reference_window_TU':[15000,20000],'widths_TU':WIDTH,
          'global_definition':'all later block means inside band, minimum followup max(5W,2000 TU)',
          'limitations':['not an inferred optimal assimilation interval','not the original Yang et al. growth-rate criterion',
                        'local entry does not imply permanent settling','window and tolerance choices are operational and tested, not uniquely determined'],
          'sources':sources,'synthetic_tests':unit_tests,'results':rows,'status_counts':dict(Counter(r['status'] for r in rows))}
    (OUT/'plateau_results.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    for view in ['early','full']:
        fig,axes=plt.subplots(3,6,figsize=(26,13),layout='constrained')
        for side,params in enumerate([WATER,CARBON]):
            variables=['x2','w','TL'] if side==0 else ['Catm','Cocean','ALK']
            base_limits=[30,100,100] if side==0 else [300,1000,4000]
            for j,var in enumerate(variables):
                need=max([base_limits[j]]+[1.1*(lookup[p,var]['local_confirmation_TU'] or 0) for p in params])
                unit=10**(int(np.floor(np.log10(need)))-1)
                base_limits[j]=min(20000,np.ceil(need/unit)*unit)
            for group,subset in enumerate([params[:3],params[3:6],params[6:]]):
                for j,var in enumerate(variables):
                    ax=axes[group,side*3+j];xmax=base_limits[j] if view=='early' else 20000
                    # 保持各列同一尺度；早期图不为晚发候选点缩放或隐藏后续离开。
                    for k,name in enumerate(subset):
                        d=cache[name];r=lookup[name,var];color=COLORS[k]
                        _,bt,bm=measure(d[:,VARS.index(var)+1],.1,WIDTH[var])
                        mask=d[:,0]<=xmax
                        if view=='early':
                            ax.plot(np.r_[0,d[mask,0]],np.r_[0,d[mask,VARS.index(var)+1]],color=color,lw=.7,alpha=.22)
                        candidate=r['local_plateau_TU']
                        if r['status']=='reference_not_stable':label=name+' (unstable reference)'
                        elif candidate is None:label=name+' (no sustained entry)'
                        else:label=f'{name} ({candidate:g}–{candidate+WIDTH[var]:g} TU)'+('*' if r['status']!='sustained_and_global' else '')
                        bmask=bt<=xmax
                        line,=ax.plot(bt[bmask],bm[bmask],color=color,lw=1.5,label=label)
                        np.testing.assert_array_equal(line.get_ydata(),bm[bmask])
                        ax.axhline(r['reference_mean'],color=color,lw=.8,ls=':',alpha=.6)
                        if candidate is not None and candidate<=xmax:
                            idx=int(round(candidate/WIDTH[var]))
                            ax.plot([candidate,candidate+WIDTH[var]],[bm[idx],bm[idx]],color=color,lw=3,marker='|',ms=6)
                    ax.set_xlim(0,xmax);ax.set_title(var+f' (W={WIDTH[var]} TU)')
                    ax.set_ylim(bottom=0)
                    if view=='full':ax.set_xticks([0,5000,10000,15000,20000])
                    ax.set_xlabel('Time after perturbation (TU)');ax.set_ylabel(var)
                    ax.grid(alpha=.25,ls='--');ax.legend(loc='upper left',fontsize=8.5,framealpha=.9)
        for row in axes:
            assert [ax.get_ylabel() for ax in row]==['x2','w','TL','Catm','Cocean','ALK']
        fig.suptitle('Sustained plateau entry: '+('early response' if view=='early' else 'full-record check'),fontsize=18)
        fig.supxlabel('All responses are ensemble standard deviations. Bars: first qualifying time bin (5 block means within ±10% of the tail mean). * Later departures; not permanent settling.',fontsize=11)
        fig.savefig(OUT/f'plateau_{view}_18panels.png',dpi=300,facecolor='white');plt.close(fig)
    # 一张易读的判据对照：旧点/新进入/后续确认窗/尾段参照。
    examples=[('kappa','x2',30),('c1','w',150),('c30','Catm',1000),('c28','ALK',8000)]
    fig,axes=plt.subplots(2,2,figsize=(15,10),layout='constrained')
    for ax,(name,var,xmax) in zip(axes.flat,examples):
        d=cache[name];r=lookup[name,var];y=d[:,VARS.index(var)+1]
        xmax=max(xmax,1.15*(r['local_confirmation_TU'] or 0))
        _,bt,bm=measure(y,.1,WIDTH[var]);m=d[:,0]<=xmax
        ax.plot(np.r_[0,d[m,0]],np.r_[0,y[m]],color='#1f77b4',lw=.7,alpha=.25,label='Raw spread')
        bm_mask=bt<=xmax;ax.plot(bt[bm_mask],bm[bm_mask],color='#1f77b4',lw=1.6,label=f'Block mean ({WIDTH[var]} TU)')
        ref=r['reference_mean'];ax.axhspan(.9*ref,1.1*ref,color='grey',alpha=.15,label='Tail mean ±10%')
        ax.axhline(ref,color='grey',ls=':',lw=1)
        old_tau=r['old_growth_peak_TU'];ax.axvline(old_tau,color='#E66101',ls=':',label=f'Old growth-rate peak: {old_tau:.1f} TU')
        if r['local_plateau_TU'] is not None:
            tau=r['local_plateau_TU'];end=r['local_confirmation_TU']
            ax.axvline(tau,color='#7B3294',ls='--',label=f'Local plateau entry: {tau:g} TU')
            ax.axvspan(tau,end,color='#7B3294',alpha=.08,label=f'Confirmation to {end:g} TU')
        else:ax.text(.97,.05,'No sustained entry / stable reference',transform=ax.transAxes,ha='right')
        ax.set_xlim(0,xmax);ax.set_ylim(bottom=0);ax.set_title(name+' → '+var)
        ax.set_xlabel('Time after perturbation (TU)');ax.set_ylabel(var)
        ax.legend(fontsize=9);ax.grid(alpha=.2)
    fig.suptitle('Growth-rate peaks versus sustained plateau entry',fontsize=17)
    fig.supxlabel('All responses are ensemble standard deviations. A local plateau is not necessarily permanent; later departures are retained in the full-record check.',fontsize=11)
    fig.savefig(OUT/'plateau_method_comparison.png',dpi=300,facecolor='white');plt.close(fig)
    table=['# 持续平台法重测：先区分进入平台与永久整定','',
           '## 与上一版的根本区别','',
           '上一版用增长率的早期主峰，回答的是响应何时增长最快，而非响应何时进入平台。本版不再把该点当作平台饱和点。',
           '使用刚完成的完整20000 TU Fortran响应，20份二进制SHA256与超算审核文件逐一一致；未重跑积分，未更改参数名单或入场时刻。','',
           '## 新判据（明确的操作性定义，不是唯一物理常数）','',
           '1. 末段15000–20000 TU的平均集合标准差作为候选平台值P，不采用最后一个采样点。',
           '2. 后段前后两半均值之差/P≤10%，且后段四个子窗均值相对P偏差均≤10%，才接受这个平台参照。',
           '3. 不重叠时间窗内平均S(t)：x1/x2/x3用2 TU，w/TL用10 TU，Catm用20 TU，Cocean用100 TU，ALK用200 TU。',
           '4. 连续5个窗平均都在P±10%中，记录第一个窗的起点为局部平台进入τ；确认时间为第5窗末端。时间分辨率是W，不是0.1 TU。',
           '5. 另算全程整定：从某窗起直到20000 TU末尾所有窗口均在容差内，且仍保留至少max(5W,2000 TU)的验证长度。',
           '6. 每条曲线还比较5%/10%/15%容差、0.5/1/2倍平均窗，以及末20%和末50%参照窗；不挑选最有利的组合。',
           '7. 未通过参照检查/没有持续平台时不给饱和数值。局部平台后来离开时必须标星，不能当作永久饱和。','',
           '整定时间“进入并保持在最终值附近”的基础概念参考[MATLAB官方定义](https://www.mathworks.com/help/control/ref/dynamicsystem.stepinfo.html)。本次对振荡集合响应的分窗、持续长度和容差为明确披露的操作性扩展，不是该来源或Yang论文推荐的唯一阈值。','',
           '## 六个绘图变量的结果','',
           '数字单位TU；局部τ后星号表示随后再次离开容差带；NA表示未通过所定义的判据，不等同于数学上永远不会饱和。','',
           '| 参数 | 变量 | 旧增长率峰 | 新局部进入τ | 确认到 | 全程整定τ | 状态 |',
           '|---|---|---:|---:|---:|---:|---|']
    display=[]
    zh={'reference_not_stable':'尾段平台不稳','no_sustained_plateau':'无持续平台','sustained_and_global':'进入后一直保持','local_only_later_departures':'仅局部平台，后来离开'}
    def fmt(v):return 'NA' if v is None else f'{v:.2f}'.rstrip('0').rstrip('.')
    for name in WATER+CARBON:
        for var in (['x2','w','TL'] if name in WATER else ['Catm','Cocean','ALK']):
            r=lookup[name,var];display.append(r)
            table.append('| '+' | '.join([name,var,fmt(r['old_growth_peak_TU']),fmt(r['local_plateau_TU'])+('*' if r['status']=='local_only_later_departures' else ''),
                          fmt(r['local_confirmation_TU']),fmt(r['global_settling_TU']),zh[r['status']]])+' |')
    table+=['','## 对MCPE方案的处理','',
            '此轮不把任何平台进入时间直接写入参数更新周期：新定义与之前论文的增长率峰准饱和点不同，局部进入与全程整定也不能互换。',
            '水循环x2前十、碳循环Catm前十、1000 TU参数入场间隔均保持。旧周期草案暂停使用，未提交新的同化实验。']
    (OUT/'持续平台法结果与说明.md').write_text('\n'.join(table)+'\n',encoding='utf-8')
    manifests=[]
    for name in ['plateau_early_18panels.png','plateau_full_18panels.png','plateau_method_comparison.png']:
        path=OUT/name
        with Image.open(path) as im:
            original=im.size;im.thumbnail((1800,1500));im.convert('RGB').save(OUT/(path.stem+'_preview.jpg'),quality=90)
            manifests.append({'name':name,'pixels':original,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (OUT/'validation.json').write_text(json.dumps({'source_hashes_verified':20,'response_pairs':160,'synthetic_tests':unit_tests,
               'main_curve_bindings_verified':120,'displayed_status_counts':dict(Counter(r['status'] for r in display)),
               'figures':manifests},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'all_status':meta['status_counts'],'display_status':dict(Counter(r['status'] for r in display)),
               'examples':[{k:lookup[n,v][k] for k in ['parameter','variable','local_plateau_TU','global_settling_TU','old_point_fraction_of_reference','status']} for n,v,_ in examples]},ensure_ascii=False))

if __name__=='__main__':main()

"""只恢复原始0.1 TU响应图：无时间平均/平滑/抽稀，不重新裁定饱和点。"""
from pathlib import Path
import json, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image

BASE=Path(__file__).resolve().parent
OUT=BASE/'raw_0p1TU';OUT.mkdir(exist_ok=True)
WATER=['kappa','c1','b','sigma','c13','c2','lambda','c4','c12','c11']
CARBON=['c24','c16','c20','c29','c18','c30','c28','c19','c22','c23']
VARS=['x2','w','TL','Catm','Cocean','ALK']
COLUMNS=[2,4,5,6,7,8]
LIMITS=[20,50,50,100,100,2000]
COLORS=['#1f77b4','#ff7f0e','#2ca02c','#d62728']
font_manager.fontManager.addfont(str(BASE/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':13,
 'axes.titlesize':14,'xtick.labelsize':11,'ytick.labelsize':11,'mathtext.fontset':'stix',
 'path.simplify':False,'agg.path.chunksize':10000})

data={};source_hashes={}
for slot,name in enumerate(WATER+CARBON,1):
    folder=BASE/'results'/str(slot);source=folder/('saturation_'+name+'.bin')
    source_hashes[name]=hashlib.sha256(source.read_bytes()).hexdigest()
    audit=json.loads((folder/'audit.json').read_text(encoding='utf-8'))
    assert source_hashes[name]==audit['binary_sha256']
    d=np.fromfile(source,dtype='<f8').reshape(-1,9)
    assert d.shape==(200000,9) and np.isfinite(d).all()
    np.testing.assert_allclose(d[:,0],np.arange(1,200001)*.1,atol=1e-10,rtol=0)
    data[name]=d

fig,axes=plt.subplots(3,6,figsize=(26,13),layout='constrained')
checks=[]
for side,params in enumerate([WATER,CARBON]):
    for row,subset in enumerate([params[:3],params[3:6],params[6:]]):
        for j in range(3):
            col=side*3+j;ax=axes[row,col]
            for k,name in enumerate(subset):
                d=data[name];mask=d[:,0]<=LIMITS[col]
                t=np.r_[0.,d[mask,0]];y=np.r_[0.,d[mask,COLUMNS[col]]]
                line,=ax.plot(t,y,lw=1.5,color=COLORS[k],alpha=1,label=name)
                np.testing.assert_array_equal(line.get_xdata()[1:],d[mask,0])
                np.testing.assert_array_equal(line.get_ydata()[1:],d[mask,COLUMNS[col]])
                assert len(y)==int(LIMITS[col]*10)+1
                checks.append({'row':row,'column':col,'parameter':name,'variable':VARS[col],
                  'source_points':len(y)-1,'xmax_TU':LIMITS[col],'exact_source_match':True})
            ax.set_xlim(0,LIMITS[col]);ax.set_ylim(bottom=0)
            ax.set_xlabel('Time (TU)');ax.set_ylabel(VARS[col]);ax.set_title(VARS[col])
            ax.grid(alpha=.4,ls='--');ax.legend(loc='upper left',fontsize=10,framealpha=.9)
for row in axes:
    assert [ax.get_ylabel() for ax in row]==VARS
assert len(checks)==60 and len(fig.axes)==18
fig.suptitle('Parameter sensitivity responses',fontsize=18)
fig.supxlabel('Raw ensemble standard deviations sampled every 0.1 TU; no temporal averaging or smoothing. Saturation-time annotations are pending review.',fontsize=12)
path=OUT/'parameter_responses_raw_0p1TU_18panels.png'
fig.savefig(path,dpi=300,facecolor='white');plt.close(fig)
with Image.open(path) as im:
    pixels=im.size;dpi=im.info.get('dpi');im.thumbnail((1800,1200));im.convert('RGB').save(OUT/'preview.jpg',quality=92)
report={'input_sample_interval_TU':.1,'temporal_averaging':False,'smoothing':False,'decimation':False,
        'path_simplification':False,'initial_zero':'all members share the same initial state',
        'annotations':'not finalized; no obsolete growth-rate peaks restored',
        'source_sha256':source_hashes,'curves':checks,'pixels':pixels,'dpi':dpi,
        'output_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'file':str(path),'curves_verified':len(checks),'pixels':pixels}))

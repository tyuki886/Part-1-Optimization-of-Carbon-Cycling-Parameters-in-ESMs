"""Transpose the two 3x3 blocks; change only three slow ALK markers."""
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
import fit_display_windows as old

BASE=Path(__file__).resolve().parent
OUT=BASE/'plateau_axes_restored'
PREVIOUS=BASE/'plateau_from_existing_fit'/'plateau_results.json'
SLOW={'c20','c29','c28'}

def main():
    OUT.mkdir(exist_ok=True)
    before=hashlib.sha256(PREVIOUS.read_bytes()).hexdigest()
    payload=json.loads(PREVIOUS.read_text(encoding='utf-8'))
    rows=payload['results'];data={};checks=[]
    for r in rows:
        name=r['parameter'];v=r['variable'];f=r['fit'];T=r['window_TU']
        col={'x2':2,'w':4,'TL':5,'Catm':6,'Cocean':7,'ALK':8}[v]
        t,y,h=old.load_window((old.WATER+old.CARBON).index(name)+1,name,col,T)
        data[(name,v)]=(t,y)
        special=v=='ALK' and name in SLOW
        r['marker_basis']='90% of within-window fitted peak' if special else '95% of fitted asymptote'
        r['marker_fraction']=.9 if special else .95
        if special:
            # The retained sigmoids are monotone. Their maximum INSIDE this
            # window is f(T), not the asymptote A and not a noisy raw peak.
            fitted=old.evaluate(np.r_[0,t],f)
            assert np.all(np.diff(fitted)>=-1e-12)
            peak=float(fitted.max());target=.9*peak
            ts=float(brentq(lambda z:float(old.evaluate(z,f))-target,0,T,xtol=1e-9))
            assert abs(float(old.evaluate(ts,f))/peak-.9)<1e-9
            first=np.flatnonzero(fitted>=target)[0]
            assert (first-1)*.1-1e-8<=ts<=first*.1+1e-8
            r.update(marker_TU=ts,marker_y=target,window_fitted_peak=peak,
                     marker_is_plateau_proof=False,marker_is_window_dependent=True)
        else:
            r.update(marker_TU=r['plateau_95_TU'],marker_y=.95*f['A'])
        checks.append({'parameter':name,'variable':v,'binary_column_zero_based':col,
                       'binary_sha256':h,'points':len(t),'changed_marker':special})
    assert sum(r['marker_basis'].startswith('90%') for r in rows)==3
    assert all(r['marker_TU'] is not None for r in rows)
    assert hashlib.sha256(PREVIOUS.read_bytes()).hexdigest()==before
    (OUT/'results.json').write_text(json.dumps({'source_results_sha256':before,
        'refit':False,'raw_or_fitted_curves_changed':False,'results':rows},ensure_ascii=False,indent=2),encoding='utf-8')
    render(rows,data,checks)
    report(rows)
    print(json.dumps([{'parameter':r['parameter'],'time_TU':r['marker_TU'],'basis':r['marker_basis']}
                      for r in rows if r['variable']=='ALK' and r['parameter'] in SLOW],ensure_ascii=False))

def render(rows,data,checks):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from PIL import Image
    font_manager.fontManager.addfont(str(BASE/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':14,
                         'path.simplify':False,'agg.path.chunksize':10000,'mathtext.fontset':'stix'})
    fig,axes=plt.subplots(3,6,figsize=(26,13),layout='constrained')
    grid=[]
    for side,params in enumerate([old.WATER,old.CARBON]):
        for group,subset in enumerate([params[:3],params[3:6],params[6:]]):
            col=side*3+group
            for row in range(3):
                j=side*3+row;v=old.VARS[j];T=old.LIMITS[j];ax=axes[row,col]
                for k,name in enumerate(subset):
                    r=next(x for x in rows if x['parameter']==name and x['variable']==v)
                    t,y=data[(name,v)];f=r['fit'];ts=r['marker_TU'];color=old.COLORS[k]
                    raw,=ax.plot(np.r_[0,t],np.r_[0,y],color=color,lw=.8,alpha=.6)
                    np.testing.assert_array_equal(raw.get_ydata()[1:],y)
                    np.testing.assert_array_equal(raw.get_xdata()[1:],t)
                    special=v=='ALK' and name in SLOW
                    suffix=f'{ts:.1f}'+(' [90%]' if special else '')+('*' if r['fit_caveats'] else '')
                    tf=np.linspace(0,T,max(1000,len(t)))
                    ax.plot(tf,old.evaluate(tf,f),color=color,lw=1.8,ls='--',label=f'{name}: {suffix}')
                    ax.plot(ts,r['marker_y'],marker='D' if special else 'o',ms=5,color=color,
                            markerfacecolor='white' if r['fit_caveats'] else color,
                            markeredgecolor='black',markeredgewidth=.5)
                    grid.append({'row':row+1,'column':col+1,'variable':v,'parameter':name})
                ax.set(xlim=(0,T),xlabel='Time (TU)',ylabel=v)
                ax.set_ylim(bottom=0)
                if row==2 and col==5:
                    ax.set_ylim(0,.10)
                    ax.set_yticks(np.arange(0,.1001,.02))
                if row==0:
                    ax.set_title(old.VARS[col],fontsize=14)
                ax.grid(alpha=.25,ls=':');ax.legend(fontsize=9,loc='best',framealpha=.85)
    for row in range(3):
        for col in range(6):
            expected=[['x2']*3+['Catm']*3,['w']*3+['Cocean']*3,['TL']*3+['ALK']*3][row][col]
            assert axes[row,col].get_ylabel()==expected
            assert all(x['variable']==expected for x in grid if x['row']==row+1 and x['column']==col+1)
    assert len(grid)==60 and len({(g['parameter'],g['variable']) for g in grid})==60
    fig.suptitle('Parameter response fits and saturation-time markers',fontsize=18)
    fig.supxlabel('Response: ensemble standard deviation. Thin solid: raw 0.1-TU samples; dashed: unchanged fit.\nCircles: 95% of fitted asymptote; diamonds: 90% of within-window fitted peak (ALK: c20, c29, c28). * = fit caveat.',fontsize=12)
    assert [ax.get_title() for ax in axes[0]]==old.VARS
    np.testing.assert_allclose(axes[2,5].get_ylim(),[0,.10])
    axis_checks=[{'row':i+1,'column':j+1,'ylabel':ax.get_ylabel(),
                 'title':ax.get_title(),'xlim':list(ax.get_xlim()),'ylim':list(ax.get_ylim())}
                for i,row_axes in enumerate(axes) for j,ax in enumerate(row_axes)]
    clipped=[{'parameter':p,'samples_above_0p10':int(np.count_nonzero(data[(p,'ALK')][1]>.1)),
              'raw_max':float(data[(p,'ALK')][1].max())} for p in old.CARBON[6:]]
    dest=OUT/'plateau_axes_restored_alk90.png'
    fig.savefig(dest,dpi=300,facecolor='white');plt.close(fig)
    with Image.open(dest) as im:
        assert im.size==(7800,3900)
        im.thumbnail((1800,1000));im.convert('RGB').save(OUT/'preview.jpg',quality=80)
    (OUT/'validation.json').write_text(json.dumps({'input_checks':checks,'actual_panel_mapping':grid,
        'unchanged_fits':True,'only_3_markers_changed':True,'all_60_raw_plot_arrays_checked':True,
        'all_18_axis_labels_checked_against_actual_curve_variable':True,
        'axes':axis_checks,'bottom_right_display_clipping':clipped},ensure_ascii=False,indent=2),encoding='utf-8')

def report(rows):
    lines=['# 纵向变量布局及慢ALK峰值90%取点','',
        '问题定位：上一版标签与实际数据相符，但变量和参数分组的行列排反。现将左右两个3×3区块分别转置，数据、拟合、取点一起移动，而非仅改标签。','',
        '| 行 | 左侧三列 | 右侧三列 |','|---|---|---|','| 第一行 | x2 | Catm |','| 第二行 | w | Cocean |','| 第三行 | TL | ALK |','',
        '每侧三列从左到右分别放参数1–3、4–6、7–10，仍为3/3/4组。顶部依用户确认恢复x2/w/TL/Catm/Cocean/ALK，实际响应变量仍以面板纵轴为准。','',
        '撤销共用纵轴，恢复每个面板独立范围；右下角按用户指定固定0–0.10。超过0.10的原始波动在显示边界裁切，数据、拟合、取点及时间轴不变。','',
        '根据紧邻对话，将“特别缓慢的几个”限定为上一版NR的c20、c29、c28对应ALK；峰值按当前0–2000 TU窗口内拟合曲线的最高值理解，取其90%。不是原始振荡峰值，也不是渐近平台A的90%。这三个时间依赖窗口，不等同于证实真正饱和。其余57个点沿用95%A。','',
        '图中圆点为95%A，菱形及[90%]为三条ALK的窗口拟合峰值90%；†或星号为原拟合注意项。','']
    for params,variables,title in [(old.WATER,old.VARS[:3],'水循环'),(old.CARBON,old.VARS[3:],'碳循环')]:
        lines += [f'## {title}参数取点时间（TU）','','| 参数 | '+' | '.join(variables)+' |','|---|---:|---:|---:|']
        for p in params:
            cells=[]
            for v in variables:
                r=next(x for x in rows if x['parameter']==p and x['variable']==v)
                cells.append(f"{r['marker_TU']:.1f}"+('（峰值90%）' if v=='ALK' and p in SLOW else '')+('†' if r['fit_caveats'] else ''))
            lines.append('| '+p+' | '+' | '.join(cells)+' |')
        lines.append('')
    (OUT/'布局修正及取点时间.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__':main()

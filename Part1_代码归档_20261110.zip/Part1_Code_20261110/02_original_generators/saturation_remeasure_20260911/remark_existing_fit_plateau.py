"""Re-mark saved fits at 95% of their asymptote; never refit or integrate."""
from pathlib import Path
import hashlib
import json
import numpy as np
from scipy.optimize import brentq
import fit_display_windows as old

BASE=Path(__file__).resolve().parent
OUT=BASE/'plateau_from_existing_fit'
SRC=BASE/'display_window_fit'/'fit_results.json'

def crossing(f,q):
    T=f['window_TU']
    if float(old.evaluate(T,f)) < q*f['A']:
        return None
    t=float(brentq(lambda t: float(old.evaluate(t,f))/f['A']-q,0,T,xtol=1e-10))
    assert abs(float(old.evaluate(t,f))/f['A']-q)<1e-8
    # Independent grid bracketing, at original sampling cadence.
    grid=np.arange(0,round(T/.1)+1)*.1
    k=np.flatnonzero(old.evaluate(grid,f)>=q*f['A'])[0]
    assert grid[max(0,k-1)]-1e-8 <= t <= grid[k]+1e-8
    return t

def main():
    OUT.mkdir(exist_ok=True)
    before=hashlib.sha256(SRC.read_bytes()).hexdigest()
    payload=json.loads(SRC.read_text(encoding='utf-8'))
    rows=[];data={}
    for r in payload['results']:
        f=old.selected_fit(r);name=r['parameter'];v=r['variable'];j=old.VARS.index(v)
        t,y,h=old.load_window((old.WATER+old.CARBON).index(name)+1,name,old.COLS[j],r['window_TU'])
        assert h==payload['source_sha256'][name]
        data[(name,v)]=(t,y)
        flags=[x for x in r['flags'] if x in ['solver_not_converged','parameter_bound_hit','poor_identifiability','transition_under_sample_resolution']]
        ts=crossing(f,.95)
        rows.append({'parameter':name,'variable':v,'window_TU':r['window_TU'],
                     'model':r['selected_model'],'plateau_95_TU':ts,
                     'plateau_90_TU':crossing(f,.9),'plateau_99_TU':crossing(f,.99),
                     'asymptote':f['A'],'end_fraction':float(old.evaluate(r['window_TU'],f)/f['A']),
                     'status':'not_reached_in_window' if ts is None else 'fit_based_estimate',
                     'fit_caveats':flags,'fit':f})
    assert len(rows)==60
    assert before==hashlib.sha256(SRC.read_bytes()).hexdigest()
    out={'definition':'first t in original window with fitted S(t) >= 0.95 A',
         'threshold_is_analyst_operational_choice':True,'user_requested_reuse_existing_fit':True,
         'refit':False,'new_integration':False,'raw_stationarity_test':False,
         'source_fit_sha256':before,'results':rows}
    (OUT/'plateau_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    report(rows)
    render(rows,data)
    print(json.dumps({'total':len(rows),'in_window':sum(r['plateau_95_TU'] is not None for r in rows),
                      'not_reached':[(r['parameter'],r['variable']) for r in rows if r['plateau_95_TU'] is None],
                      'by_variable':{v:sum(r['plateau_95_TU'] is not None for r in rows if r['variable']==v) for v in old.VARS},
                      'output':str(OUT)},ensure_ascii=False),flush=True)

def report(rows):
    lines=['# 原有拟合曲线重新取点：平台进入时间','',
           '直接复用上一版Logistic/Gompertz的所选函数和全部系数，不重新拟合、不重新积分。只替换标记的位置。','',
           '本次采用的操作性标准：拟合响应S(t)首次达到拟合渐近平台A的95%，即S(t)=0.95A。95%是本次分析选用的容差，不是用户指定的比例或普适物理定律，也不是95%置信度。',
           '因此这些是“拟合平台进入时间”，不是经过原始序列平稳性检验的长期稳定时间。渐近平台A不是窗口内最大值，不能用曲线终点代替A。',
           '窗口：x2 0–20 TU；w、TL 0–50 TU；Catm、Cocean 0–100 TU；ALK 0–2000 TU。时间从扰动开始计。窗口内未达到95%A时不画点、不外推时间。',
           '原始0.1 TU曲线保留。†继承原拟合的采样分辨率、参数触边或可辨识性提示；不沿用“无内部拐点”作为平台无法判定的理由。','']
    for params,variables,title in [(old.WATER,old.VARS[:3],'水循环参数'),(old.CARBON,old.VARS[3:],'碳循环参数')]:
        lines += [f'## {title}（TU）','','| 参数 | '+' | '.join(variables)+' |','|---|---:|---:|---:|']
        for name in params:
            vals=[]
            for v in variables:
                r=next(x for x in rows if x['parameter']==name and x['variable']==v)
                ts=r['plateau_95_TU']
                vals.append('窗口内未达到' if ts is None else f'{ts:.1f}'+('†' if r['fit_caveats'] else ''))
            lines.append('| '+name+' | '+' | '.join(vals)+' |')
        lines.append('')
    lines += ['## 容差参考及拟合注意项','','90%和99%仅展示取点对容差的依赖，不是置信区间；图中只标95%。','',
              '| 参数–变量 | 函数 | 90%时间 | 95%时间 | 99%时间 | 注意项 |','|---|---|---:|---:|---:|---|']
    labels={'solver_not_converged':'求解未收敛','parameter_bound_hit':'拟合参数触边','poor_identifiability':'参数可辨识性弱','transition_under_sample_resolution':'拟合过渡短于0.1 TU采样间隔'}
    for r in rows:
        cells=['未达到' if r[f'plateau_{q}_TU'] is None else f"{r[f'plateau_{q}_TU']:.1f}" for q in [90,95,99]]
        lines.append('| '+r['parameter']+'–'+r['variable']+' | '+r['model']+' | '+' | '.join(cells)+' | '+('；'.join(labels[x] for x in r['fit_caveats']) or '—')+' |')
    lines += ['','上一版最大斜率标记保留为历史结果，不能再称为平台进入时间。本次未改变MCPE方案、参数入场间隔或更新周期。','']
    (OUT/'拟合平台进入时间.md').write_text('\n'.join(lines),encoding='utf-8')

def render(rows,data):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from PIL import Image
    font_manager.fontManager.addfont(str(BASE/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':13,
                         'path.simplify':False,'agg.path.chunksize':10000,'mathtext.fontset':'stix'})
    fig,axes=plt.subplots(3,6,figsize=(26,13),layout='constrained')
    for side,params in enumerate([old.WATER,old.CARBON]):
        for row,subset in enumerate([params[:3],params[3:6],params[6:]]):
            for j in range(3):
                col=side*3+j;v=old.VARS[col];T=old.LIMITS[col];ax=axes[row,col]
                for k,name in enumerate(subset):
                    r=next(x for x in rows if x['parameter']==name and x['variable']==v)
                    t,y=data[(name,v)];f=r['fit'];ts=r['plateau_95_TU'];color=old.COLORS[k]
                    raw,=ax.plot(np.r_[0.,t],np.r_[0.,y],color=color,lw=.8,alpha=.6)
                    np.testing.assert_array_equal(raw.get_ydata()[1:],y)
                    suffix='NR' if ts is None else f'{ts:.1f}'+('*' if r['fit_caveats'] else '')
                    tf=np.linspace(0,T,max(1000,len(t)))
                    ax.plot(tf,old.evaluate(tf,f),color=color,lw=1.8,ls='--',label=f'{name}: {suffix}')
                    if ts is not None:
                        ax.plot(ts,.95*f['A'],marker='o',ms=5,color=color,
                                markerfacecolor='white' if r['fit_caveats'] else color,markeredgecolor='black',markeredgewidth=.5)
                ax.set(xlim=(0,T),ylim=(0,None),xlabel='Time (TU)',ylabel=v,title=v)
                ax.grid(alpha=.25,ls=':');ax.legend(fontsize=9,loc='best',framealpha=.85)
    fig.suptitle('Parameter response fits and plateau-entry times',fontsize=18)
    fig.supxlabel('Thin solid: raw 0.1-TU samples; dashed: unchanged fit; circles: 95% of fitted asymptote. * = fit caveat; NR = not reached in window.',fontsize=12)
    dest=OUT/'fitted_plateau_entry_18panels.png'
    fig.savefig(dest,dpi=300,facecolor='white');plt.close(fig)
    with Image.open(dest) as im:
        assert im.size==(7800,3900)
        im.thumbnail((1800,1000));im.convert('RGB').save(OUT/'preview.jpg',quality=80)
    (OUT/'validation.json').write_text(json.dumps({'all_60_roots_or_window_exclusions_checked':True,
        'root_checked_by_independent_0p1_grid':True,'raw_plot_arrays_unchanged':True,
        'saved_fit_file_unchanged':True,'pixels':[7800,3900],'dpi':300},indent=2),encoding='utf-8')

if __name__=='__main__':main()

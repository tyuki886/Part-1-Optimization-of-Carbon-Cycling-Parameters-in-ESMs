"""Recheck B at divisors of 5000 TU; raw diagnostic plots for visual review.

No production-model changes. Visual suggestions are entered separately after
inspection, never manufactured by rounding an unconfirmed statistical result.
"""
import argparse
import json
import hashlib
from pathlib import Path
import numpy as np
import bc_stability as b

OUT=b.BASE/'divisor_5000_review'
DIVISORS=[d for d in range(1,5001) if 5000%d==0]


def main_rows():
    p=json.loads((b.OUT/'results.json').read_text(encoding='utf-8'))
    rows=[r for r in p['results'] if (r['parameter'] in b.WATER and r['variable'] in ['x2','w','TL']) or
                                  (r['parameter'] in b.CARBON and r['variable'] in ['Catm','Cocean','ALK'])]
    assert len(rows)==60
    return p,rows


def load_data(p):
    data={}
    for slot,name in enumerate(b.WATER+b.CARBON,1):
        src=b.BASE/'results'/str(slot)/f'saturation_{name}.bin'
        raw=src.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==p['source_sha256'][name]
        d=np.frombuffer(raw,dtype='<f8').reshape(-1,9)
        assert d.shape==(200000,9) and np.isfinite(d).all()
        np.testing.assert_allclose(d[:,0],np.arange(1,200001)*.1,atol=1e-10,rtol=0)
        data[name]=d
    return data


def grid_check(y,old,seed):
    result={'window_TU':old['window_TU'],'reference_status':old['status'],
            'first_three_window_grid_TU':None,'first_followup_pass_grid_TU':None,'tested':[]}
    ref=old.get('normal_reference')
    if ref is None:
        result['status']='reference_unavailable'
        return result
    n=int(round(old['window_TU']/.1))
    reference=b.features(y,n)[-old['reference_windows']:]
    for d in DIVISORS:
        start=int(round(d/.1))
        first=b.features(y[start:start+3*n],n)
        if len(first)<3:
            continue
        score=np.max(abs(first-np.array(ref['median']))/np.array(ref['MAD_scale']),axis=1)
        passed=bool(np.all(score<=ref['joint_empirical_95_cutoff']))
        item={'candidate_TU':d,'three_windows_pass':passed,'scores':score.tolist()}
        if passed:
            if result['first_three_window_grid_TU'] is None:
                result['first_three_window_grid_TU']=d
            follow=b.followup_test(b.features(y[start:],n),reference,np.random.default_rng(seed),
                                   old['resampling_block_windows'])
            item['followup']=follow
            if follow['passed']:
                result['first_followup_pass_grid_TU']=d
                result['tested'].append(item)
                break
        result['tested'].append(item)
    result['status']='grid_candidate' if result['first_followup_pass_grid_TU'] is not None else 'no_grid_point_passed'
    return result


def measure(p,rows,data):
    output=[]
    for r in rows:
        y=data[r['parameter']][:,1+b.VARIABLES.index(r['variable'])]
        settings={'base':r['B'],**r['B_checks']}
        checks={label:grid_check(y,old,60000+r['slot']*100+b.VARIABLES.index(r['variable']))
                for label,old in settings.items()}
        vals=[x['first_followup_pass_grid_TU'] for x in checks.values()]
        output.append({'parameter':r['parameter'],'variable':r['variable'],'checks':checks,
                       'C_turn_TU':r['C']['fits'][-1].get('tau_TU'),
                       'C_status':r['C']['status'],
                       'all_settings_have_grid_candidate':all(x is not None for x in vals),
                       'all_settings_same_grid_candidate':len(set(vals))==1 and vals[0] is not None})
        print(r['parameter'],r['variable'],vals,flush=True)
    result={'divisors_TU':DIVISORS,'interpretation':'positive integer divisors of 5000 TU',
            'sample_interval_TU':.1,'source_sha256':p['source_sha256'],
            'diagnostic_only':True,'selection_rule':'earliest tested divisor passing unchanged B features and follow-up',
            'multiple_grid_search':'exploratory; nominal bootstrap checks do not give a confidence level for the selected time',
            'results':output}
    (OUT/'grid_measurement.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')


def plots(data):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from PIL import Image
    font_manager.fontManager.addfont(str(b.BASE/'times.ttf'))
    plt.rcParams.update({'font.family':'Times New Roman','font.size':12,'axes.labelsize':12,
                         'path.simplify':False,'agg.path.chunksize':10000})
    configs=[('water_1',b.WATER[:5],['x2','w','TL'],[40,100,100]),
             ('water_2',b.WATER[5:],['x2','w','TL'],[40,100,100]),
             ('carbon_1',b.CARBON[:5],['Catm','Cocean','ALK'],[250,500,5000]),
             ('carbon_2',b.CARBON[5:],['Catm','Cocean','ALK'],[250,500,5000])]
    checks=[]
    for label,params,variables,limits in configs:
        fig,axes=plt.subplots(5,3,figsize=(19,16),layout='constrained')
        for i,param in enumerate(params):
            d=data[param]
            for j,(v,end) in enumerate(zip(variables,limits)):
                ax=axes[i,j];col=1+b.VARIABLES.index(v);mask=d[:,0]<=end
                line,=ax.plot(d[mask,0],d[mask,col],color='#1f77b4',lw=1)
                np.testing.assert_array_equal(line.get_ydata(),d[mask,col])
                np.testing.assert_array_equal(line.get_xdata(),d[mask,0])
                ax.set(xlim=(0,end),ylim=(0,None),xlabel='Time (TU)',ylabel=v,title=f'{param} - {v}')
                ax.grid(alpha=.2)
                checks.append({'parameter':param,'variable':v,'xmax_TU':end,'raw_points':int(mask.sum()),'exact':True})
        fig.suptitle('Raw parameter responses: visual review (0.1 TU sampling)',fontsize=17)
        fig.savefig(OUT/f'{label}.png',dpi=160);plt.close(fig)
        with Image.open(OUT/f'{label}.png') as im:
            im.thumbnail((2000,1800));im.convert('RGB').save(OUT/f'{label}_preview.jpg',quality=92)
    for v,col in [('ALK',8),('Cocean',7)]:
        fig,axes=plt.subplots(5,2,figsize=(17,16),layout='constrained')
        for ax,param in zip(axes.flat,b.CARBON):
            d=data[param]
            line,=ax.plot(d[:,0],d[:,col],lw=1,color='#1f77b4')
            np.testing.assert_array_equal(line.get_ydata(),d[:,col])
            for t in [5000,10000,15000]:ax.axvline(t,color='#777777',lw=.7,ls=':')
            ax.set(xlim=(0,20000),ylim=(0,None),xlabel='Time (TU)',ylabel=v,title=param)
            ax.grid(alpha=.2)
        fig.suptitle(f'{v}: complete raw response (0-20000 TU)',fontsize=17)
        fig.savefig(OUT/f'{v}_full.png',dpi=160);plt.close(fig)
        with Image.open(OUT/f'{v}_full.png') as im:
            im.thumbnail((1400,1400));im.convert('RGB').save(OUT/f'{v}_full_preview.jpg',quality=65)
    (OUT/'raw_plot_validation.json').write_text(json.dumps({'smoothing':False,'decimation':False,
                'early_or_medium_curves':checks,'full_ALK_curves':10,'full_Cocean_curves':10},indent=2),encoding='utf-8')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['measure','plots']);args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    p,rows=main_rows();data=load_data(p)
    if args.mode=='measure':measure(p,rows,data)
    else:plots(data)

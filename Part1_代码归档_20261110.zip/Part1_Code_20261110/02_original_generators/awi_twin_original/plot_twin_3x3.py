"""偏差孪生实验：原始数据、原抽样；去总标题及海冰，按指定顺序排列九面板。

图件约定：比较 x2 初值 1.0/1.1 的轨迹，9900–10000 TU；
原始 10000 行、0.01 TU/行，x1/x2/x3 每100行抽一点，其余全采样。
输出独立 PNG/PDF，黑/红配色沿用原图，英文衬线字体。
"""
from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / 'python_deps'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

BASE = Path(__file__).resolve().parent
font = BASE / 'times.ttf'
if font.exists():
    font_manager.fontManager.addfont(str(font))
    family = font_manager.FontProperties(fname=str(font)).get_name()
else:
    family = 'DejaVu Serif'
plt.rcParams.update({'font.family': family, 'font.size': 11,
                     'axes.titlesize': 13, 'axes.labelsize': 11,
                     'xtick.labelsize': 10, 'ytick.labelsize': 10,
                     'pdf.fonttype': 42, 'ps.fonttype': 42})
A = np.loadtxt(BASE / 'twin_x2_1p0.txt')
B = np.loadtxt(BASE / 'twin_x2_1p1.txt')
if A.shape != B.shape or A.ndim != 2 or A.shape[1] != 11:
    raise ValueError('Expected matching arrays with time and ten state columns')
if not np.isfinite(A).all() or not np.isfinite(B).all():
    raise ValueError('Nonfinite data')
if not np.array_equal(A[:, 0], B[:, 0]) or not np.all(np.diff(A[:, 0]) > 0):
    raise ValueError('Time coordinates must match and increase')
# 文件列号（0列为时间），不可将显示顺序当作数据列顺序。
PANELS = [('x1', 1), ('x2', 2), ('x3', 3),
          ('TL', 7), ('w', 4), ('eta', 5),
          ('Catm', 8), ('Cocean', 9), ('ALK', 10)]
fig, axes = plt.subplots(3, 3, figsize=(12, 10), constrained_layout=True)
counts = {}
for ax, (label, column) in zip(axes.flat, PANELS):
    stride = 100 if column in (1, 2, 3) else 1
    rows = slice(None, None, stride)
    ax.plot(A[rows, 0], A[rows, column], color='k', lw=1.0,
            label='Truth (X2 = 1.0)')
    ax.plot(B[rows, 0], B[rows, column], color='#C44E52', lw=1.0,
            label='Control (X2 = 1.1)')
    ax.set_title(label, pad=7)
    ax.set_xlabel('t (TU)')
    ax.set_xlim(9900, 10000)
    ax.set_xticks(np.arange(9900, 10001, 20))
    ax.ticklabel_format(axis='y', style='plain', useOffset=False)
    ax.legend(fontsize=8, loc='best', framealpha=0.85)
    ax.grid(alpha=0.22, linewidth=0.6)
    counts[label] = len(A[rows])
for ext in ('png', 'pdf'):
    fig.savefig(BASE / ('biased_twin_x2_3x3.' + ext), dpi=300,
                bbox_inches='tight', facecolor='white')
plt.close(fig)
print(json.dumps({'rows': len(A), 'time_start': A[0, 0],
                  'time_end': A[-1, 0], 'panels': PANELS,
                  'points_per_panel': counts, 'font': family,
                  'global_title': None}, ensure_ascii=False))

# -*- coding: utf-8 -*-
"""偏差孪生实验画图：10 子图（2x5），最后 100 TU
黑线 Truth (X2 = 1.0)，红线 Control (X2 = 1.1)
题目 Biased twin experiment of x2
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ST = ['x1', 'x2', 'x3', 'w', 'eta', 'ice', 'TL', 'Catm', 'Cocean', 'ALK']
A = np.loadtxt('twin_x2_1p0.txt')   # Truth, 列0=时间, 1-10=变量
B = np.loadtxt('twin_x2_1p1.txt')   # Control
t = A[:, 0]
THIN = {0, 1, 2, 5}                 # x1/x2/x3/ice 震荡快：1 TU 一个点（100 点）

fig, axes = plt.subplots(2, 5, figsize=(20, 9))
for j, v in enumerate(ST):
    ax = axes[j // 5, j % 5]
    if j in THIN:
        ax.plot(t[::100], A[::100, j + 1], color='k', lw=1.2, label='Truth (X2 = 1.0)')
        ax.plot(t[::100], B[::100, j + 1], color='#C44E52', lw=1.2, label='Control (X2 = 1.1)')
    else:
        ax.plot(t, A[:, j + 1], color='k', lw=1.2, label='Truth (X2 = 1.0)')
        ax.plot(t, B[:, j + 1], color='#C44E52', lw=1.2, label='Control (X2 = 1.1)')
    ax.set_title(v, fontsize=11, fontweight='bold')
    ax.set_xlabel('t (TU)', fontsize=9)
    ax.legend(fontsize=8, loc='best')
    ax.grid(alpha=0.3)
plt.suptitle('Biased twin experiment of x2', fontsize=14, fontweight='bold')
plt.tight_layout(rect=[0, 0, 1, 0.96])
fig.savefig('biased_twin_x2.png', dpi=200, bbox_inches='tight')
plt.close()
print('PLOT_DONE')

program biased_twin
    ! 偏差孪生实验：10 变量模式，仅 x2 初值不同（1.0 = Truth, 1.1 = Control）
    ! 自由积分 10000 TU（1e6 步，dt=0.01 TU），输出最后 100 TU（每步一行）
    use RKmethod
    implicit none
    real(kind=dp) :: x(10)
    integer(kind=8) :: i
    integer :: u

    ! ---- Run 1: x2 = 1.0 (Truth) ----
    x = 0.0_dp; x(2) = 1.0_dp; call update_sea_ice(x)
    open(newunit=u, file='twin_x2_1p0.txt', status='replace')
    do i = 1, 1000000_8
        call adv_true_state(x, i, 10)
        if (i > 990000_8) write(u, '(ES14.6,1X,10ES14.6)') dble(i)*0.01_dp, x
    end do
    close(u)

    ! ---- Run 2: x2 = 1.1 (Control) ----
    x = 0.0_dp; x(2) = 1.1_dp; call update_sea_ice(x)
    open(newunit=u, file='twin_x2_1p1.txt', status='replace')
    do i = 1, 1000000_8
        call adv_true_state(x, i, 10)
        if (i > 990000_8) write(u, '(ES14.6,1X,10ES14.6)') dble(i)*0.01_dp, x
    end do
    close(u)

    write(*,*) 'TWIN_DONE'
end program

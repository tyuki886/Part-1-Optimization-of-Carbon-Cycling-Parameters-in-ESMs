"""将 AWI 原始孪生数据和九面板脚本迁入新超算，运行并取回图件。"""
from pathlib import Path
import getpass
import hashlib
import json
import sys
import paramiko

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parents[1]))
import hpc

SOURCE = '/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/twin_work'
TARGET = '/public/home/hou/wyh/MCPE26.0/twin_work_3x3'
password = getpass.getpass('New HPC password: ')
client = paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('222.195.137.80', username='hou', password=password,
               timeout=30, look_for_keys=False, allow_agent=False)
del password
try:
    awi = hpc.connect()
    try:
        with awi.open_sftp() as src:
            for name in ('twin_x2_1p0.txt', 'twin_x2_1p1.txt'):
                src.get(SOURCE + '/' + name, str(BASE / name))
                with src.open(SOURCE + '/' + name, 'rb') as stream:
                    stream.prefetch(src.stat(SOURCE + '/' + name).st_size)
                    assert hashlib.sha256(stream.read()).hexdigest() == hashlib.sha256((BASE / name).read_bytes()).hexdigest()
                print('AWI data verified:', name, flush=True)
    finally:
        awi.close()
    with client.open_sftp() as dst:
        try:
            dst.stat(TARGET)
        except FileNotFoundError:
            dst.mkdir(TARGET)
        for name in ('plot_twin.py', 'plot_twin_3x3.py', 'biased_twin.f90',
                     'twin_x2_1p0.txt', 'twin_x2_1p1.txt'):
            dst.put(str(BASE / name), TARGET + '/' + name)
            with dst.open(TARGET + '/' + name, 'rb') as stream:
                stream.prefetch(dst.stat(TARGET + '/' + name).st_size)
                assert hashlib.sha256(stream.read()).hexdigest() == hashlib.sha256((BASE / name).read_bytes()).hexdigest()
            print('New HPC verified:', name, flush=True)
        dst.put('C:/Windows/Fonts/times.ttf', TARGET + '/times.ttf')
    command = ('cd ' + TARGET + ' && /public/home/hou/miniconda3/envs/yuki/bin/python plot_twin_3x3.py')
    _, stdout, stderr = client.exec_command(command, timeout=120)
    out = stdout.read().decode('utf-8', 'replace')
    err = stderr.read().decode('utf-8', 'replace')
    print(out, flush=True)
    print(err, flush=True)
    if stdout.channel.recv_exit_status() != 0:
        raise RuntimeError('Remote plotting failed')
    with client.open_sftp() as dst:
        for ext in ('png', 'pdf'):
            name = 'biased_twin_x2_3x3.' + ext
            dst.get(TARGET + '/' + name, str(BASE / name))
            print('Downloaded:', BASE / name, flush=True)
    print('DONE', flush=True)
finally:
    client.close()

from pathlib import Path
import getpass
import paramiko
BASE = Path(__file__).resolve().parent
REMOTE = '/public/home/hou/wyh/MCPE26.0/twin_work_3x3'
PY = '/public/home/hou/miniconda3/envs/yuki/bin/python'
client = paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('222.195.137.80', username='hou', password=getpass.getpass('New HPC password: '), timeout=30, look_for_keys=False, allow_agent=False)
try:
    with client.open_sftp() as sftp:
        try:
            sftp.mkdir(REMOTE + '/wheelhouse')
        except IOError:
            pass
        for path in sorted((BASE / 'wheelhouse').glob('*.whl')):
            sftp.put(str(path), REMOTE + '/wheelhouse/' + path.name)
            print('Uploaded:', path.name, flush=True)
        sftp.put(str(BASE / 'plot_twin_3x3.py'), REMOTE + '/plot_twin_3x3.py')
    for command in [PY + ' -m pip install --no-index --find-links=' + REMOTE + '/wheelhouse --target=' + REMOTE + '/python_deps numpy==1.26.4 matplotlib==3.8.4', PY + ' ' + REMOTE + '/plot_twin_3x3.py']:
        _, out, err = client.exec_command(command, timeout=180)
        print(out.read().decode('utf-8', 'replace'), flush=True)
        print(err.read().decode('utf-8', 'replace'), flush=True)
        if out.channel.recv_exit_status() != 0:
            raise RuntimeError('Remote command failed')
    with client.open_sftp() as sftp:
        for ext in ('png', 'pdf'):
            name = 'biased_twin_x2_3x3.' + ext
            sftp.get(REMOTE + '/' + name, str(BASE / name))
            print('Downloaded:', name, flush=True)
finally:
    client.close()

"""统一水循环和碳循环图例位置；复用原统计和排序，不重新计算敏感性。"""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch
from PIL import Image
import plot_sensitivity_combined as old

BASE=Path(__file__).resolve().parent
FOLDER=BASE/'results'
OUT=BASE/'legends_aligned_20260914'
OUT.mkdir(exist_ok=True)
src=FOLDER/'sensitivity_W20_C500.txt'
digest=hashlib.sha256(src.read_bytes()).hexdigest()
rows=old.read_results(FOLDER)
prior=json.loads((FOLDER/'sensitivity_audit.json').read_text())
font_manager.fontManager.addfont(r'C:\Windows\Fonts\times.ttf')
plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'axes.titlesize':13,
                     'axes.labelsize':11,'xtick.labelsize':9,'ytick.labelsize':10})
fig=plt.figure(figsize=(19,18),constrained_layout=True)
fig.suptitle('Parameter sensitivity under separate measurement windows',fontsize=18)
subfigs=fig.subfigures(2,1,hspace=.035)
audits=[];legends=[]
for sf,group,title,key,deep,pale in [
    (subfigs[0],'WATER','Water cycle parameters (0-20 TU)',1,'#1F4E79','#9DC3E6'),
    (subfigs[1],'CARBON','Carbon cycle parameters (0-500 TU)',5,'#1E6B3A','#9CD9A5')]:
    items=sorted([r for r in rows if r['group']==group],key=lambda r:r['row'])
    top=[r['name'] for r in sorted(items,key=lambda r:-r['values'][key])[:10]]
    assert top==prior['groups'][group]['top10']
    sf.suptitle(title,fontsize=16,fontweight='bold')
    axes=sf.subplots(2,4)
    handles=[Patch(facecolor=deep,edgecolor='#222222',label=f'Top 10 ({old.VARS[key]})'),
             Patch(facecolor=pale,edgecolor=pale,label='Other parameters')]
    legend=sf.legend(handles=handles,fontsize=10,frameon=False,ncol=2,
                     loc='upper left',bbox_to_anchor=(.035,.998),borderaxespad=0)
    legends.append((sf,legend))
    for j,var in enumerate(old.VARS):
        ax=axes[j//4,j%4]
        order=sorted(items,key=lambda r:-r['values'][j])
        labels=[r['name'] for r in order];values=[r['values'][j] for r in order]
        previous=next(p for p in prior['panels'] if p['group']==group and p['variable']==var)
        assert labels==previous['parameters']
        colors=[deep if name in top else pale for name in labels]
        edges=['#222222' if name in top else pale for name in labels]
        bars=ax.bar(np.arange(len(order)),values,color=colors,edgecolor=edges,linewidth=.45,width=.85)
        np.testing.assert_array_equal([b.get_height() for b in bars],values)
        ax.set_title(var,pad=8);ax.set_xticks(np.arange(len(order)),labels=labels,rotation=90)
        ax.tick_params(axis='x',length=2,pad=3);ax.set_ylim(bottom=0);ax.set_axisbelow(True)
        ax.grid(alpha=.25,axis='y',linewidth=.6);ax.ticklabel_format(axis='y',style='sci',scilimits=(0,0))
        if j%4==0:ax.set_ylabel('Mean ensemble standard deviation')
        audits.append({'group':group,'variable':var,'parameters':labels,'heights':values})
fig.canvas.draw()
renderer=fig.canvas.get_renderer()
for sf,legend in legends:
    legend_box=legend.get_window_extent(renderer)
    assert all(not legend_box.overlaps(ax.get_window_extent(renderer)) for ax in sf.axes)
    assert not legend_box.overlaps(sf._suptitle.get_window_extent(renderer))
previous_audit=json.loads((BASE/'legend_outside_20260914'/'validation.json').read_text(encoding='utf-8'))
assert audits==previous_audit['panels']
target=OUT/'sensitivity_W20_C500_combined.png'
fig.savefig(target,dpi=300,bbox_inches='tight',facecolor='white');plt.close(fig)
with Image.open(target) as im:
    size=list(im.size);im.thumbnail((1400,1350));im.convert('RGB').save(OUT/'preview.jpg',quality=75)
assert digest==hashlib.sha256(src.read_bytes()).hexdigest()
(OUT/'validation.json').write_text(json.dumps({'source_sha256':digest,'panels':audits,
    'both_legends_outside_data_axes':True,'legend_does_not_overlap_group_title':True,
    'same_subfigure_relative_anchor':[.035,.998],
    'rankings_and_heights_unchanged':True,'output':str(target),'pixels':size},ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS: 16 panels unchanged; both legends aligned outside plots and clear of group titles.')
print(target)

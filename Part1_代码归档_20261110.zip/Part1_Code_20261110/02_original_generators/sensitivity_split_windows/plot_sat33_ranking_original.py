# plot_sat33_ranking.py — 2026-08-26 新基本盘 33 参数敏感性排名图（模板照 C-32 make_sat_figs.py）
# 水循环 19 / 碳循环 14，各 2x4 面板（8 观测列），每面板按该列敏感度降序，top10 深色高亮
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path

BASE = Path('/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/sat33')
FIGD = BASE / 'figures'
FIGD.mkdir(exist_ok=True)
VARS = ['x1','x2','x3','w','TL','Catm','Cocean','ALK']
# 33 可估计 = 19 水循环 + 14 碳循环（行号，2026-08-26 新基本盘，12 常数已剔除）
WATER_ROWS = {1,2,3,4,5,6,7,8,25,26,27,28,29,30,31,32,33,34,42}
CARB_ROWS  = {9,10,11,12,14,15,16,17,35,36,37,38,39,40}

rows = {}   # name -> (row, {var: std})
with open(BASE / 'sensitivity_long33.txt') as f:
    for ln in f:
        if ln.startswith('#') or not ln.strip():
            continue
        p = ln.split()
        idx, name, row = int(p[0]), p[1], int(p[2])
        vals = dict(zip(VARS, [float(x) for x in p[3:11]]))
        if name not in rows:
            rows[name] = (row, vals)

water = sorted([(nm, rw, vv) for nm, (rw, vv) in rows.items() if rw in WATER_ROWS], key=lambda t: t[1])
carb  = sorted([(nm, rw, vv) for nm, (rw, vv) in rows.items() if rw in CARB_ROWS], key=lambda t: t[1])
print('water params:', len(water), ' carb params:', len(carb), ' total:', len(rows))

# top10：水循环按 x2、碳循环按 Catm（规则 3.2 口径）
water_top = [nm for nm, _, vv in sorted(water, key=lambda t: -t[2]['x2'])][:10]
carb_top  = [nm for nm, _, vv in sorted(carb,  key=lambda t: -t[2]['Catm'])][:10]
print('water top10:', water_top)
print('carb  top10:', carb_top)

def plot_sens(items, topset, c_top, c_rest, fname, title):
    fig, axes = plt.subplots(2, 4, figsize=(19, 9))
    for j, var in enumerate(VARS):
        ax = axes[j // 4, j % 4]
        order = sorted(items, key=lambda t: t[2][var], reverse=True)
        for k, (nm, rw, vals) in enumerate(order):
            c = c_top if nm in topset else c_rest
            ax.bar(k, vals[var], color=c, width=0.85)
        ax.set_title('%s - sensitivity ranking' % var, fontsize=11)
        ax.set_xticks(range(len(order)))
        ax.set_xticklabels([nm for nm, _, _ in order], rotation=90, fontsize=5)
        ax.grid(alpha=0.3, axis='y')
        ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0))
    fig.suptitle(title, fontsize=13, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(FIGD / fname, dpi=150)
    print('saved', fname)

plot_sens(water, set(water_top), '#1F4E79', '#9DC3E6',
          'sensitivity_ranking_water19.png',
          'Sensitivity ranking of water-cycle parameters across the 10VCC state variables')
plot_sens(carb, set(carb_top), '#1E6B3A', '#9CD9A5',
          'sensitivity_ranking_carb14.png',
          'Sensitivity ranking of carbon-cycle parameters across the 10VCC state variables')
print('ALL_DONE')

"""两组纵向合图：上水循环W20、下碳循环W500，每组保留原2x4排名面板。"""
from pathlib import Path
import sys
import json
import csv
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent / "twin_work_3x3" / "python_deps"))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch

VARS=["x1","x2","x3","w","TL","Catm","Cocean","ALK"]
WATER={1,2,3,4,5,6,7,8,25,26,27,28,29,30,31,32,33,34,42}
CARBON={9,10,11,12,14,15,16,17,35,36,37,38,39,40}
EXPECTED_WATER=["kappa","c1","b","sigma","c13","c2","c15","lambda","c4","c12"]
EXPECTED_CARBON=["c20","c16","c30","c19","c28","c17","c23","c26","c21","c29"]

def read_results(folder):
    rows=[]
    for line in (folder/"sensitivity_W20_C500.txt").read_text().splitlines():
        if not line.strip() or line.startswith("#"): continue
        p=line.split()
        assert len(p)==14, p
        r=dict(index=int(p[0]),name=p[1],row=int(p[2]),group=p[3],window=float(p[4]),samples=int(p[5]),
               values=np.array(p[6:],dtype=float))
        group="WATER" if r["row"] in WATER else "CARBON"
        assert r["row"] in WATER|CARBON
        assert r["group"]==group
        assert r["window"]==(20 if group=="WATER" else 500)
        assert r["samples"]==round(r["window"]*100)
        assert np.isfinite(r["values"]).all() and (r["values"]>=0).all()
        trace=np.loadtxt(folder/f"sensitivity_trace_{r['name']}.txt")
        assert trace.shape==(round(r["window"]*10),9), (r["name"],trace.shape)
        assert np.isfinite(trace).all() and (trace[:,1:]>=0).all()
        np.testing.assert_allclose(trace[:,0],np.arange(1,len(trace)+1)*.1,rtol=0,atol=1e-8)
        rows.append(r)
    assert len(rows)==33 and len({r["row"] for r in rows})==33
    assert {r["row"] for r in rows}==WATER|CARBON
    return rows

def main():
    folder=Path(sys.argv[1]) if len(sys.argv)>1 else BASE/"results"
    rows=read_results(folder)
    font=BASE/"times.ttf"
    font_manager.fontManager.addfont(str(font))
    family=font_manager.FontProperties(fname=str(font)).get_name()
    plt.rcParams.update({"font.family":family,"font.size":11,"axes.titlesize":13,
                         "axes.labelsize":11,"xtick.labelsize":9,"ytick.labelsize":10,
                         "pdf.fonttype":42,"ps.fonttype":42})
    fig=plt.figure(figsize=(19,18),constrained_layout=True)
    fig.suptitle("Parameter sensitivity under separate measurement windows",fontsize=18)
    subfigs=fig.subfigures(2,1,hspace=.035)
    audit={"ensemble_members":40,"std_ddof":1,"integration_dt_TU":.01,
           "statistic":"native-step mean ensemble standard deviation",
           "layout":"two vertically stacked groups; each group 2x4 panels","groups":{},"panels":[]}
    exports=[]
    for sf,group,title,key,deep,pale,expected in [
        (subfigs[0],"WATER","Water cycle parameters (0-20 TU)",1,"#1F4E79","#9DC3E6",EXPECTED_WATER),
        (subfigs[1],"CARBON","Carbon cycle parameters (0-500 TU)",5,"#1E6B3A","#9CD9A5",EXPECTED_CARBON)]:
        items=sorted([r for r in rows if r["group"]==group],key=lambda r:r["row"])
        selected=sorted(items,key=lambda r:-r["values"][key])[:10]
        top=[r["name"] for r in selected]
        sf.suptitle(title,fontsize=16,fontweight="bold")
        axes=sf.subplots(2,4)
        for j,var in enumerate(VARS):
            ax=axes[j//4,j%4]
            order=sorted(items,key=lambda r:-r["values"][j])
            labels=[r["name"] for r in order]
            values=[r["values"][j] for r in order]
            colors=[deep if name in top else pale for name in labels]
            edges=["#222222" if name in top else pale for name in labels]
            ax.bar(np.arange(len(order)),values,color=colors,edgecolor=edges,linewidth=.45,width=.85)
            ax.set_title(var,pad=8)
            ax.set_xticks(np.arange(len(order)),labels=labels,rotation=90)
            ax.tick_params(axis="x",length=2,pad=3)
            ax.set_ylim(bottom=0)
            ax.set_axisbelow(True)
            ax.grid(alpha=.25,axis="y",linewidth=.6)
            ax.ticklabel_format(axis="y",style="sci",scilimits=(0,0))
            if j%4==0: ax.set_ylabel("Mean ensemble standard deviation")
            if j==0:
                ax.legend(handles=[Patch(facecolor=deep,edgecolor="#222222",label=f"Top 10 ({VARS[key]})"),
                                   Patch(facecolor=pale,edgecolor=pale,label="Other parameters")],
                          fontsize=9,frameon=False,loc="upper right")
            assert len(ax.patches)==len(order)
            assert [x.get_text() for x in ax.get_xticklabels()]==labels
            audit["panels"].append({"group":group,"variable":var,"parameters":labels,"bars":len(order)})
            for rank,r in enumerate(order,1):
                exports.append([group,r["name"],r["row"],r["window"],r["samples"],var,rank,r["values"][j],r["name"] in top])
        audit["groups"][group]={"count":len(items),"window_TU":items[0]["window"],"top10":top,
                               "matches_existing_C80_top10_order":top==expected,
                               "matches_existing_C80_top10_set":set(top)==set(expected)}
    assert len(fig.axes)==16
    folder.mkdir(exist_ok=True)
    for ext in ("png","pdf"):
        fig.savefig(folder/f"sensitivity_W20_C500_combined.{ext}",dpi=300,bbox_inches="tight",facecolor="white")
    plt.close(fig)
    with (folder/"sensitivity_rankings.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.writer(f)
        w.writerow(["parameter_group","parameter","model_row","window_TU","native_samples","response_variable","rank","sensitivity","top10_selected"])
        w.writerows(exports)
    (folder/"sensitivity_audit.json").write_text(json.dumps(audit,indent=2),encoding="utf-8")
    print(json.dumps(audit["groups"]),flush=True)
    print("SENSITIVITY_FIGURE_COMPLETE",flush=True)

if __name__=="__main__": main()

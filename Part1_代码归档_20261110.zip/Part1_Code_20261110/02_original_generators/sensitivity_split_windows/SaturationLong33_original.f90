! 长 trace 自由积分探针（33 可估计参数全测量版）：19 水循环 + 14 碳循环 × 8 观测列集合标准差。
! 2026-08-26 新基本盘：12 常数（c25/E/od/spd/ss/sm/slm/old/gamma/sls/om/olm）不测量。
! 参数顺序 = MCPE42.f90 45 参数行号去掉 12 常数后的 33 个可估计参数。
! 采样两段式：0-2000 TU stride=10（0.1 TU，保快变量），2000-20000 TU stride=1000（10 TU）。
program SaturationLong33
    use RKmethod
    implicit none

    integer, parameter :: nens=40, nparam=33, nout=8
    integer(kind=8), parameter :: spinup_steps=1000000_8       ! 10,000 TU
    integer(kind=8), parameter :: sens_steps=2000_8            ! 前 20 TU（敏感性均值窗口）
    integer(kind=8), parameter :: trace_steps=2000000_8        ! 20,000 TU（长 trace）
    integer(kind=8), parameter :: fine_steps=200000_8          ! 前 2,000 TU 精细采样
    integer(kind=8), parameter :: fine_stride=10_8             ! 0.10 TU
    integer(kind=8), parameter :: coarse_stride=1000_8         ! 10 TU（2,000-20,000 TU 段）
    integer(kind=8) :: it, absolute_it
    integer :: ip, ie, iy, unit_id, trace_unit, nsample
    real(kind=dp) :: x_spin(10), x_ens(10,nens), values(nens,nout)
    real(kind=dp) :: mean_y(nout), std_y(nout), sum_std(nout), sens(nparam,nout)
    real(kind=dp) :: perturb(nens), amplitude
    character(len=96) :: filename
    ! MCPE42 行号（45 参数去掉 12 常数：13,18,19,20,21,22,23,24,41,43,44,45）
    integer, parameter :: prow(nparam) = [ &
        1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17, &
        25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,42]
    character(len=12), parameter :: pname(nparam) = [character(len=12) :: &
        'sigma','kappa','b','c1','c2','c6','c12','c15','c18','c20','c21','c22', &
        'c26','c28','c29','c30', &
        'c3','c4','c5','c7','c8','c9','c10','c11','c13','c14', &
        'c16','c17','c19','c23','c24','c27','lambda']

    call reset_all_46()
    x_spin=0.0_dp; x_spin(2)=1.0_dp
    do it=1,spinup_steps
        call adv_true_state(x_spin,it,10)
    end do

    ! 对称 0.25%...5% 扰动（与 canonical20 相同分布，排名可比）
    do ie=1,nens
        amplitude=0.0025_dp*real((ie+1)/2,dp)
        if (mod(ie,2)==1) amplitude=-amplitude
        perturb(ie)=amplitude
    end do

    sens=0.0_dp
    open(newunit=unit_id,file='sensitivity_long33.txt',status='replace',action='write')
    write(unit_id,'(A)') '# 20-TU time-mean ensemble std after one-parameter perturbation (full model, 33 params: 19 water + 14 carbon)'
    write(unit_id,'(A)') '# index name row x1 x2 x3 w TL Catm Cocean ALK'

    do ip=1,nparam
        do ie=1,nens
            x_ens(:,ie)=x_spin
        end do
        sum_std=0.0_dp
        nsample=0
        write(filename,'("saturation_std_long33_",A,".txt")') trim(pname(ip))
        open(newunit=trace_unit,file=trim(filename),status='replace',action='write')
        write(trace_unit,'(A)') '# time_TU x1_std x2_std x3_std w_std TL_std Catm_std Cocean_std ALK_std'

        do it=1,trace_steps
            absolute_it=spinup_steps+it
            do ie=1,nens
                call reset_all_46()
                call set_one_parameter(ip, perturb(ie))
                call adv_true_state(x_ens(:,ie),absolute_it,10)
            end do
            call extract_outputs(x_ens,values)
            do iy=1,nout
                mean_y(iy)=sum(values(:,iy))/real(nens,dp)
                std_y(iy)=sqrt(sum((values(:,iy)-mean_y(iy))**2)/real(nens-1,dp))
            end do
            if (it<=sens_steps) then
                sum_std=sum_std+std_y
            end if
            ! 两段采样：前 fine_steps 用 fine_stride，之后用 coarse_stride
            if (mod(it,fine_stride)==0_8 .or. (it>fine_steps .and. mod(it,coarse_stride)==0_8)) then
                write(trace_unit,'(F12.2,8(1X,ES18.8))') real(it,dp)*0.01_dp,std_y
            end if
        end do
        sens(ip,:)=sum_std/real(sens_steps,dp)
        write(unit_id,'(I3,1X,A12,I3,8(1X,ES18.8))') ip,trim(pname(ip)),prow(ip),sens(ip,:)
        close(trace_unit)
        write(*,'(A,I3,1X,A,I3)') 'done',ip,trim(pname(ip)),prow(ip)
    end do
    close(unit_id)

contains

    subroutine extract_outputs(x,y)
        real(kind=dp), intent(in) :: x(10,nens)
        real(kind=dp), intent(out) :: y(nens,nout)
        y(:,1)=x(1,:); y(:,2)=x(2,:); y(:,3)=x(3,:); y(:,4)=x(4,:)
        y(:,5)=x(7,:); y(:,6)=x(8,:); y(:,7)=x(9,:); y(:,8)=x(10,:)
    end subroutine extract_outputs

    ! ip 按新 33 参数顺序（45 行号去 12 常数后的压缩索引）
    subroutine set_one_parameter(index, delta)
        integer,intent(in)::index
        real(kind=dp),intent(in)::delta
        select case(index)
        case(1);  sigma=sigma*(1.0_dp+delta)
        case(2);  kappa=kappa*(1.0_dp+delta)
        case(3);  b=b*(1.0_dp+delta)
        case(4);  c1=c1*(1.0_dp+delta)
        case(5);  c2=c2*(1.0_dp+delta)
        case(6);  c6=c6*(1.0_dp+delta)
        case(7);  c12=c12*(1.0_dp+delta)
        case(8);  c15=c15*(1.0_dp+delta)
        case(9);  c18=c18*(1.0_dp+delta)
        case(10); c20=c20*(1.0_dp+delta)
        case(11); c21=c21*(1.0_dp+delta)
        case(12); c22=c22*(1.0_dp+delta)
        case(13); c26=c26*(1.0_dp+delta)
        case(14); c28=c28*(1.0_dp+delta)
        case(15); c29=c29*(1.0_dp+delta)
        case(16); c30=c30*(1.0_dp+delta)
        case(17); c3=c3*(1.0_dp+delta)
        case(18); c4=c4*(1.0_dp+delta)
        case(19); c5=c5*(1.0_dp+delta)
        case(20); c7=c7*(1.0_dp+delta)
        case(21); c8=c8*(1.0_dp+delta)
        case(22); c9=c9*(1.0_dp+delta)
        case(23); c10=c10*(1.0_dp+delta)
        case(24); c11=c11*(1.0_dp+delta)
        case(25); c13=c13*(1.0_dp+delta)
        case(26); c14=c14*(1.0_dp+delta)
        case(27); c16=c16*(1.0_dp+delta)
        case(28); c17=c17*(1.0_dp+delta)
        case(29); c19=c19*(1.0_dp+delta)
        case(30); c23=c23*(1.0_dp+delta)
        case(31); c24=c24*(1.0_dp+delta)
        case(32); c27=c27*(1.0_dp+delta)
        case(33); lambda=lambda*(1.0_dp+delta)
        end select
    end subroutine set_one_parameter
end program SaturationLong33

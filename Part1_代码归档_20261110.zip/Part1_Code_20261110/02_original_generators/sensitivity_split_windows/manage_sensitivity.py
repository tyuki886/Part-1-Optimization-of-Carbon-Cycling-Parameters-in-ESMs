"""隔离部署、检查与下载分窗口敏感性实验。"""
from pathlib import Path
import getpass
import sys
import paramiko
BASE=Path(__file__).resolve().parent
REMOTE="/public/home/hou/wyh/MCPE26.0/sensitivity_split_windows"
FILES=["SensitivityWindows33.f90","RKmethod.f90","plot_sensitivity_combined.py","run_sensitivity.pbs","README.md"]
def run(c,cmd):
    _,out,err=c.exec_command(cmd,timeout=120)
    text=out.read().decode("utf-8","replace")
    errors=err.read().decode("utf-8","replace")
    print(text,flush=True)
    if errors: print(errors,flush=True)
    if out.channel.recv_exit_status(): raise RuntimeError("Remote command failed")
    return text
c=paramiko.SSHClient()
c.load_system_host_keys()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect("222.195.137.80",username="hou",password=getpass.getpass("New HPC password: "),
          timeout=30,look_for_keys=False,allow_agent=False)
try:
    action=sys.argv[1]
    if action=="deploy":
        run(c,f"mkdir -p {REMOTE}/logs {REMOTE}/smoke")
        with c.open_sftp() as s:
            for name in FILES: s.put(str(BASE/name),REMOTE+"/"+name)
            s.put("C:/Windows/Fonts/times.ttf",REMOTE+"/times.ttf")
        run(c,f"""set -eu
cd {REMOTE}
gfortran -O3 -ffree-line-length-none -c RKmethod.f90
gfortran -O3 -ffree-line-length-none SensitivityWindows33.f90 RKmethod.o -o sensitivity_windows33
bash -n run_sensitivity.pbs
cd smoke
SENS_SMOKE=1 ../sensitivity_windows33
test "$(grep -vc '^#' sensitivity_W20_C500.txt)" -eq 1
echo SMOKE_PASS
cd ../logs
qsub {REMOTE}/run_sensitivity.pbs
""")
    elif action=="status":
        run(c,f"""qstat -u hou || true
tail -n 5 {REMOTE}/logs/SensW20C500.o* 2>/dev/null || true
ls -l {REMOTE}/results/COMPLETE {REMOTE}/results/sensitivity_W20_C500_combined.* 2>/dev/null || true
""")
    elif action=="collect":
        with c.open_sftp() as s:
            s.stat(REMOTE+"/results/COMPLETE")
            dest=BASE/"results"
            dest.mkdir(exist_ok=True)
            for name in s.listdir(REMOTE+"/results"):
                s.get(REMOTE+"/results/"+name,str(dest/name))
                print("Downloaded",name,flush=True)
    else:
        raise ValueError(action)
finally:
    c.close()

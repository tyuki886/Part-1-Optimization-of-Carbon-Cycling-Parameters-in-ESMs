"""Current-figure c28 source audit; do not alter historical figures/documents."""
from pathlib import Path
import hashlib,json,re,collections,zipfile,xml.etree.ElementTree as ET
import numpy as np
B=Path(__file__).resolve().parent;C=B.parents[1];P=C.parent;F=Path(r'D:\SRDP\论文大作！\MCPE26.0\最终成图')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
remote=json.loads((B/'remote_c28_audit.json').read_text())
counts=collections.Counter(Path(r['path']).parts[7] for r in remote['initial_parameter_checks'])
sourcechecks=[]
for r in remote['sources']:
 tail=r['path'].split('/MCPE26.0/',1)[1];p=C/tail
 sourcechecks.append({**r,'local_path':str(p),'local_matches_remote':p.exists() and sha(p)==r['sha256']})
images=sorted(F.rglob('*.png'));bysize=collections.defaultdict(list);hashcache={}
for q in P.rglob('*.png'):bysize[q.stat().st_size].append(q)
def cachedsha(q):
 if q not in hashcache:hashcache[q]=sha(q)
 return hashcache[q]
records=[]
for p in images:
 n=p.name;rel=str(p.relative_to(F));matches=[str(q) for q in bysize[p.stat().st_size] if cachedsha(q)==cachedsha(p)]
 if n in ['psd_combined_7panels.png','model_comparison_PSD_correct_units.png']:
  status='旧轨迹版本需替换';basis='来源为awi_power_combined旧轨迹；AWI对应现存RKmethod c28=10。correct_units仅更换谱密度单位，没有重跑。本次原源码回放未完全复现旧轨迹，不能据现存源码断言旧二进制只存在c28一项差异。'
 elif 'timeline' in n:
  status='非数值积分图';basis='参数入场时序示意；c28真值不决定图形，不需要因本次修正重画。'
 elif 'sensitivity' in n or 'saturation' in n:
  status='关联源码基准为1；历史运行未逐个重放';basis='sensitivity_split_windows、saturation_remeasure与alk_top10模块初始化/重置c28=1；扰动实验允许c28围绕1变化。旧C80饱和图还需区分旧参数名单，不能替代最新22参数图。'
 elif 'twin' in n:
  status='来源指向c28=1模型；旧二进制绑定未完全核实';basis='AWI MCPE21.0/twin_work轨迹，主程序use RKmethod；该项目现存模块为1，但孪生目录未留独立RKmethod源码或运行参数快照。'
 elif n.startswith(('V2_','V3_')):
  status='独立排放源码及重置基准为1';basis='AWI MCPE21.0/freeze_src/RKmethod.f90及freeze.f90明确c28=1，plot_freeze.py输入results_C66/freeze；旧运行没有逐份参数快照核验。'
 elif 'nonlinear' in n:
  status='关联诊断编译源码基准为1';basis='C80 diagtraj编译入口引用MCPE26.0/RKmethod.f90，c28基准1。来自seed0原诊断轨迹，未重新运行历史CDA。'
 elif 'C80' in n:
  status='关联C80源码基准为1；属历史设计';basis='C80编译引用MCPE26.0/RKmethod c28=1。该图不是当前同步MCPE12–30方案，不能与当前方案混用。'
 elif any(x in rel for x in ['两项功率谱机制实验','carbon_feedback_controlled','matched_window']):
  status='当前机制实验c28参考值1';basis='独立反馈/匹配实验模块c28=1；新参数干预分支的真值记录纳入本次825份检查。'
 elif any(x in n.lower() for x in ['rmse','parameter','power_spectra','taylor','rate_sync']):
  status='当前MCPE关联运行真值检查为1';basis='sync_four_groups及配套基线/谱实验：初始参数第15行真值1；估计值和10%偏差允许非1。图片逐文件来源匹配另列。'
 else:
  status='需补充来源';basis='当前映射未覆盖，不能宣称已排除c28问题。'
 records.append({'file':rel,'sha256':sha(p),'source_matches':matches,'status':status,'basis':basis,'historical_copy':('before_' in n or 'carbon_legend_only' in n)})
# Numerical diagnostic of archived twin ALK tendency (not exact RK4 replay).
twin=[]
for p in (C/'awi_twin_original').glob('twin_x2_*.txt'):
 a=np.loadtxt(p);t=a[:,0];co=a[:,9];alk=a[:,10];d=np.gradient(alk,t);idx=np.arange(2,len(t)-2)
 errors={}
 for c28 in [1.,10.]:
  rhs=.0018-2*.00009*co*np.maximum(alk-.5*co+c28,0)
  errors[str(c28)]=float(np.sqrt(np.mean((d[idx]-rhs[idx])**2)))
 twin.append({'file':str(p),'derivative_RMS_residual':errors,'method':'centered finite difference, rounded archived states; diagnostic only, not exact execution provenance'})
# Locate affected embedded images without rewriting Word.
embedded=[]
bad={r['sha256']:r['file'] for r in records if r['status']=='旧轨迹版本需替换'}
for doc in [F/'Optimization of Carbon Cycling Parameters in ESM_2.0.docx',F/'Optimization of Carbon Cycling Parameters in ESM_2.1_polished.docx',F/'全文修订与实验审查_20260915/Optimization of Carbon Cycling Parameters in ESM_2.2_revised.docx']:
 with zipfile.ZipFile(doc) as z:
  for name in z.namelist():
   if name.startswith('word/media/'):
    h=hashlib.sha256(z.read(name)).hexdigest()
    if h in bad:embedded.append({'document':str(doc),'media':name,'matched_figure':bad[h]})
out={'scope':str(F),'figure_count':len(records),'figures':records,'remote_initial_count':remote['initial_count'],'remote_initial_truth_not1':remote['initial_truth_not1'],'source_checks':sourcechecks,'run_record_counts':dict(counts),'twin_tendency_check':twin,'affected_embedded_images':embedded}
(B/'current_figures_c28_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print('FIGURES',len(records),'STATUSES',dict(collections.Counter(r['status'] for r in records)))
print('COUNTS',dict(counts));print('TWIN',twin);print('EMBEDDED',embedded)

"""Compare unchanged-source replay with archived and corrected trajectories."""
from pathlib import Path
import numpy as np,json,hashlib
B=Path(__file__).resolve().parent
old=B.parents[1]/'awi_power_combined'
completion=json.loads((B/'original_completion.json').read_text())
records=[]
for r in completion:
 for name,meta in r['files'].items():
  p=B/'replay_original'/('run'+str(r['n']))/name
  assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['sha256']
  a=np.loadtxt(p)
  for lab,q in [('archive',old/name),('corrected1',B/('run'+str(r['n']))/name)]:
   d=np.loadtxt(q);ix=np.flatnonzero(np.any(a!=d,axis=1))
   row={'file':name,'comparison':'original10_replay_vs_'+lab,'equal':len(ix)==0,'first_different_postspinup_TU':None if len(ix)==0 else float(a[ix[0],0]),'max_abs_difference':float(np.max(np.abs(a-d)))}
   records.append(row);print(row)
(B/'original_replay_comparison.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
diagnostics=[]
for label,folder in [('archived',old),('original10_replay',B/'replay_original'/'run10'),('corrected1',B/'run10')]:
 co=np.loadtxt(folder/'Cocean_10var.txt');alk=np.loadtxt(folder/'alk_10var.txt')
 assert np.array_equal(co[:,0],alk[:,0])
 t=alk[:,0];c=co[:,1];a=alk[:,1];d=np.gradient(a,t);valid=(t>=1000000)&(t<=1999980)&(c>0)
 errors={}
 for c28 in [1.,10.]:
  rhs=.0018-2*.00009*c*np.maximum(a-.5*c+c28,0)
  errors[str(c28)]=float(np.sqrt(np.mean((d[valid]-rhs[valid])**2)))
 inferred=(.0018-d[valid])/(2*.00009*c[valid])-a[valid]+.5*c[valid]
 row={'version':label,'method':'10-TU centered finite difference; continuous tendency diagnostic, not exact discrete execution proof','RMS_tendency_residual':errors,'active_branch_implied_c28_median':float(np.median(inferred))}
 diagnostics.append(row);print(row)
(B/'carbon_tendency_diagnostic.json').write_text(json.dumps(diagnostics,indent=2),encoding='utf-8')

"""Package corrected figures and a source-qualified c28 audit; retain old files."""
from pathlib import Path
import json,hashlib,shutil
B=Path(__file__).resolve().parent
D=Path(r'D:\SRDP\论文大作！\MCPE26.0\最终成图\c28统一为1_重跑与图件自查_20260915')
A=json.loads((B/'current_figures_c28_audit.json').read_text(encoding='utf-8'))
S=json.loads((B/'spectral_results.json').read_text())
R=json.loads((B/'original_replay_comparison.json').read_text())
def rec(v,m,version='new'):return next(r for r in S if r['variable']==v and r['model']==m and r['version']==version)
lines=['# c28统一为1：七/十变量重跑与论文图件自查', '', '日期：2026-09-15。审计对象为本轮交付前“最终成图”目录及其子目录内的39张PNG，包含历史备份；不等于39项独立实验。本报告是c28来源专项检查，不是对全部论文公式、估计器和结论的全面认证。', '',
'## 1. 结论与需要立即替换的图', '',
'已从AWI原始power目录重新下载源码，在新超算将RKmethod.f90中的c28=10改为c28=1，七变量和十变量均重新编译、起转并积分。新主图为 `model_comparison_PSD_c28_1.png`。旧数据和旧图未覆盖，Word未在本轮自动改写。', '',
'旧 `psd_combined_7panels.png` 及其单位修正版 `全文修订与实验审查_20260915/图片/model_comparison_PSD_correct_units.png` 不应继续作为当前c28=1模型的谱比较图。旧目录现存模块为c28=10，且旧ALK轨迹的方程残差诊断独立支持接近10的值。', '',
'当前MCPE、CDA配套实验检查的825份initial_parameters.txt中，c28真值栏全部为1，未发现真值10。它们包含正式、预检及配套计算记录，不是825个独立科学试验。14个被检查的相关远程模块与本地源码哈希一致。不能因此宣称所有历史二进制均已复现；各图证据级别见第6节。', '',
'“c28应该是1”指参考真值/标准模型。偏差孪生初值1.1、参数扰动、MCPE估计后的非1数值不自动构成配置错误；不能为统一真值而把估计轨迹强行锁为1。', '',
'## 2. 实际重跑与数据核验', '',
'正式作业25737.comput100已完成；其之前的25736因Python依赖路径缺失而在数值运行前失败，修复依赖后重新提交。另以原c28=10源码提交25738.comput100作隔离核验，两个模型均完成。每个输出文件均核对行数、有限值、时间间隔以及下载前后的SHA-256；真实Fortran退出记录均成功。', '',
'正式修正版与本轮下载的原RKmethod文本只有c28=10.0_dp改为1.0_dp一处差异，两个主程序未改。原源码快照保存在original目录，正式修正版在本实验目录根。未修改AWI历史原件。', '',
'保留原设置：RK4、dt=0.01 TU、七/十变量分别起转10000 TU，随后积分2000000 TU；输出各变量的时长与采样间隔沿用AWI主程序。起转后的文件时间重新从0开始，不能把相对窗口误写成绝对实验时间。', '',
'谱处理保留原窗口、分段和去均值方式，无手工增加波动、无挑选seed。推荐主图使用density型谱估计，换频率单位时同步换PSD单位。原样式核对版保留旧spectrum及其显示缩放，仅供对照旧图；两版纵轴数值不应混用。', '',
'| 变量 | 起转后谱窗口（TU） | 从积分开始计的窗口（TU） | 保存间隔（TU） | 分段长度（TU） | 频率单位 |',
'|---|---:|---:|---:|---:|---|']
for v in ['x2','w','eta','TL','Catm','Cocean','ALK']:
 r=rec(v,'10');dt={'x2':.1,'w':1,'eta':1,'TL':1,'Catm':1,'Cocean':10,'ALK':10}[v]
 lines.append('| {} | {}–{} | {}–{} | {} | {} | {}⁻¹ |'.format(v,*r['postspinup_window_TU'],*r['absolute_window_TU'],dt,r['segment_TU'],r['unit']))
lines+=['', 'Cocean/ALK使用整个选定窗口，端点包含规则使实际段时长按样本数计算，与端点之差略有区别。x2、w、TL、eta、Catm使用Hann窗；全记录碳谱使用boxcar；均作常数去均值。', '',
'## 3. 改正后还能不能说“水循环波峰都降低”？', '',
'不能。本轮相同设置下，x2及eta的最大显示谱峰高于七变量，w和TL较低。总方差与单个最大谱峰不是同一指标。以下比值都为新十变量÷本轮七变量；最大峰分别在各自0<f≤1.5显示范围内取值，并非必然同一个频点。', '',
'| 变量 | 总方差比 | 最大显示谱峰比 | 本次结果 |', '|---|---:|---:|---|']
for v in ['x2','w','eta','TL']:
 a=rec(v,'7');b=rec(v,'10');vr=b['variance']/a['variance'];pr=b['peak_PSD']/a['peak_PSD']
 lines.append(f'| {v} | {vr:.4f} | {pr:.4f} | '+('最大显示谱峰较高' if pr>1 else '最大显示谱峰较低')+' |')
lines+=['', '这是本次有限时间、单个初始条件实现的结果，不是显著性检验，也不证明所有初始条件下都如此。不能把该结果写成“所有水循环模态受到抑制”。', '',
'新十变量长碳窗口中，Cocean均值约{:.4f}、ALK均值约{:.4f}；旧归档对应均值约{:.4f}、{:.4f}。旧ALK负均值不能继续作为当前c28=1模型的性质来解释。'.format(rec('Cocean','10')['mean'],rec('ALK','10')['mean'],rec('Cocean','10','archived')['mean'],rec('ALK','10','archived')['mean']), '',
'## 4. 原源码回放与来源差异', '',
'同环境下，原c28=10模块与改为1模块产生的七变量三个输出文件逐点完全相等。这支持七变量计算路径不依赖c28。它不是“十变量关闭全部反馈”的等价性测试，不能替代对反馈开关逐项实施的核查。', '',
'但旧归档七变量的w/TL与eta分别从起转后7829 TU和7833 TU开始不再与本轮回放完全相同，x2短文件完全一致。原c28=10十变量回放也未逐点复现旧归档。因此旧轨迹与新轨迹的所有差别不能归因于c28；历史编译环境、数值路径或生成版本尚未完整绑定，不能在本次证据不足时选定其中一个原因。', '',
'独立诊断：在长碳窗口用保存轨迹近似ALK时间导数，代入ALK′=0.0018−2×0.00009×Cocean×max(ALK−0.5×Cocean+c28,0)。旧归档活跃分支反推c28中位数约9.981；本次原值回放约9.981；新修正版约1.001。旧归档采用10时导数RMS残差约6.08×10⁻⁵，采用1时约1.85×10⁻³。此诊断支持旧数据的c28≈10，但有限采样差分不是旧二进制执行证明。', '',
'为避免来源混淆，额外提供 `water_spectra_c28_controlled_comparison.png`：七变量、同环境c28=1十变量、同环境c28=10十变量。它比直接对照旧归档更适于检查c28改值的影响；仍需区分谱峰变化与有限时长统计波动。', '',
'## 5. 对论文的影响与交付图使用', '',
'1. 推荐替换图：model_comparison_PSD_c28_1.png（规范PSD）。',
'2. psd_combined_7panels_c28_1_legacy_scale.png：原纵轴样式核对版，不与PSD数值混用。',
'3. water_spectra_c28_controlled_comparison.png：同环境单参数对照实验。',
'4. water_spectra_c28_audit_overlay.png：新图与旧归档的来源审计对照，不能单独作c28因果证据。', '',
'已以嵌入图片内容哈希确认：ESM_2.2_revised.docx中的word/media/image18.png仍是旧轨迹单位修正版。该谱图及相关特征周期表、谱峰高低文字需要同步更新；旧“长窗口ALK为负”的讨论应撤回或明确属于旧参数版本。本轮未改写Word，避免把图件专项修正与全文编辑混在一起。早期Word经WPS压缩可能无法通过原PNG哈希直接匹配，不能把未匹配当作没有引用旧图。', '',
'c26的AWI写法为0.01×rrain(0.009)=0.00009，与当前单系数形式等价，不能仅看c26字面不同就再认定另一个百倍参数错误。', '',
'实验总流程规则中冲突的c28=10表项已改为1，并增加最新规则。旧源码快照、历史图和原始数据保留，用于溯源，不再作为当前标准模型默认运行入口。', '',
'## 6. 39张图逐项核验', '',
'“内容匹配”表示已在项目目录找到与交付图SHA-256完全相同的副本，可能是改名副本；它本身不证明旧二进制参数。源码、初始运行记录、轨迹诊断是不同强度的证据。3张图未找到内容完全一致的本地来源副本，仍需保留这一限制。', '',
'| 图件（相对最终成图目录） | c28审计状态 | 项目副本内容匹配 |', '|---|---|---|']
for r in A['figures']:lines.append('| '+r['file'].replace('\\','/')+' | '+r['status']+' | '+('是' if r['source_matches'] else '未找到')+' |')
lines+=['', '### 各类证据说明', '']
seen=set()
for r in A['figures']:
 if r['status'] not in seen:lines.append('- '+r['status']+'：'+r['basis']);seen.add(r['status'])
lines+=['', '额外孪生轨迹检查：两条旧ALK轨迹在c28=1时的导数RMS残差约1.97–1.98×10⁻⁵，设10则约1.84–1.85×10⁻²，进一步支持该孪生图使用1；仍不替代缺失的旧模块/二进制绑定。', '',
'未找到同哈希来源副本的图：'+ '、'.join(r['file'] for r in A['figures'] if not r['source_matches'])+'。其中V2/V3已有AWI排放程序初始化与重置c28=1的源码证据，但没有逐份旧运行参数快照；旧unit_cleanup备份有当前MCPE来源链证据，尚未逐字节绑定到绘图输入。', '',
'边界：C80的RMSE/修正率、旧18面板饱和图属于历史方案，不应与当前同步MCPE12–30/22独立参数设计混用。这是额外发现的版本标注问题，不是c28=10的证据。', '',
'## 7. 复现与留档', '',
'完整源码、数据、回执与JSON证据：`'+str(B)+'`。', '',
'新超算目录：`/public/home/hou/wyh/MCPE26.0/paper_revision_20260915/c28_corrected_comparison`。', '',
'审计JSON保存每图哈希与来源路径、825份初始值检查、模块哈希、谱统计、原源码回放对比与ALK导数诊断。原始多百万TU轨迹保留在工作区与超算，不重复复制进论文图片目录。没有额外生成或下载PDF。']
report='\n'.join(lines)+'\n'
(B/'重跑结果与c28图件自查.md').write_text(report,encoding='utf-8')
D.mkdir(parents=True,exist_ok=True)
for p in (B/'figures').glob('*.png'):shutil.copy2(p,D/p.name)
shutil.copy2(B/'重跑结果与c28图件自查.md',D/'重跑结果与c28图件自查.md')
(D/'核验记录').mkdir(exist_ok=True)
for name in ['current_figures_c28_audit.json','spectral_results.json','original_replay_comparison.json','carbon_tendency_diagnostic.json','original_manifest.json','completion.json','original_completion.json','remote_c28_audit.json']:
 shutil.copy2(B/name,D/'核验记录'/name)
for p in (D).glob('*.png'):
 assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256((B/'figures'/p.name).read_bytes()).digest()
print('DELIVERED',D);print('FIGURES',len(list(D.glob('*.png'))));print('REPORT_CHARS',len(report))

"""Original AWI integrations, c28=1, independent output directories."""
from pathlib import Path
import concurrent.futures,subprocess,hashlib,json,time,re,sys
import numpy as np
B=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
original=(B/'original/RKmethod.f90').read_text()
fixed=(B/'RKmethod.f90').read_text()
assert fixed==original.replace('c28=10.0_dp','c28=1.0_dp')
assert original.count('c28=10.0_dp')==1
replay='--verify-original' in sys.argv
if replay:(B/'replay_original').mkdir(exist_ok=True)
def run(n):
 d=(B/'replay_original' if replay else B)/f'run{n}';d.mkdir(exist_ok=False);start=time.time();exe=B/f'original_{n}' if replay else B/f'run_{n}'
 cmd=['/usr/bin/strace','-f','-e','trace=process','-o',str(d/'process.trace'),str(exe)]
 with (d/'run.log').open('w') as f:p=subprocess.run(cmd,cwd=d,stdout=f,stderr=subprocess.STDOUT)
 trace=(d/'process.trace').read_text();exits=[int(x) for x in re.findall(r'^\d+\s+\+\+\+ exited with (\d+) \+\+\+',trace,re.M)]
 assert p.returncode==0 or (p.returncode==255 and exits==[0,255] and 'ECHILD' in trace and 'WEXITSTATUS(s) == 0' in trace),(p.returncode,exits)
 files={}
 for q in sorted(d.glob('*var.txt')):
  a=np.loadtxt(q);assert np.isfinite(a).all(),q
  expected=40000 if q.name.startswith('x2') else 20000 if q.name.startswith('wTL') else 200000
  assert len(a)==expected,(q,len(a),expected)
  files[q.name]={'sha256':sha(q),'rows':len(a),'first_time':float(a[0,0]),'last_time':float(a[-1,0]),'min':a[:,1:].min(0).tolist(),'max':a[:,1:].max(0).tolist()}
 assert len(files)==(3 if n==7 else 5)
 out={'n':n,'c28_reference':10 if replay else 1,'dt_TU':.01,'spinup_TU':10000,'postspinup_TU':2000000,'source_sha256':sha(B/'original/RKmethod.f90' if replay else B/'RKmethod.f90'),'main_sha256':sha(B/f'RK4main{n}.f90'),'binary_sha256':sha(exe),'seconds':time.time()-start,'returncode':p.returncode,'process_exits':exits,'files':files}
 (d/'receipt.json').write_text(json.dumps(out,indent=2));print('DONE',n,out['seconds'],flush=True);return out
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:receipts=list(pool.map(run,[7,10]))
(B/('original_completion.json' if replay else 'completion.json')).write_text(json.dumps(receipts,indent=2))

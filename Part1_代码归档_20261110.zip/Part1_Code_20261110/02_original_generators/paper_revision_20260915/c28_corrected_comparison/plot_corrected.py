"""Recompute spectra from verified c28=1 runs, preserving legacy windows."""
from pathlib import Path
import ast,json,hashlib
import numpy as np
from scipy import signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
B=Path(__file__).resolve().parent;O=B/'figures';O.mkdir(exist_ok=True);LEG=B.parents[1]/'awi_power_combined'
plt.rcParams.update({'font.family':'Times New Roman','font.size':10,'path.simplify':False})
tree=ast.parse((LEG/'plot_psd_v10v7.py').read_text(encoding='utf-8'))
node=next(n for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='CFG')
cfg=eval(compile(ast.Expression(node.value),'<cfg>','eval'),{'__builtins__':{},'dict':dict})
completion=json.loads((B/'completion.json').read_text());records=[];spec={};old={};replay={}
for rec in completion:
 for name,r in rec['files'].items():
  p=B/f"run{rec['n']}"/name
  assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
for v,c in cfg.items():
 for m in ['7','10']:
  if 'f'+m not in c:continue
  for label,folder in [('new',B/f'run{m}'),('archived',LEG),('replay10',B/'replay_original'/f'run{m}')]:
   p=folder/c['f'+m];d=np.loadtxt(p);a=d[(d[:,0]>=c['trange'][0])&(d[:,0]<=c['trange'][1])]
   assert np.isfinite(a).all();np.testing.assert_allclose(np.diff(a[:,0]),1/c['fs'],rtol=0,atol=1e-8)
   y=a[:,c['col']];n=len(y) if c['nperseg']=='full' else c['nperseg'];win='boxcar' if c['nperseg']=='full' else 'hann'
   f,ps=signal.welch(y,fs=c['fs'],nperseg=n,window=win,scaling='density',detrend='constant',noverlap=n//2)
   ff=f*c['mult'];ps=ps/c['mult'];mask=ff<=1.5
   _,legacy=signal.welch(y-y.mean(),fs=c['fs'],nperseg=n,window=win,scaling='spectrum')
   value=(ff[mask],ps[mask],legacy[mask]*c['scale'])
   {'new':spec,'archived':old,'replay10':replay}[label][v,m]=value
   pk=np.flatnonzero(mask&(ff>0))[np.argmax(ps[mask&(ff>0)])]
   records.append({'variable':v,'model':m,'version':label,'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'samples':len(y),'postspinup_window_TU':c['trange'],'absolute_window_TU':[10000+t for t in c['trange']],'segment_TU':n/c['fs'],'unit':c['unit'],'mean':float(y.mean()),'variance':float(y.var()),'peak_frequency':float(ff[pk]),'peak_PSD':float(ps[pk]),'period':float(1/ff[pk]),'peak_at_first_bin':bool(pk==1)})
def save(fig,name):
 fig.savefig(O/name,dpi=300,bbox_inches='tight',pad_inches=.1);plt.close(fig)
 with Image.open(O/name) as im:
  im.thumbnail((1500,1100));im.convert('RGB').save(O/name.replace('.png','_preview.jpg'))
def draw(legacy=False):
 fig=plt.figure(figsize=(13.2,9.3));l=fig.add_gridspec(4,1,left=.075,right=.48,top=.90,bottom=.065,hspace=.63);r=fig.add_gridspec(3,1,left=.59,right=.985,top=.90,bottom=.065,hspace=.5)
 for v,a,g in [('x2','a',l[0]),('w','c',l[1]),('eta','e',l[2]),('TL','g',l[3]),('Catm','b',r[0]),('Cocean','d',r[1]),('ALK','f',r[2])]:
  ax=fig.add_subplot(g);c=cfg[v]
  for m,color,style in [('7','#24578D','--'),('10','#B52D43','-')]:
   if (v,m) in spec:
    s=spec[v,m];ax.plot(s[0],s[2 if legacy else 1],color=color,ls=style,lw=1.15)
  ax.set(title=f'({a}) {v}',xlabel='Frequency ('+c['unit']+'$^{-1}$)',ylabel='Power Spectrum' if legacy else 'PSD',xlim=(0,1.5),ylim=(0,None))
  ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,3));ax.grid(alpha=.2)
 fig.suptitle('Power spectra of the seven-variable and 10VCC models',fontsize=16,y=.987)
 fig.legend(handles=[Line2D([],[],color='#24578D',ls='--',label='Seven-variable'),Line2D([],[],color='#B52D43',label='10VCC')],loc='upper center',bbox_to_anchor=(.5,.96),ncol=2,frameon=False)
 save(fig,'psd_combined_7panels_c28_1_legacy_scale.png' if legacy else 'model_comparison_PSD_c28_1.png')
draw();draw(True)
fig,axes=plt.subplots(2,2,figsize=(12,7.5))
for ax,v in zip(axes.flat,['x2','w','eta','TL']):
 for s,col,ls in [(spec[v,'7'],'#24578D','--'),(spec[v,'10'],'#B52D43','-'),(old[v,'10'],'#777777',':')]:ax.plot(s[0],s[1],color=col,ls=ls,lw=1.2)
 ax.set(title=v,xlabel='Frequency ('+cfg[v]['unit']+'$^{-1}$)',ylabel='PSD',xlim=(0,1.5),ylim=(0,None));ax.grid(alpha=.2)
fig.legend(handles=[Line2D([],[],color='#24578D',ls='--',label='Seven-variable rerun'),Line2D([],[],color='#B52D43',label='10VCC, c28 = 1 rerun'),Line2D([],[],color='#777777',ls=':',label='Archived 10-variable')],loc='upper center',ncol=3,frameon=False)
fig.tight_layout(rect=(0,0,1,.93));save(fig,'water_spectra_c28_audit_overlay.png')
fig,axes=plt.subplots(2,2,figsize=(12,7.5))
for ax,v in zip(axes.flat,['x2','w','eta','TL']):
 for s,col,ls in [(spec[v,'7'],'#24578D','--'),(spec[v,'10'],'#B52D43','-'),(replay[v,'10'],'#228355',':')]:ax.plot(s[0],s[1],color=col,ls=ls,lw=1.2)
 ax.set(title=v,xlabel='Frequency ('+cfg[v]['unit']+'$^{-1}$)',ylabel='PSD',xlim=(0,1.5),ylim=(0,None));ax.grid(alpha=.2)
fig.legend(handles=[Line2D([],[],color='#24578D',ls='--',label='Seven-variable'),Line2D([],[],color='#B52D43',label='10VCC, c28 = 1'),Line2D([],[],color='#228355',ls=':',label='10VCC, c28 = 10')],loc='upper center',ncol=3,frameon=False)
fig.tight_layout(rect=(0,0,1,.93));save(fig,'water_spectra_c28_controlled_comparison.png')
(B/'spectral_results.json').write_text(json.dumps(records,indent=2))
for v in ['x2','w','eta','TL']:
 a=next(r for r in records if r['variable']==v and r['version']=='new' and r['model']=='7');b=next(r for r in records if r['variable']==v and r['version']=='new' and r['model']=='10')
 print(v,'variance10/7',b['variance']/a['variance'],'peak10/7',b['peak_PSD']/a['peak_PSD'])

"""只读取AWI原始谱源码；保持历史源码及数据不变。"""
from pathlib import Path
import sys,hashlib,json
B=Path(__file__).resolve().parent
sys.path.insert(0,str(B.parents[2]))
import hpc
src='/work/ab0246/wuyuhang/SRDP/output/power'
c=hpc.connect()
manifest={}
with c.open_sftp() as s:
    for name in ['RKmethod.f90','RK4main7.f90','RK4main10.f90','plot_psd_v10v7.py','job.sh']:
        p=B/'original'/name;p.parent.mkdir(parents=True,exist_ok=True)
        s.get(src+'/'+name,str(p))
        manifest[name]={'source':src+'/'+name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime':s.stat(src+'/'+name).st_mtime}
c.close()
(B/'original_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('DOWNLOADED',list(manifest))

"""Model-only power spectra using the original paper-style spectral settings.

This script is deliberately separate from the later CTL/CDA/MCPE evaluation
spectra.  In particular, the annual-band w spectrum uses the 10000-TU record,
2500-sample Welch segments, the original spectrum normalization, and the
0.5--1.5 yr^-1 display range.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
from scipy import signal
from scipy.stats import chi2


BASE = Path(__file__).resolve().parent
OUT = BASE / "model_psd_original_method"
OUT.mkdir(exist_ok=True)

BLUE = "#24578D"
RED = "#C6324B"
BLACK = "#202020"

plt.rcParams.update(
    {
        "font.family": "Times New Roman",
        "font.size": 10.5,
        "axes.titlesize": 11.5,
        "axes.labelsize": 10.5,
        "xtick.labelsize": 9.5,
        "ytick.labelsize": 9.5,
        "axes.linewidth": 0.85,
        "path.simplify": False,
    }
)


CONFIG = {
    # Water-cycle settings reproduce the original model-spectrum workflow.
    "x2": dict(
        files={"7": "x2_7var.txt", "10": "x2_10var.txt"},
        col=1,
        trange=(2000.0, 4000.0),
        fs=10.0,
        nperseg=1024,
        window="hann",
        multiplier=10.0 / 12.0,
        scale=0.0035,
        unit="Month",
        xlim=(0.0, 2.0),
        ticks=np.arange(0.0, 2.01, 0.2),
        red_noise=False,
    ),
    "w": dict(
        files={"7": "wTL_7var.txt", "10": "wTL_10var.txt"},
        col=1,
        trange=(10000.0, 20000.0),
        fs=1.0,
        nperseg=2500,
        window="hann",
        multiplier=10.0,
        scale=0.1,
        unit="Year",
        xlim=(0.5, 1.5),
        ticks=np.arange(0.5, 1.51, 0.1),
        red_noise=False,
    ),
    "eta": dict(
        files={"7": "eta_7var.txt", "10": "etaCatm_10var.txt"},
        col=1,
        trange=(10000.0, 20000.0),
        fs=1.0,
        nperseg=2500,
        window="hann",
        multiplier=100.0,
        scale=1.0,
        unit="Decade",
        xlim=(0.5, 1.5),
        ticks=np.arange(0.5, 1.51, 0.1),
        red_noise=False,
    ),
    "TL": dict(
        files={"7": "wTL_7var.txt", "10": "wTL_10var.txt"},
        col=2,
        trange=(10000.0, 20000.0),
        fs=1.0,
        nperseg=2500,
        window="hann",
        multiplier=10.0,
        scale=0.1,
        unit="Year",
        xlim=(0.5, 1.5),
        ticks=np.arange(0.5, 1.51, 0.1),
        red_noise=False,
    ),
    # Carbon variables retain their long model-only records and native scales.
    "Catm": dict(
        files={"10": "etaCatm_10var.txt"},
        col=2,
        trange=(100000.0, 200000.0),
        fs=1.0,
        nperseg=1024,
        window="hann",
        multiplier=10.0,
        scale=1.0,
        unit="Year",
        xlim=(0.0, 1.5),
        ticks=np.arange(0.0, 1.51, 0.2),
        red_noise=False,
    ),
    "Cocean": dict(
        files={"10": "Cocean_10var.txt"},
        col=1,
        trange=(100000.0, 200000.0),
        fs=0.1,
        nperseg="full",
        window="boxcar",
        multiplier=1000.0,
        scale=1.0,
        unit="Century",
        xlim=(0.0, 1.5),
        ticks=np.arange(0.0, 1.51, 0.2),
        red_noise=False,
    ),
    "ALK": dict(
        files={"10": "alk_10var.txt"},
        col=1,
        trange=(1000000.0, 2000000.0),
        fs=0.1,
        nperseg="full",
        window="boxcar",
        multiplier=10000.0,
        scale=1.0,
        unit="Millennium",
        xlim=(0.0, 1.5),
        ticks=np.arange(0.0, 1.51, 0.2),
        red_noise=False,
    ),
}


def load_series(variable: str, model: str) -> np.ndarray:
    cfg = CONFIG[variable]
    path = BASE / f"run{model}" / cfg["files"][model]
    data = np.loadtxt(path, ndmin=2)
    mask = (data[:, 0] >= cfg["trange"][0]) & (data[:, 0] <= cfg["trange"][1])
    values = data[mask, cfg["col"]].astype(float)
    if values.size < 16 or not np.isfinite(values).all():
        raise ValueError(f"Invalid series for {variable}, model {model}: {path}")
    return values


def spectrum(variable: str, model: str):
    cfg = CONFIG[variable]
    y = load_series(variable, model)
    nperseg = len(y) if cfg["nperseg"] == "full" else min(int(cfg["nperseg"]), len(y))
    noverlap = 0 if cfg["window"] == "boxcar" else nperseg // 2
    f, power = signal.welch(
        y - y.mean(),
        fs=cfg["fs"],
        window=cfg["window"],
        nperseg=nperseg,
        noverlap=noverlap,
        detrend="constant",
        scaling="spectrum",
    )
    f_display = f * cfg["multiplier"]
    power_display = power * cfg["scale"]
    return y, f, f_display, power_display, nperseg, noverlap


def ar1_red_noise_95(y, f_native, observed_power, fs, nperseg, noverlap):
    """Conservative pointwise 95% AR(1) background in observed spectrum units."""
    centered = y - y.mean()
    rho = float(np.corrcoef(centered[:-1], centered[1:])[0, 1])
    rho = float(np.clip(rho, -0.99, 0.99))
    shape = (1.0 - rho**2) / (
        1.0 + rho**2 - 2.0 * rho * np.cos(2.0 * np.pi * f_native / fs)
    )
    valid = f_native > 0
    shape *= observed_power[valid].sum() / shape[valid].sum()
    step = max(1, nperseg - noverlap)
    segments = max(1, 1 + (len(y) - nperseg) // step)
    dof = max(2, 2 * segments)
    return shape * chi2.ppf(0.95, dof) / dof


spectra = {}
metadata = {"method": "original paper-style model spectra", "variables": {}}
for variable, cfg in CONFIG.items():
    spectra[variable] = {}
    metadata["variables"][variable] = {
        "window_TU": list(cfg["trange"]),
        "display_unit": cfg["unit"],
        "models": {},
    }
    for model in cfg["files"]:
        y, f_native, freq, power, nperseg, noverlap = spectrum(variable, model)
        spectra[variable][model] = (y, f_native, freq, power, nperseg, noverlap)
        view = (freq >= cfg["xlim"][0]) & (freq <= cfg["xlim"][1]) & (freq > 0)
        peak_index = np.flatnonzero(view)[np.argmax(power[view])]
        metadata["variables"][variable]["models"][model] = {
            "samples": int(len(y)),
            "nperseg": int(nperseg),
            "peak_frequency": float(freq[peak_index]),
            "peak_period": float(1.0 / freq[peak_index]),
            "peak_power": float(power[peak_index]),
        }


fig = plt.figure(figsize=(13.4, 9.2))
left = fig.add_gridspec(4, 1, left=0.075, right=0.485, top=0.88, bottom=0.08, hspace=0.62)
right = fig.add_gridspec(3, 1, left=0.59, right=0.985, top=0.88, bottom=0.08, hspace=0.52)
panels = [
    ("x2", "a", left[0]),
    ("w", "c", left[1]),
    ("eta", "e", left[2]),
    ("TL", "g", left[3]),
    ("Catm", "b", right[0]),
    ("Cocean", "d", right[1]),
    ("ALK", "f", right[2]),
]

for variable, letter, cell in panels:
    cfg = CONFIG[variable]
    ax = fig.add_subplot(cell)
    red_noise_curves = []
    for model, color, linestyle, label in (
        ("7", BLUE, "--", "Seven-variable"),
        ("10", RED, "-", "10VCC"),
    ):
        if model not in spectra[variable]:
            continue
        y, f_native, freq, power, nperseg, noverlap = spectra[variable][model]
        view = (freq >= cfg["xlim"][0]) & (freq <= cfg["xlim"][1])
        ax.plot(freq[view], power[view], color=color, linestyle=linestyle, linewidth=1.25, label=label)
        if cfg["red_noise"]:
            threshold = ar1_red_noise_95(
                y, f_native, power, cfg["fs"], nperseg, noverlap
            )
            red_noise_curves.append(threshold)

    if red_noise_curves:
        # A single conservative envelope keeps the comparison legible: a peak
        # above it exceeds the pointwise 95% AR(1) level for both model series.
        envelope = np.maximum.reduce(red_noise_curves)
        common_freq = next(iter(spectra[variable].values()))[2]
        ax.plot(common_freq, envelope, color=BLACK, linestyle=(0, (5, 4)), linewidth=1.0)

    if variable == "w":
        ax.axvline(1.0, color="#777777", linestyle=":", linewidth=0.9, zorder=0)
        ax.text(1.0, 0.97, "1 year", transform=ax.get_xaxis_transform(), ha="center", va="top", fontsize=8.5, color="#555555")

    ax.set_xlim(*cfg["xlim"])
    ax.set_xticks(cfg["ticks"])
    ax.set_ylim(bottom=0)
    ax.set_title(f"({letter}) {variable}", pad=5)
    ax.set_xlabel(f"Frequency ({cfg['unit']}$^{{-1}}$)")
    ax.set_ylabel("Power Spectrum")
    ax.ticklabel_format(axis="y", style="sci", scilimits=(-2, 2))
    ax.grid(True, color="#C8CDD2", alpha=0.42, linewidth=0.55)

fig.suptitle("Power spectra of the seven-variable and 10VCC models", fontsize=16, y=0.975)
fig.legend(
    handles=[
        Line2D([], [], color=BLUE, linestyle="--", linewidth=1.5, label="Seven-variable"),
        Line2D([], [], color=RED, linestyle="-", linewidth=1.5, label="10VCC"),
    ],
    loc="upper center",
    bbox_to_anchor=(0.5, 0.945),
    ncol=2,
    frameon=False,
    handlelength=3.0,
    columnspacing=1.8,
)

png = OUT / "model_power_spectra_original_method_c28_1.png"
fig.savefig(png, dpi=400, bbox_inches="tight", pad_inches=0.08, facecolor="white")
plt.close(fig)

(OUT / "model_power_spectra_original_method_c28_1.json").write_text(
    json.dumps(metadata, indent=2), encoding="utf-8"
)

print(png)
print(json.dumps(metadata["variables"]["w"], indent=2))

"""Read-only model/initial-parameter provenance checks; output scoped audit JSON."""
from pathlib import Path
import json,hashlib,re
B=Path(__file__).resolve().parent;R=B.parents[1]
roots=['sync_four_groups_20260913','three_channel_figures_psd150k_20260913','sensitivity_split_windows','saturation_remeasure_20260911','alk_top10_saturation_20260912','carbon_feedback_off_20260914','paper_revision_20260915']
out={'root':str(R),'sources':[],'initial_parameter_checks':[]}
for name in roots:
 d=R/name
 for p in sorted(d.glob('*.f90')):
  s=p.read_text(errors='replace');lines=[{'line':i,'text':x.strip()} for i,x in enumerate(s.splitlines(),1) if re.search(r'\bc28\s*=',x,re.I)]
  if lines:out['sources'].append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'assignments':lines})
 for p in sorted(d.glob('**/initial_parameters.txt')):
  rows=[x.split() for x in p.read_text().splitlines() if x.strip()]
  row=next((x for x in rows if x[0]=='15'),None)
  if row:
   truth=float(row[1].replace('D','E'));out['initial_parameter_checks'].append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'row15':row,'truth_is_1':abs(truth-1)<1e-12})
out['initial_count']=len(out['initial_parameter_checks'])
out['initial_truth_not1']=[r for r in out['initial_parameter_checks'] if not r['truth_is_1']]
(B/'remote_c28_audit.json').write_text(json.dumps(out,indent=2))
print('SOURCE_FILES',len(out['sources']),'INITIAL_RECORDS',out['initial_count'],'TRUTH_NOT_1',len(out['initial_truth_not1']))

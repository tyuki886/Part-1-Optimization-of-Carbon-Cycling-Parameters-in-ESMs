#!/bin/bash
#SBATCH --job-name=srdp_sync
#SBATCH --account=ab0246
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks=3
#SBATCH --time=04:00:00
#SBATCH --output=slurm_%j.out

srun --ntasks=1 --exclusive ./run_7 &
srun --ntasks=1 --exclusive ./run_9 &
srun --ntasks=1 --exclusive ./run_10 &
wait

echo "Simulation finished. Executing plot script..."
python3 plot_srdp.py

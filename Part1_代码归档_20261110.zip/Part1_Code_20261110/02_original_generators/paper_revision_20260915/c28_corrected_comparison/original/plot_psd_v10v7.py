# -*- coding: utf-8 -*-
"""功率谱对比图（新方案）：
图1 psd_phys4_compare.png：x2,w,eta,TL 四子图纵向，10-var 红(new model) vs 7-var 蓝(7-variable model)
图2 psd_carbon3_10var.png：Catm,Cocean,ALK 三子图纵向，仅 10-var 红(new model)
xlim 统一 0-1.5；nperseg 减小（不平滑）；无黑色虚线
打印：主峰周期（单位 + 换算年份），7-var 与 10-var 并列
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import signal

BD = '/work/ab0246/wuyuhang/SRDP/output/power/'
XLIM = [0.0, 1.5]
RED, BLUE = '#C44E52', '#4C72B0'
YR = {'Month': 1.0/12.0, 'Year': 1.0, 'Decade': 10.0, 'Millennium': 1000.0}

CFG = {
    'x2':   dict(f7='x2_7var.txt',       f10='x2_10var.txt',      col=1, trange=[2000, 4000],
                 fs=10.0, mult=10.0/12.0, unit='Month', nperseg=256, scale=0.0035,
                 xlab=r'Frequency (Month$^{-1}$)', ylim=None),
    'w':    dict(f7='wTL_7var.txt',      f10='wTL_10var.txt',     col=1, trange=[10000, 20000],
                 fs=1.0,  mult=10.0,      unit='Year', nperseg=512, scale=0.1,
                 xlab=r'Frequency (Model Year$^{-1}$)', ylim=None),
    'eta':  dict(f7='eta_7var.txt',      f10='etaCatm_10var.txt', col=1, trange=[10000, 20000],
                 fs=1.0,  mult=100.0,     unit='Decade', nperseg=1024, scale=1.0,
                 xlab=r'Frequency (Model Decade$^{-1}$)', ylim=None),
    'TL':   dict(f7='wTL_7var.txt',      f10='wTL_10var.txt',     col=2, trange=[10000, 20000],
                 fs=1.0,  mult=10.0,      unit='Year', nperseg=512, scale=0.1,
                 xlab=r'Frequency (Model Year$^{-1}$)', ylim=None),
    'Catm': dict(                          f10='etaCatm_10var.txt', col=2, trange=[100000, 200000],
                 fs=1.0,  mult=10.0,      unit='Year', nperseg=512, scale=1.0,
                 xlab=r'Frequency (Year$^{-1}$)', ylim=None),
    'Cocean': dict(                        f10='Cocean_10var.txt', col=1, trange=[1000000, 2000000],
                 fs=0.1,  mult=10000.0,   unit='Millennium', nperseg='full', scale=1.0,
                 xlab=r'Frequency (Millennium$^{-1}$)', ylim=None),
    'ALK':  dict(                          f10='alk_10var.txt',    col=1, trange=[1000000, 2000000],
                 fs=0.1,  mult=10000.0,   unit='Millennium', nperseg='full', scale=1.0,
                 xlab=r'Frequency (Millennium$^{-1}$)', ylim=None),
}
PHYS = ['x2', 'w', 'eta', 'TL']
CARB = ['Catm', 'Cocean', 'ALK']

def get_spec(cfg, fname, col):
    """返回 xlim 窗内 (f, p)"""
    d = np.loadtxt(BD + fname)
    m = (d[:, 0] >= cfg['trange'][0]) & (d[:, 0] <= cfg['trange'][1])
    t = d[m, col] - d[m, col].mean()
    if cfg['nperseg'] == 'full':
        nps, win = len(t), 'boxcar'
    else:
        nps, win = cfg['nperseg'], 'hann'
    f, p = signal.welch(t, fs=cfg['fs'], nperseg=nps, window=win, scaling='spectrum')
    fs_ = f * cfg['mult']
    vm = (fs_ >= XLIM[0]) & (fs_ <= XLIM[1])
    return fs_[vm], p[vm] * cfg['scale']

def draw_panel(ax, cfg, fv, pv, color, label):
    ax.plot(fv, pv, color=color, lw=1.4, label=label)
    ax.set_xlim(XLIM)
    if cfg['ylim'] is not None:
        ax.set_ylim(cfg['ylim'])
    ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0))
    ax.grid(True, alpha=0.3, linestyle=':')
    ax.set_xlabel(cfg['xlab'], fontsize=10)
    ax.set_ylabel('Power Spectrum', fontsize=10)
    ax.legend(loc='upper right', fontsize=9)

# 预加载全部谱
SPEC = {}
for v, cfg in CFG.items():
    SPEC[v] = {}
    if cfg.get('f7'):
        SPEC[v]['7'] = get_spec(cfg, cfg['f7'], cfg['col'])
    SPEC[v]['10'] = get_spec(cfg, cfg['f10'], cfg['col'])

# 打印主峰（xlim 窗内 argmax）→ 周期 + 换算年份
print('variable   mod7 period(unit)  mod7 yr    mod10 period(unit) mod10 yr')
for v, cfg in CFG.items():
    out = [f'{v:>7s}']
    for mod in ('7', '10'):
        if mod in SPEC[v]:
            fv, pv = SPEC[v][mod]
            fpk = fv[np.argmax(pv)]
            per = 1.0 / fpk
            out.append(f'{per:10.4f} {cfg["unit"]:>10s} {per*YR[cfg["unit"]]:9.4f}')
        else:
            out.append('        --        --')
    print('  '.join(out))

# ===== 图1：物理四变量 7 vs 10 =====
fig, axes = plt.subplots(4, 1, figsize=(9, 13))
for ax, v in zip(axes, PHYS):
    cfg = CFG[v]
    ax.set_title(v, fontsize=11, fontweight='bold')
    draw_panel(ax, cfg, *SPEC[v]['7'], BLUE, '7-variable model')
    draw_panel(ax, cfg, *SPEC[v]['10'], RED, 'new model')
plt.tight_layout()
fig.savefig(BD + 'psd_phys4_compare.png', dpi=300, bbox_inches='tight')
plt.close()
print('[OK] psd_phys4_compare.png')

# ===== 图2：碳三变量 仅 10-var =====
fig, axes = plt.subplots(3, 1, figsize=(9, 10))
for ax, v in zip(axes, CARB):
    cfg = CFG[v]
    ax.set_title(v, fontsize=11, fontweight='bold')
    draw_panel(ax, cfg, *SPEC[v]['10'], RED, 'new model')
plt.tight_layout()
fig.savefig(BD + 'psd_carbon3_10var.png', dpi=300, bbox_inches='tight')
plt.close()
print('[OK] psd_carbon3_10var.png')

# -*- coding: utf-8 -*-
"""准饱和时间测量 —— 指南法 v2（2026-08-07 按《准饱和时间指南法设计复查与修正建议》修订）。
v1 → v2 修改清单（对应复查文档问题编号）：
  P1  平滑尺度按变量类别自适应（快变量 S 0.4TU/g 0.8TU，慢变量 S 1.0TU/g 2.0TU），
      消除 2TU 平滑窗对 ~1TU 快变量主峰的边缘影响
  P2  取消"≥70% 全局最大峰"硬门槛：先按对称谷深分段，再在第一响应段内取主峰
      （仅当第一段主峰 <30% 全局峰 且 存在第二段时视为噪声前奏，跳至第二段）
  P3  搜索窗口自适应扩窗（×2 倍增，上限 20000 TU），直到主峰不靠末端 且 完成
      "上升→主峰→回落 <50% 主峰"完整过程
  P4  极大值检查严格化：a<0 且 g(t_fit)>0 且 g'(τ⁻)>0 且 g'(τ⁺)<0
  P5  取消固定 ±1TU 确认：改"同峰瓣判定"（g≥0.9×g_peak 的连续区间 [tL,tR] 含 τ_fit），
      兜底尺度自适应阈值 Δ≤max(1, 0.1×τ_num) 且 g(τ_fit)≥0.9×g_peak
  P7  弱敏感性前置门槛：S*(t)=S(t)/σ_clim（σ_clim=尾段>3000TU 中位数），
      max(S*)<0.02 → status=weak，τ=NA（不强行赋周期）
  P8  谷深判段对称化：valley_ratio = g_valley / min(g1,g2) ≥ 0.9 → 同段
  P9  拟合质量硬门槛：R²≥0.90 且 NRMSE≤0.10 且残差无强单边趋势（|r|<0.5）
  P6  四状态裁决：cubic_confirmed / numerical_fallback / conflict / weak
输出字段（文档第 14 节）：param,var,t_num,peak_left,peak_right,fit_start,fit_end,
  t_fit,fit_R2,fit_NRMSE,sensitivity_strength,status,t_final,cycle_tau,audit_reason
"""
import numpy as np
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VARS = ['x1', 'x2', 'x3', 'w', 'TL', 'Catm', 'Cocean', 'ALK']
WATER10 = ['kappa', 'c1', 'b', 'sigma', 'c13', 'c2', 'c15', 'lambda', 'c4', 'c12']  # 2026-08-26 新重测
CARB10 = ['c16', 'c20', 'c29', 'c30', 'c22', 'c17', 'c24', 'c19', 'c18', 'c21']  # 2026-08-26 新重测

# ---- P1: 按变量类别的平滑尺度（TU）----
SMOOTH = {'x1': (0.4, 0.8), 'x2': (0.4, 0.8), 'x3': (0.4, 0.8),
          'w': (0.6, 1.2), 'TL': (0.6, 1.2),
          'Catm': (0.8, 1.6), 'Cocean': (1.0, 2.0), 'ALK': (1.0, 2.0)}
WIN0 = {'x1': 40.0, 'x2': 40.0, 'x3': 40.0, 'w': 40.0, 'TL': 40.0,
        'Catm': 60.0, 'Cocean': 100.0, 'ALK': 250.0}
VALLEY = 0.90     # P8 对称谷深同段判据
WEAK_FRAC = 0.02  # P7 弱敏感门槛：max(S*) < 2%
NOISE_FRAC = 0.30  # P2 噪声前奏跳段阈值（段主峰 <30% 全局峰 → 噪声前奏）
PLATEAU_RATIO = 1.5  # P2" 平台判据：所选段内峰高变幅 ≤1.5×（增长率长时间不增不减，
                     # 如 ALK 40-100TU 宽平台）→ τ 取平台起点（首次 ≥90% 段峰），
                     # 而非平台内噪声决定的最高点；落实"增长率不再继续增加"
REBOUND_FRAC = 2.0  # P2' 再生长判据：后续段存在 ≥2× 本段主峰的生长峰 → 本段为
                    # 早期爆发前奏（c20 Catm 1.1 峰后有 12.0 峰），跳到下一段；
                    # 无 ≥2× 后续峰（b x1 2.3 峰后最大仅 12%）→ 本段即"第一次主要建立"
HALF_DROP = 0.50  # 回落截断：g 首次回落到 <50% 主峰
WMAX_FACTOR = 2.5
WMIN_FACTOR = 1.6
FLANK_FRAC = 0.90  # P5 峰瓣定义：g ≥ 0.9×g_peak 的连续区间
FLANK_TOL = 0.5    # P5 峰瓣边界容差（TU，工程 QC 规则）：拟合为近似，τ_fit 距瓣边
                   # ≤0.5 TU 视为同瓣（消除浮点/采样边缘误报，如 lambda TL Δ=0.3 差 0.1 落瓣外）
DT_MAX = 1.0       # P5 兜底阈值基数（TU）
DT_FRAC = 0.10     # P5 兜底：0.1×τ_num
R2_MIN = 0.85      # P9 拟合质量门槛（局部窗下慢变量 0.98+，快变量形状性偏低→fallback）
NRMSE_MAX = 0.10   # P9 记入审计，不一票否决
RESID_R_MAX = 0.50  # P9 记入审计，不一票否决


def smooth_edge(y, win_tu, dt):
    k = max(3, int(round(win_tu / dt)))
    k += (k % 2 == 0)
    yp = np.pad(y, k // 2, mode='edge')
    return np.convolve(yp, np.ones(k) / k, mode='valid')


def load_curve(nm, var):
    d = np.loadtxt(ROOT / f'saturation_std_long33_{nm}.txt', comments='#')
    t = d[:, 0]
    y = d[:, VARS.index(var) + 1]
    return t, y


def g_series(t, y, sm_s, sm_g):
    dt = t[1] - t[0]
    ys = smooth_edge(y, sm_s, dt)
    g = np.gradient(ys, dt)
    return t, smooth_edge(g, sm_g, dt)


def numeric_peak(t, y, window, sm_s, sm_g):
    """P2 分段优先的数值主峰：raw 局部极大 → 对称谷深分段 → 第一响应段内主峰。
    返回 (tau_num, g_peak, gmax, t_break, tc, g) —— tc/g 均为窗口内序列。"""
    tg, gfull = g_series(t, y, sm_s, sm_g)
    m = t <= window
    tc, g = tg[m], gfull[m]
    gmax = g.max()
    i0 = int(np.searchsorted(tc, 0.5))
    peaks = []
    for i in range(max(1, i0), len(g) - 1):
        if g[i] >= g[i - 1] and g[i] > g[i + 1] and g[i] > 0.0:
            peaks.append((float(tc[i]), float(g[i])))
    if not peaks:
        j = max(1, i0) + int(np.argmax(g[max(1, i0):]))
        return float(tc[j]), float(g[j]), gmax, None, tc, g
    # 对称谷深分段（P8）：valley/min(g1,g2) ≥ 0.9 → 同段（g 回落到 0 以下 → 必然新段）
    segs = [[peaks[0]]]
    for k in range(1, len(peaks)):
        t2, g2 = peaks[k]
        i1 = int(np.searchsorted(tc, segs[-1][-1][0]))
        i2 = int(np.searchsorted(tc, t2))
        valley = g[i1:i2 + 1].min()
        if valley >= VALLEY * min(segs[-1][-1][1], g2):
            segs[-1].append((t2, g2))
        else:
            segs.append([(t2, g2)])
    # 第一响应段内主峰（P2：不用全局 70% 硬门槛）。跳段判据（P2 噪声前奏 + P2' 再生长）：
    #   a) 段主峰 <30% 全局峰（数值噪声前奏，如 c18 x1 的 0.02% 假峰）
    #   b) 后续存在 ≥2× 本段主峰的再生长峰（早期爆发后回落再重建，如 c20 Catm 1.1→12.0）
    # 后缀最大段峰表（O(n) 预计算，避免 O(n²)）
    seg_peak = [max(s, key=lambda x: x[1])[1] for s in segs]
    suf = [0.0] * (len(segs) + 1)
    for i in range(len(segs) - 1, -1, -1):
        suf[i] = max(seg_peak[i], suf[i + 1])
    si = 0
    while si < len(segs) - 1:
        gp = seg_peak[si]
        if gp >= NOISE_FRAC * gmax and suf[si + 1] < REBOUND_FRAC * gp:
            break
        si += 1
    tau_num, g_peak = max(segs[si], key=lambda x: x[1])
    # 平台起算（P2"）：所选段内峰高变幅 ≤1.5× → 增长率持续不增不减，
    # τ 取"增长率停止增加"时刻 = 平台起点（首次 ≥90% 段峰），而非噪声决定的最高点
    seg = segs[si]
    smax = max(x[1] for x in seg)
    smin = min(x[1] for x in seg)
    if len(seg) > 1 and smin > 0 and smax / smin <= PLATEAU_RATIO:
        for tt, gg in seg:
            if gg >= 0.9 * smax:
                tau_num = tt
                break
    t_break = segs[si + 1][0][0] if si + 1 < len(segs) else None
    return tau_num, g_peak, gmax, t_break, tc, g


def peak_flank(tc, g, tau_num, g_peak):
    """P5 主峰峰瓣：[tL,tR] = 连续满足 g ≥ 0.9×g_peak 的最大区间（含 τ_num）。"""
    i = int(np.searchsorted(tc, tau_num))
    lo = hi = i
    while lo > 0 and g[lo - 1] >= FLANK_FRAC * g_peak:
        lo -= 1
    while hi < len(g) - 1 and g[hi + 1] >= FLANK_FRAC * g_peak:
        hi += 1
    return float(tc[lo]), float(tc[hi])


def adaptive_window(t, y, var):
    """P3 自适应扩窗：从 WIN0 起 ×2 倍增，直到主峰不靠末端(<0.8×w) 且
    g 在 [τ_num, w] 内完成回落到 <50% 主峰（或存在第二段）。上限 20000 TU。"""
    sm_s, sm_g = SMOOTH[var]
    w = WIN0[var]
    while w <= 20000.0:
        tau, gpk, gmax, t_break, tc, g = numeric_peak(t, y, w, sm_s, sm_g)
        near_end = tau > 0.8 * w
        m = (tc >= tau) & (tc <= w)
        has_decay = bool(((g[m] < HALF_DROP * gpk) & (tc[m] > tau)).any())
        if (not near_end) and (has_decay or t_break is not None):
            break
        if w >= 20000.0:  # 已达上限仍未满足 → 取当前结果（防死循环）
            break
        w = min(w * 2.0, 20000.0)
    return tau, gpk, gmax, t_break, tc, g, w


def fit_window_end(tg, g, w, tau, gpk):
    """拟合窗 = 峰邻域局部阶段 [0.5τ, 1.5τ]（文档第17节：在该局部阶段对 S 做三次拟合）。
    全窗信息（w_end 等）仅用于审计，不参与拟合。"""
    w_end = min(WMAX_FACTOR * tau, w)
    m = (tg >= tau) & (tg <= w_end)
    below = tg[m][g[m] < HALF_DROP * gpk]
    if len(below) > 0:
        w_end = min(w_end, float(below[0]))
    w_end = max(w_end, WMIN_FACTOR * tau)
    return min(w_end, w)


def cubic_fit(t, y, tau):
    """P9 三次拟合 + 质量门槛（在峰邻域 [0.5τ, 1.5τ] 上进行）。
    返回 (a,b,c,d,tau_fit,R2,NRMSE,resid_r,ok,why)。QC：R2≥0.85 硬门槛，
    NRMSE/残差单边趋势记入审计但不一票否决（文档问题9：至少一个质量指标）。"""
    lo, hi = 0.5 * tau, 1.5 * tau
    m = (t >= lo) & (t <= hi)
    tc, yc = t[m], y[m]
    if len(tc) < 8:
        return None, None, None, None, None, None, None, None, False, f'局部窗点数不足({len(tc)})'
    A = np.vstack([tc ** 3, tc ** 2, tc, np.ones_like(tc)]).T
    coef, *_ = np.linalg.lstsq(A, yc, rcond=None)
    a, b, c, d = coef
    fit = A @ coef
    res = yc - fit
    ss_res = float(np.sum(res ** 2))
    ss_tot = float(np.sum((yc - yc.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else np.nan
    span = np.ptp(yc)
    nrmse = float(np.sqrt(np.mean(res ** 2)) / span) if span > 0 else np.nan
    resid_r = float(np.corrcoef(tc, res)[0, 1]) if len(tc) > 2 else 0.0
    if abs(a) < 1e-14:
        return a, b, c, d, None, r2, nrmse, resid_r, False, 'a≈0(无曲率)'
    if r2 < R2_MIN:
        return a, b, c, d, None, r2, nrmse, resid_r, False, f'R2={r2:.3f}<{R2_MIN}'
    tau_fit = -b / (3.0 * a)
    return a, b, c, d, tau_fit, r2, nrmse, resid_r, True, ''


def validate(t, g, w_end, tau_fit, a, b, c):
    """P4 严格检查：①窗口内 ②a<0 且 g(t_fit)>0 且 g' 变号 ③峰瓣贴附。"""
    if not (0.0 < tau_fit < w_end):
        return False, f'τ_fit={tau_fit:.1f} 不在窗口(0,{w_end:.1f})'
    if a >= 0:
        return False, f'a={a:.2e}≥0(开口向上=无峰)'
    g_fit = 3 * a * tau_fit ** 2 + 2 * b * tau_fit + c
    if g_fit <= 0:
        return False, f'g(τ_fit)={g_fit:.2e}≤0(敏感度已不增长)'
    gp_before = 6 * a * (tau_fit - 0.3 * tau_fit) + 2 * b
    gp_after = 6 * a * (tau_fit + 0.3 * tau_fit) + 2 * b
    if not (gp_before > 0 and gp_after < 0):
        return False, f"g'符号不符({gp_before:.2e},{gp_after:.2e})"
    # 峰瓣贴附：τ_fit 处 g ≥ 0.9×邻域极大
    i = int(np.searchsorted(t, tau_fit))
    lo, hi = max(1, i - 10), min(len(g) - 1, i + 10)
    gmax_nb = g[lo:hi + 1].max()
    if g[i] < 0.90 * gmax_nb:
        return False, f'τ_fit处g={g[i]:.2f}为邻域极大{gmax_nb:.2f}的{g[i]/gmax_nb:.0%}(谷中)'
    return True, ''


def run_one(nm, var):
    t, y = load_curve(nm, var)
    # P7 弱敏感门槛
    m_clim = t > 3000.0
    clim = float(np.median(y[m_clim])) if m_clim.sum() > 0 else 1.0
    tau_num, gpk, gmax, t_break, tg, g, window = adaptive_window(t, y, var)
    w_end = fit_window_end(tg, g, window, tau_num, gpk)  # 仅审计用
    tL, tR = peak_flank(tg, g, tau_num, gpk)
    sens_strength = float(np.max(y[:int(np.searchsorted(t, window)) + 1]) / clim) if clim > 0 else np.nan
    fit_start, fit_end = 0.5 * tau_num, 1.5 * tau_num  # 峰邻域局部拟合窗（文档17节）
    a, b, c, d, tau_fit, r2, nrmse, resid_r, ok_fit, why = cubic_fit(t, y, tau_num)
    # ---- 四状态裁决（P6）----
    if sens_strength < WEAK_FRAC:
        return dict(param=nm, var=var, t_num=tau_num, peak_left=tL, peak_right=tR,
                    fit_start=fit_start, fit_end=fit_end, t_fit=None, fit_R2=None, fit_NRMSE=None,
                    sensitivity_strength=sens_strength, status='weak', t_final=None,
                    cycle_tau=None, audit_reason=f'弱响应 max(S*)={sens_strength:.3f}<{WEAK_FRAC}')
    if not ok_fit:
        return dict(param=nm, var=var, t_num=tau_num, peak_left=tL, peak_right=tR,
                    fit_start=fit_start, fit_end=fit_end, t_fit=None, fit_R2=r2, fit_NRMSE=nrmse,
                    sensitivity_strength=sens_strength, status='numerical_fallback', t_final=tau_num,
                    cycle_tau=int(np.ceil(tau_num)),
                    audit_reason=f'拟合失败: {why}')
    ok_val, why_v = validate(tg, g, w_end, tau_fit, a, b, c)
    if not ok_val:
        return dict(param=nm, var=var, t_num=tau_num, peak_left=tL, peak_right=tR,
                    fit_start=fit_start, fit_end=fit_end, t_fit=float(tau_fit), fit_R2=r2, fit_NRMSE=nrmse,
                    sensitivity_strength=sens_strength, status='numerical_fallback', t_final=tau_num,
                    cycle_tau=int(np.ceil(tau_num)),
                    audit_reason=f'检查未过: {why_v}')
    # P5 同峰瓣确认（唯一物理一致性判据，含 ±0.5TU 边界容差）+ 尺度自适应兜底；t_break 仅审计
    same_flank = ((tL - FLANK_TOL) <= tau_fit <= (tR + FLANK_TOL))
    dtau = abs(tau_fit - tau_num)
    dtau_max = max(DT_MAX, DT_FRAC * tau_num)
    in_seg1 = (t_break is None) or (tau_fit <= t_break)
    ratio = float(np.interp(tau_fit, tg, g) / gpk) if gpk > 0 else 0.0
    fallback_th = (dtau <= dtau_max and ratio >= FLANK_FRAC)
    qc_note = f' R2={r2:.2f}/NRMSE={nrmse:.2f}/残差r={resid_r:.2f}' if (nrmse > NRMSE_MAX or abs(resid_r) > RESID_R_MAX) else ''
    if same_flank:
        return dict(param=nm, var=var, t_num=tau_num, peak_left=tL, peak_right=tR,
                    fit_start=fit_start, fit_end=fit_end, t_fit=float(tau_fit), fit_R2=r2, fit_NRMSE=nrmse,
                    sensitivity_strength=sens_strength, status='cubic_confirmed', t_final=float(tau_fit),
                    cycle_tau=int(np.ceil(tau_fit)),
                    audit_reason=f'同峰瓣[{tL:.1f},{tR:.1f}] Δ={dtau:.2f} seg1={in_seg1}' + qc_note)
    if fallback_th:
        return dict(param=nm, var=var, t_num=tau_num, peak_left=tL, peak_right=tR,
                    fit_start=fit_start, fit_end=fit_end, t_fit=float(tau_fit), fit_R2=r2, fit_NRMSE=nrmse,
                    sensitivity_strength=sens_strength, status='cubic_confirmed', t_final=float(tau_fit),
                    cycle_tau=int(np.ceil(tau_fit)),
                    audit_reason=f'Δ={dtau:.2f}≤max(1,0.1τ)且贴顶(ratio={ratio:.2f}) seg1={in_seg1}' + qc_note)
    return dict(param=nm, var=var, t_num=tau_num, peak_left=tL, peak_right=tR,
                fit_start=fit_start, fit_end=fit_end, t_fit=float(tau_fit), fit_R2=r2, fit_NRMSE=nrmse,
                sensitivity_strength=sens_strength, status='conflict', t_final=tau_num,
                cycle_tau=int(np.ceil(tau_num)),
                audit_reason=f'冲突: 拟合合理但 Δ={dtau:.1f}TU 不在峰瓣[{tL:.1f},{tR:.1f}] seg1={in_seg1}' + qc_note)


def main():
    rows = [run_one(nm, var) for nm in WATER10 + CARB10 for var in VARS]
    print('===== 指南法 v2：四状态裁决 =====')
    print(f"{'参数':6s} {'变量':7s} {'t_num':>6s} {'t_fit':>6s} {'最终τ':>6s} {'窗右':>6s} {'峰瓣':>10s} {'S*':>6s} {'R2':>5s}  状态/原因")
    for r in rows:
        tf = r['t_fit']
        st = r['status']
        if st == 'weak':
            print(f"{r['param']:6s} {r['var']:7s} {r['t_num']:6.1f}     -     -     -       - {r['sensitivity_strength']:5.3f}    -  weak <<< {r['audit_reason']}")
        elif tf is None:
            print(f"{r['param']:6s} {r['var']:7s} {r['t_num']:6.1f}     - {r['t_final']:6.1f} {r['fit_end']:6.1f} {r['peak_left']:4.1f}-{r['peak_right']:<4.1f} {r['sensitivity_strength']:5.3f}   -  {st} <<< {r['audit_reason']}")
        else:
            print(f"{r['param']:6s} {r['var']:7s} {r['t_num']:6.1f} {tf:6.1f} {r['t_final']:6.1f} {r['fit_end']:6.1f} {r['peak_left']:4.1f}-{r['peak_right']:<4.1f} {r['sensitivity_strength']:5.3f} {r['fit_R2']:5.2f}  {st}" + (f" <<< {r['audit_reason']}" if st != 'cubic_confirmed' else ''))
    from collections import Counter
    cnt = Counter(r['status'] for r in rows)
    print(f'\n状态统计: {dict(cnt)}')
    n_weak = sum(1 for r in rows if r['status'] == 'weak')
    print(f'weak(τ=NA) {n_weak} 个（不再强行赋周期）')
    with open('tau_guide_v2_top20_20260826.json', 'w', encoding='utf-8') as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)
    print('saved tau_guide_v2_top20_20260826.json')


if __name__ == '__main__':
    main()

"""同步18面板绘图脚本，在新超算重绘并取回；不重复运行饱和时间计算。"""
from pathlib import Path
import getpass
import paramiko
BASE=Path(__file__).resolve().parent
REMOTE='/public/home/hou/wyh/MCPE26.0/saturation_c80_18panels'
client=paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
client.connect('222.195.137.80',username='hou',password=getpass.getpass('New HPC password: '),timeout=30,look_for_keys=False,allow_agent=False)
try:
    with client.open_sftp() as sftp:
        sftp.put(str(BASE/'plot_saturation_c80_18panels.py'),REMOTE+'/plot_saturation_c80_18panels.py')
    _,out,err=client.exec_command('/public/home/hou/miniconda3/envs/yuki/bin/python '+REMOTE+'/plot_saturation_c80_18panels.py',timeout=120)
    print(out.read().decode(),flush=True)
    error=err.read().decode()
    if out.channel.recv_exit_status()!=0: raise RuntimeError(error)
    if error: print(error,flush=True)
    with client.open_sftp() as sftp:
        for ext in ('png','pdf'):
            name='saturation_C80_18panels_334334.'+ext
            sftp.get(REMOTE+'/'+name,str(BASE/name))
            print('Downloaded:',name,flush=True)
finally:
    client.close()

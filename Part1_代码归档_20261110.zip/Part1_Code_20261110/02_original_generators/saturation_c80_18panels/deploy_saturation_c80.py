"""AWI原曲线派生导出、新超算独立18面板出图及取回。"""
from pathlib import Path
import sys
import getpass
import hashlib
import paramiko
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parents[1]))
import hpc
AWI='/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/sat33'
EXPORT='/home/b/b382207/srdp_exports/c80_18panels_20260905'
REMOTE='/public/home/hou/wyh/MCPE26.0/saturation_c80_18panels'
PY='/public/home/hou/miniconda3/envs/yuki/bin/python'
def run(client,command,source=None):
    stdin,out,err=client.exec_command(command,timeout=240)
    if source:
        stdin.write(source); stdin.flush(); stdin.channel.shutdown_write()
    for line in out:
        print(line.rstrip(),flush=True)
    error=err.read().decode('utf-8','replace')
    if out.channel.recv_exit_status()!=0:
        raise RuntimeError(error)
    if error: print(error,flush=True)
new=paramiko.SSHClient()
new.load_system_host_keys()
new.set_missing_host_key_policy(paramiko.AutoAddPolicy())
new.connect('222.195.137.80',username='hou',password=getpass.getpass('New HPC password: '),timeout=30,look_for_keys=False,allow_agent=False)
try:
    awi=hpc.connect()
    try:
        run(awi,'/home/b/b382207/conda/envs/yuki/bin/python -u -',(BASE/'export_awi_saturation.py').read_text(encoding='utf-8'))
        with awi.open_sftp() as src:
            for name in ('curves_c80_18panels.npz','tau_c80_18panels.json'):
                src.get(EXPORT+'/'+name,str(BASE/name))
            src.get(AWI+'/analyze_sat_guide_v2_33.py',str(BASE/'analyze_sat_guide_v2_33_original.py'))
    finally:
        awi.close()
    with new.open_sftp() as dst:
        try: dst.stat(REMOTE)
        except FileNotFoundError: dst.mkdir(REMOTE)
        for name in ('curves_c80_18panels.npz','tau_c80_18panels.json','plot_saturation_c80_18panels.py','analyze_sat_guide_v2_33_original.py','export_awi_saturation.py'):
            dst.put(str(BASE/name),REMOTE+'/'+name)
            with dst.open(REMOTE+'/'+name,'rb') as stream:
                stream.prefetch(dst.stat(REMOTE+'/'+name).st_size)
                assert hashlib.sha256(stream.read()).hexdigest()==hashlib.sha256((BASE/name).read_bytes()).hexdigest()
        dst.put('C:/Windows/Fonts/times.ttf',REMOTE+'/times.ttf')
    print('NEW_HPC_TRANSFER_VERIFIED',flush=True)
    run(new,PY+' '+REMOTE+'/plot_saturation_c80_18panels.py')
    with new.open_sftp() as dst:
        for name in ('saturation_C80_18panels_334334.png','saturation_C80_18panels_334334.pdf','panel_layout.json'):
            dst.get(REMOTE+'/'+name,str(BASE/name))
            print('Downloaded:',name,flush=True)
finally:
    new.close()

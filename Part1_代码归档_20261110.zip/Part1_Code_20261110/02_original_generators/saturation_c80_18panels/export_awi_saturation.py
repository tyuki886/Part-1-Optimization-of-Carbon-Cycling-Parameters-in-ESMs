"""在 AWI 上读取原始长序列，以原指南法 v2 计算当前 C80 的60个同循环响应。"""
from pathlib import Path
import importlib.util
import json
import hashlib
from collections import Counter
import numpy as np

SOURCE = Path('/work/ab0246/wuyuhang/SRDP/output/MCPE21.0/sat33')
OUT = Path('/home/b/b382207/srdp_exports/c80_18panels_20260905')
OUT.mkdir(parents=True, exist_ok=True)
WATER = ['kappa','c1','b','sigma','c13','c2','c15','lambda','c4','c12']
CARBON = ['c20','c16','c30','c19','c28','c17','c23','c26','c21','c29']
spec = importlib.util.spec_from_file_location('guide', SOURCE / 'analyze_sat_guide_v2_33.py')
guide = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guide)
old = {(r['param'], r['var']): r for r in json.loads((SOURCE / 'tau_guide_v2_top20_20260826.json').read_text())}
rows, arrays, compared, differences = [], {}, 0, []
sources = {}
for params, variables, limit in [(WATER, ['x2','w','TL'], 50), (CARBON, ['Catm','Cocean','ALK'], 2000)]:
    for param in params:
        path = SOURCE / ('saturation_std_long33_' + param + '.txt')
        data = np.loadtxt(path, comments='#')
        if data.shape != (200000, 9) or not np.isfinite(data).all():
            raise ValueError('Invalid source: ' + param)
        if not np.allclose(np.diff(data[:,0]), 0.1, atol=1e-8):
            raise ValueError('Unexpected sampling: ' + param)
        # 只缓存当前参数的数据，避免 run_one 对每个变量重复读取长文件。
        def load_curve(name, var):
            assert name == param
            return data[:,0], data[:,guide.VARS.index(var)+1]
        guide.load_curve = load_curve
        results = [guide.run_one(param, var) for var in variables]
        for result in results:
            previous = old.get((param, result['var']))
            if previous is not None:
                compared += 1
                a, b = previous['t_final'], result['t_final']
                if (a is None) != (b is None) or (a is not None and not np.isclose(a,b,rtol=1e-6,atol=1e-6)):
                    differences.append({'param':param,'var':result['var'],'old':a,'new':b})
        rows.extend(results)
        # 保留绘图窗口全部0.1TU样点；若标注超出旧窗口则额外保留至标注之后。
        bound = max([limit] + [1.15*r['t_final'] for r in results if r['t_final'] is not None])
        columns = [0] + [guide.VARS.index(var)+1 for var in variables]
        arrays[param] = data[data[:,0] <= bound][:,columns]
        sources[param] = {'path':str(path),'rows':len(data),'sample_interval_TU':0.1,
                          'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        print('Calculated:', param, flush=True)
np.savez_compressed(OUT / 'curves_c80_18panels.npz', **arrays)
report = {'water':WATER,'carbon':CARBON,'results':rows,'sources':sources,
          'existing_results_compared':compared,'differences':differences,
          'status_counts':dict(Counter(r['status'] for r in rows)),
          'method_source':str(SOURCE / 'analyze_sat_guide_v2_33.py')}
(OUT / 'tau_c80_18panels.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
if differences:
    raise ValueError('Existing tau values changed: ' + str(differences))
print(json.dumps({'output':str(OUT),'compared':compared,'status_counts':report['status_counts']}), flush=True)

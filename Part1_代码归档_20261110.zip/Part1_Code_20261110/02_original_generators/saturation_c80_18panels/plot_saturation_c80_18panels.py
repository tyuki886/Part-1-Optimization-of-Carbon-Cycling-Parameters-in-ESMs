"""当前C80饱和时间图：3行6列，左水循环、右碳循环，参数均按3/3/4分组。

曲线是0.1TU原始集合标准差，无平滑；图例与曲线末端标注指南法v2的t_final。
六列x2/w/TL/Catm/Cocean/ALK，三行分别3/3/4个参数；子图横轴为时间TU，纵轴为标准差。
继承原图窗口20/50/50及100/100/2000TU、默认蓝橙绿红配色、实线与整数TU标注。
"""
from pathlib import Path
import sys
import json
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parent / 'twin_work_3x3' / 'python_deps'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import MaxNLocator

report = json.loads((BASE/'tau_c80_18panels.json').read_text(encoding='utf-8'))
curves = np.load(BASE/'curves_c80_18panels.npz')
WATER = ['kappa','c1','b','sigma','c13','c2','c15','lambda','c4','c12']
CARBON = ['c20','c16','c30','c19','c28','c17','c23','c26','c21','c29']
assert report['water'] == WATER and report['carbon'] == CARBON
assert len(report['results']) == 60 and not report['differences']
lookup = {(r['param'],r['var']):r for r in report['results']}
font_manager.fontManager.addfont(str(BASE/'times.ttf'))
plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.labelsize':13,'axes.titlesize':14,
                     'xtick.labelsize':11,'ytick.labelsize':11,
                     'pdf.fonttype':42,'ps.fonttype':42,'mathtext.fontset':'stix'})
groups = [WATER[:3],WATER[3:6],WATER[6:],CARBON[:3],CARBON[3:6],CARBON[6:]]
colors = ['#1f77b4','#ff7f0e','#2ca02c','#d62728']
fig, axes = plt.subplots(3,6,figsize=(25,12),layout='constrained')
panel_audit = []
for group_index, params in enumerate(groups):
    variables = ['x2','w','TL'] if group_index < 3 else ['Catm','Cocean','ALK']
    limits = [20,50,50] if group_index < 3 else [100,100,2000]
    for variable_index, var in enumerate(variables):
        row = group_index % 3
        col = 3 * (group_index // 3) + variable_index
        ax = axes[row,col]
        xmax = limits[variable_index]
        for k,param in enumerate(params):
            d = curves[param]
            t, y = d[:,0], d[:,variable_index+1]
            mask = t <= xmax
            t = np.r_[0., t[mask]]
            y = np.r_[0., y[mask]]
            tau = lookup[(param,var)]['t_final']
            label = param + (f' ({tau:.0f}TU)' if tau is not None else ' (NA)')
            ax.plot(t,y,color=colors[k],ls='-',lw=1.5,label=label)
            if tau is not None:
                ax.text(t[-1]*1.02,y[-1],f'{tau:.0f}',fontsize=7,va='center')
        ax.set_xlim(0,xmax)
        ax.set_xlabel('Time (TU)')
        ax.set_ylabel(var + ' standard deviation')
        ax.grid(alpha=0.5,ls='--')
        ax.legend(loc='upper left',fontsize=9,framealpha=0.85,handlelength=2.2)
        ax.set_title(var,pad=9)
        panel_audit.append({'row':row,'column':col,'variable':var,'parameters':params,'xmax':xmax})
for row in range(3):
    assert [ax.get_title() for ax in axes[row]] == ['x2','w','TL','Catm','Cocean','ALK']
    assert all(len(ax.lines) == [3,3,4][row] for ax in axes[row])
for extension in ('png','pdf'):
    fig.savefig(BASE/('saturation_C80_18panels_334334.'+extension),dpi=300,bbox_inches='tight',facecolor='white')
assert len(fig.axes)==18
plt.close(fig)
(BASE/'panel_layout.json').write_text(json.dumps(panel_audit,indent=2),encoding='utf-8')
print('PLOT_DONE: 18 panels; current C80 10 water + 10 carbon; 60 curves',flush=True)

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
cd build
gfortran -O3 -ffree-line-length-none ../01_current_model/RKmethod_reference.f90 ../01_current_model/RK4main7.f90 -o model7
gfortran -O3 -ffree-line-length-none ../01_current_model/RKmethod_reference.f90 ../01_current_model/RK4main10.f90 -o model10
echo "Built model7 and model10. No model integration has been started."

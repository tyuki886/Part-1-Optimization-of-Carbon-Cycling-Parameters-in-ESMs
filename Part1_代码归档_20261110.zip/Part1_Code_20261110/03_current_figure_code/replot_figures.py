from pathlib import Path
import json,hashlib,runpy,shutil,re,io
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager,mathtext
from matplotlib.figure import Figure
from matplotlib.text import Text
from matplotlib.text import Annotation
from matplotlib.patches import Patch
from PIL import Image,ImageDraw
from parameter_map import rename_display
B=Path(__file__).resolve().parent;G=B/'graph_inputs';O=B/'renamed_figures';O.mkdir(exist_ok=True)
inputs=json.loads((G/'manifest.json').read_text())
for z in inputs:assert hashlib.sha256((G/z['file']).read_bytes()).hexdigest()==z['sha256']
font_manager.fontManager.addfont(str(G/'times.ttf'))
original_save=Figure.savefig
records=[]
aliases={'Fig2_22parameters_font_unified.png':'Response_portrait.png',
    'Fig3_MCPE_timeline_font_unified.png':'Timeline.png',
    'parameter_mean_spread_MCPE30_8obs.png':'Ensemble.png',
    'ALK_Bcal_nonlinear_bracket_vertical_compact.png':'ALK_threshold.png',
    'sensitivity.png':'Sensitivity.png','response_landscape.png':'Response_landscape.png'}
def data_digest(fig):
    h=hashlib.sha256()
    for ax in fig.axes:
        for line in ax.lines:
            for v in [line.get_xdata(),line.get_ydata()]:h.update(np.ascontiguousarray(v).tobytes())
        for patch in ax.patches:
            h.update(np.ascontiguousarray(patch.get_path().vertices).tobytes())
            if hasattr(patch,'get_bbox'):h.update(str(patch.get_bbox().bounds).encode())
    return h.hexdigest()
def save_hook(fig,path,*args,**kw):
    if hasattr(path,'write'):
        return original_save(fig,path,*args,**kw)
    if str(path).lower().endswith('.pdf'):return
    before=data_digest(fig);changes=[]
    if 'timeline' in str(path).lower() and len(fig.axes)>1:
        for item in fig.axes[-1].texts:
            if not isinstance(item,Annotation):item.set_visible(False)
    if not getattr(fig,'_names_updated',False):
        seen=set()
        for item in fig.findobj(Text):
            if id(item) in seen:continue
            seen.add(id(item));old=item.get_text();new=rename_display(old).replace('Cocean','Cocn')
            # Ensure the special new symbol has a true plotted subscript.
            if '$' not in new:
                new=re.sub(r'\bA([01])\b',lambda m:'$A_{'+m[1]+'}$',new)
            if old!=new:item.set_text(new);changes.append([old,new])
        fig._names_updated=True
    assert data_digest(fig)==before
    kw['dpi']=600
    original_save(fig,path,*args,**kw)
    name=aliases.get(Path(path).name,Path(path).name)
    dest=O/name
    if Path(path)!=dest:shutil.copy2(path,dest)
    records.append(dict(file=name,changed_labels=changes,data_artists_sha256=before,data_artists_unchanged=True))
Figure.savefig=save_hook

# The existing readable response and entry plots, using their saved arrays.
ns=runpy.run_path(str(G/'font_plot_source.py'),run_name='parameter_plot_source')
ns['saturation']();ns['timeline']()

# Retain the landscape response variant as a separately delivered renamed figure.
source=(G/'font_plot_source.py').read_text()
source=source.replace('fig,axes=plt.subplots(6,3,figsize=(8.2,10.2))','fig,axes=plt.subplots(3,6,figsize=(15,6.6))')
source=source.replace('ax=axes[row,col]','ax=axes[row%3,col+(3 if row>=3 else 0)]')
source=source.replace('top=.945,wspace=.38,hspace=.65','top=.91,wspace=.4,hspace=.72')
source=source.replace('Fig2_22parameters_font_unified.png','response_landscape.png')
land={'__file__':str(G/'font_plot_source.py'),'__name__':'landscape_source'}
exec(compile(source,'landscape_source','exec'),land);land['saturation']()

# Eight-panel sensitivity ranking from unchanged archived response values.
import csv,string
rows=[]
for line in (G/'sensitivity.txt').read_text().splitlines():
    if not line.strip() or line.startswith('#'):continue
    p=line.split();rows.append(dict(name=p[1],row=int(p[2]),group=p[3],window=float(p[4]),samples=int(p[5]),values=np.array(p[6:],float)))
assert len(rows)==33
mode=json.loads((G/'sensitivity_display.json').read_text())['mode']
assert mode=='alk_highlight_top10'
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':10,
    'axes.titlesize':11,'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,
    'axes.linewidth':.7,'xtick.major.width':.6,'ytick.major.width':.6})
fig,axes=plt.subplots(2,4,figsize=(13.4,7.2))
fig.subplots_adjust(left=.07,right=.992,bottom=.105,top=.885,wspace=.31,hspace=.53)
fig.suptitle('Parameter sensitivity rankings',fontsize=14,y=.986)
fig.text(.5,.938,'Water-cycle parameters: 0–20 TU; carbon-cycle parameters: 0–500 TU',ha='center',fontsize=10.5)
variables=['$x_1$','$x_2$','$x_3$','$w$','$T_L$','$C_{\\mathrm{atm}}$','$C_{\\mathrm{ocn}}$','ALK']
def old_label(s):
    if s in ['sigma','kappa','lambda']:return '$'+chr(92)+s+'$'
    if re.fullmatch('c[0-9]+',s):return '$c_{'+s[1:]+'}$'
    return '$'+s+'$'
ranking=[]
for j,ax in enumerate(axes.flat):
    group='WATER' if j<5 else 'CARBON'
    items=[r for r in rows if r['group']==group]
    assert len(items)==(19 if j<5 else 14)
    assert all(r['window']==(20 if j<5 else 500) for r in items)
    ordered=sorted(items,key=lambda r:(-r['values'][j],r['row']))
    color='#1F4E79' if j<5 else '#1E6B3A' if j<7 else '#C44951'
    pale='#9DC3E6' if j<5 else '#9CD9A5' if j<7 else '#EAB6BA'
    selection_column=1 if j<5 else 5 if j<7 else 7
    selected={r['name'] for r in sorted(items,key=lambda r:-r['values'][selection_column])[:10]}
    values=[r['values'][j] for r in ordered];x=np.arange(len(ordered))
    bars=ax.bar(x,values,color=[color if r['name'] in selected else pale for r in ordered],width=.8,
        edgecolor=['#5F1D22' if j==7 and rank<10 else '#222222' if r['name'] in selected else pale for rank,r in enumerate(ordered)],
        linewidth=[1.05 if j==7 and rank<10 else .45 if r['name'] in selected else .3 for rank,r in enumerate(ordered)],zorder=3)
    labels=[rename_display(('$'+chr(92)+'mathbf{c_{'+r['name'][1:]+'}}$') if j==7 and rank<10 else old_label(r['name'])) for rank,r in enumerate(ordered)]
    ax.set_xticks(x,labels=labels,rotation=90)
    ax.tick_params(axis='x',length=2,pad=3)
    ax.set_title('('+string.ascii_lowercase[j]+') '+variables[j],pad=6)
    ax.set_ylim(0,max(values)*(1.34 if j in [0,5,7] else 1.16));ax.set_axisbelow(True);ax.grid(axis='y',color='#dddddd',lw=.45,zorder=0)
    ax.spines[['top','right']].set_visible(False)
    ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,3),useMathText=True)
    if j%4==0:ax.set_ylabel('Mean ensemble standard deviation',fontsize=9.5,labelpad=6)
    if j in [0,5,7]:
        ax.legend(handles=[Patch(facecolor=color,edgecolor='#222222',label='Top 10 ('+['x2','Catm','ALK'][[0,5,7].index(j)]+')'),
            Patch(facecolor=pale,edgecolor=pale,label='Other parameters')],frameon=False,fontsize=8.2,loc='upper right',handlelength=1.2)
    for rank,(row,bar) in enumerate(zip(ordered,bars),1):
        assert bar.get_height()==row['values'][j]
        ranking.append(dict(panel=string.ascii_lowercase[j],variable=['x1','x2','x3','w','TL','Catm','Cocn','ALK'][j],
          rank=rank,old_parameter=row['name'],parameter=rename_display(row['name']),
          parameter_vector_row=row['row'],sensitivity=float(row['values'][j]),window_TU=row['window'],native_samples=row['samples'],
          selected_highlight=row['name'] in selected,bold_label=(j==7 and rank<=10)))
# Tick labels are reset from their FixedFormatter during rendering. Set final
# names in the formatter itself, then prevent the generic one-pass hook from
# remapping already-final c17/c18/etc a second time.
fig._names_updated=True
fig.savefig(G/'sensitivity.png',dpi=600,facecolor='white');plt.close(fig)
with (O/'sensitivity_ranking.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(ranking[0]));writer.writeheader();writer.writerows(ranking)
(O/'sensitivity_audit.json').write_text(json.dumps(dict(display_mode=mode,panels=8,
    panel_counts=[sum(r['panel']==string.ascii_lowercase[j] for r in ranking) for j in range(8)],
    original_sensitivity_file_sha256=hashlib.sha256((G/'sensitivity.txt').read_bytes()).hexdigest(),
    unchanged_values=True,rankings=ranking,font='Times New Roman',dpi=600),indent=2))

# Ensemble curves: restore the original compact script's data layout.
cache=G/'parameter_ensemble_20260913';cache.mkdir(exist_ok=True)
shutil.copy2(G/'parameter_arrays.npz',cache/'plot_arrays.npz')
stub=G/'plot_corrected.py'
stub.write_text('''from matplotlib import pyplot as plt,font_manager
def configure_font(base):
 font_manager.fontManager.addfont(str(base/'times.ttf'))
 plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'mathtext.fontset':'stix','axes.titlesize':13,'axes.labelsize':11,'xtick.labelsize':10,'ytick.labelsize':10,'axes.linewidth':.8,'savefig.facecolor':'white','figure.facecolor':'white'})
''')
import sys
sys.path.insert(0,str(G))
source=(G/'ensemble_source.py').read_text().replace("assert size==[4800,4920]","assert size[0]>=4800")
exec(compile(source,str(G/'ensemble_source.py'),'exec'),{'__file__':str(G/'ensemble_source.py'),'__name__':'ensemble_source'})

# Nonlinear bracket: all curves come directly from the saved native diagnostics.
colors={'CTL':'#4a7bd9','CDA5':'#d96b4a','CDA7':'#2e9e5b'}
data={kind:{v:np.loadtxt(G/(kind+'_'+v+'.txt')) for v in colors} for kind in ['alk','bcal']}
panels=[('alk',1,2,'ALK','ALK time series: CTL, CDA5 and CDA7 (10000–11000 TU; 0.01 TU sampling)',(10000,11000)),
 ('bcal',1,2,'Bcal','Bcal time series: CTL, CDA5 and CDA7 (10400–10500 TU; 0.01 TU sampling)',(10400,10500)),
 ('bcal',3,4,'ALK - c27·Cocean + c28','Bcal nonlinear bracket: CTL, CDA5 and CDA7 (10400–10500 TU; 0.01 TU sampling)',(10400,10500))]
plt.rcParams.update({'font.family':'Times New Roman','font.size':11,'path.simplify':False})
fig,axes=plt.subplots(3,1,figsize=(13,10.5))
for ax,(kind,tc,sc,yl,title,limits) in zip(axes,panels):
    t=data[kind]['CTL'][:,0]
    ax.plot(t,data[kind]['CTL'][:,tc],color='#222222',lw=1.25,ls='--',label='Truth',zorder=4)
    for v in colors:ax.plot(t,data[kind][v][:,sc],color=colors[v],lw=1,label=v)
    if tc==3:ax.axhline(0,color='#777777',lw=.9,ls=':',zorder=1)
    ax.set_xlim(*limits);ax.set_xlabel('Time (TU)',fontsize=12,labelpad=3);ax.set_ylabel(yl,fontsize=12)
    ax.set_title(title,fontsize=13,pad=7);ax.ticklabel_format(axis='x',style='plain',useOffset=False)
    ax.grid(True,ls='--',lw=.6,alpha=.35);ax.legend(loc='best',frameon=True,fontsize=10,ncol=2)
fig.tight_layout(pad=1.15,h_pad=1.5)
fig.savefig(G/'ALK_Bcal_nonlinear_bracket_vertical_compact.png',bbox_inches='tight',facecolor='white');plt.close(fig)

# Emission figure: exact text-only correction outside the numerical plot areas.
im=Image.open(G/'emission_original.png').convert('RGB');old=np.asarray(im).copy();draw=ImageDraw.Draw(im)
boxes=[(249,31,405,54),(880,31,1039,54)]
for box,value in zip(boxes,['1.2','0.4']):
    draw.rectangle(box,fill='white')
    buf=io.BytesIO();mathtext.math_to_image('$E_0='+value+r'\ \mathrm{minus}\ E_0=0.8$',buf,
        prop=font_manager.FontProperties(family='Times New Roman',size=10),dpi=100,format='png')
    label=Image.open(buf).convert('RGBA');x=(box[0]+box[2]-label.width)//2;y=(box[1]+box[3]-label.height)//2
    assert x>=box[0] and y>=box[1] and x+label.width<=box[2] and y+label.height<=box[3]
    im.paste(label,(x,y),label)
mask=np.ones(old.shape[:2],bool)
for x0,y0,x1,y1 in boxes:mask[y0:y1+1,x0:x1+1]=False
assert np.array_equal(old[mask],np.asarray(im)[mask])
im.save(O/'Emission.png',dpi=(600,600))
records.append(dict(file='Emission.png',changed_labels=['E -> E_0, two panel subtitles only'],all_pixels_outside_label_boxes_unchanged=True))

# Stable output names and previews for document embedding and visual inspection.
expected=['Sensitivity.png','Response_portrait.png','Response_landscape.png','Timeline.png','Ensemble.png','ALK_threshold.png','Emission.png']
for name in expected:
    path=O/name;assert path.exists(),name
    im=Image.open(path);im.thumbnail((1500,1900));im.save(O/(path.stem+'_preview.png'))
manifest=dict(files=[dict(file=n,sha256=hashlib.sha256((O/n).read_bytes()).hexdigest()) for n in expected],
    label_changes=records,all_existing_data_inputs_unchanged=True,parameter_names_updated_once=True)
(O/'figure_audit.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('PARAMETER_FIGURES_COMPLETE',flush=True)
